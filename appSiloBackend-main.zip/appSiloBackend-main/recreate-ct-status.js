// Script para recrear la tabla CT_Status con la estructura correcta
const { query } = require('./src/db/mariadb-config');

async function recreateCTStatusTable() {
  try {
    console.log('Eliminando tabla CT_Status si existe...');
    await query('DROP TABLE IF EXISTS CT_Status');
    console.log('Tabla CT_Status eliminada correctamente');

    console.log('Creando tabla CT_Status con la estructura correcta...');
    const createTableSQL = `
      CREATE TABLE CT_Status (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        StConectado BOOL DEFAULT 0,
        StDefecto BOOL DEFAULT 0,
        St_Auto BOOL DEFAULT 0,
        St_Semi BOOL DEFAULT 0,
        St_Manual BOOL DEFAULT 0,
        St_Puerta BOOL DEFAULT 0,
        St_Datos BOOL DEFAULT 0,
        MatEntrada INT(11) DEFAULT 0,
        MatSalida INT(11) DEFAULT 0,
        PasDestino INT(11) DEFAULT 0,
        CicloTrabajo INT(11) DEFAULT 0,
        PasActual INT(11) DEFAULT 0,
        St_Carro BOOL DEFAULT 0
      )
    `;
    await query(createTableSQL);
    console.log('Tabla CT_Status creada correctamente con la estructura actualizada');

    // Insertar un registro inicial
    const insertSQL = `
      INSERT INTO CT_Status (
        StConectado, StDefecto, St_Auto, St_Semi, St_Manual, 
        St_Puerta, St_Datos, MatEntrada, MatSalida, 
        PasDestino, CicloTrabajo, PasActual, St_Carro
      ) VALUES (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    `;
    await query(insertSQL);
    console.log('Registro inicial insertado en la tabla CT_Status');

    // Verificar la estructura
    const describeSQL = 'DESCRIBE CT_Status';
    const structure = await query(describeSQL);
    console.log('Estructura de la tabla CT_Status:');
    console.table(structure);

    // Verificar los datos
    const selectSQL = 'SELECT * FROM CT_Status';
    const data = await query(selectSQL);
    console.log('Datos en la tabla CT_Status:');
    console.table(data);

    console.log('Proceso completado correctamente');
    process.exit(0);
  } catch (error) {
    console.error('Error al recrear la tabla CT_Status:', error);
    process.exit(1);
  }
}

// Ejecutar la función
recreateCTStatusTable();
