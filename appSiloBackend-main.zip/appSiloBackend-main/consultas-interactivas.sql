-- Consultas interactivas para MariaDB
-- Para ejecutar estas consultas de forma interactiva, usa el siguiente comando en cmd:
-- C:\Users\ASG\Downloads\mariadb-11.7.2-winx64\bin\mysql.exe -u ai -p0260 operator_insight

-- Seleccionar la base de datos
USE operator_insight;

-- CONSULTAS PARA VERIFICAR LA ESTRUCTURA ACTUAL DE LAS TABLAS
-- Mostrar todas las tablas
SHOW TABLES;

-- Mostrar la estructura de las tablas
DESCRIBE PT_Status;
DESCRIBE Pas_Status;
DESCRIBE MesasEntrada_Status;
DESCRIBE MesasSalida_Status;

-- CONSULTAS PARA VERIFICAR LOS DATOS ACTUALES (SIEMPRE ID=1)
-- Ver el registro actual de PT_Status (siempre id=1)
SELECT * FROM PT_Status WHERE id = 1;

-- Ver el registro actual de Pas_Status (siempre id=1)
SELECT * FROM Pas_Status WHERE id = 1;

-- Ver el registro actual de MesasEntrada_Status (siempre id=1)
SELECT * FROM MesasEntrada_Status WHERE id = 1;

-- Ver el registro actual de MesasSalida_Status (siempre id=1)
SELECT * FROM MesasSalida_Status WHERE id = 1;

-- CONSULTAS PARA VERIFICAR QUE SOLO HAY UNA FILA EN CADA TABLA
-- Contar registros en cada tabla
SELECT 'PT_Status' as tabla, COUNT(*) as total_registros FROM PT_Status
UNION
SELECT 'Pas_Status' as tabla, COUNT(*) as total_registros FROM Pas_Status
UNION
SELECT 'MesasEntrada_Status' as tabla, COUNT(*) as total_registros FROM MesasEntrada_Status
UNION
SELECT 'MesasSalida_Status' as tabla, COUNT(*) as total_registros FROM MesasSalida_Status;

-- CONSULTAS PARA ACTUALIZAR MANUALMENTE LOS DATOS
-- Actualizar el registro de Pas_Status
UPDATE Pas_Status 
SET 
  pas1 = 0,
  pas2 = 0,
  pas3 = 0,
  pas4 = 0,
  pas5 = 0,
  pas6 = 0,
  pas7 = 0,
  pas8 = 0,
  pas9 = 0,
  pas10 = 0,
  pas11 = 0,
  pas12 = 0,
  timestamp = CURRENT_TIMESTAMP
WHERE 
  id = 1;

-- Actualizar el registro de MesasEntrada_Status
UPDATE MesasEntrada_Status 
SET 
  pep1 = 0,
  pep2 = 0,
  pep3 = 0,
  pep4 = 0,
  pep5 = 0,
  pep6 = 0,
  pep7 = 0,
  pep8 = 0,
  pep9 = 0,
  pep10 = 0,
  pep11 = 0,
  pep12 = 0,
  timestamp = CURRENT_TIMESTAMP
WHERE 
  id = 1;

-- Actualizar el registro de MesasSalida_Status
UPDATE MesasSalida_Status 
SET 
  psp1 = 0,
  psp2 = 0,
  psp3 = 0,
  psp4 = 0,
  psp5 = 0,
  psp6 = 0,
  psp7 = 0,
  psp8 = 0,
  psp9 = 0,
  psp10 = 0,
  psp11 = 0,
  psp12 = 0,
  timestamp = CURRENT_TIMESTAMP
WHERE 
  id = 1;

-- CONSULTAS PARA INSERTAR REGISTROS INICIALES SI NO EXISTEN
-- Insertar registro inicial en Pas_Status si no existe
INSERT INTO Pas_Status (id, pas1, pas2, pas3, pas4, pas5, pas6, pas7, pas8, pas9, pas10, pas11, pas12)
SELECT 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM Pas_Status WHERE id = 1);

-- Insertar registro inicial en MesasEntrada_Status si no existe
INSERT INTO MesasEntrada_Status (id, pep1, pep2, pep3, pep4, pep5, pep6, pep7, pep8, pep9, pep10, pep11, pep12)
SELECT 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM MesasEntrada_Status WHERE id = 1);

-- Insertar registro inicial en MesasSalida_Status si no existe
INSERT INTO MesasSalida_Status (id, psp1, psp2, psp3, psp4, psp5, psp6, psp7, psp8, psp9, psp10, psp11, psp12)
SELECT 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM MesasSalida_Status WHERE id = 1);

-- CONSULTAS PARA OBTENER INFORMACIÓN COMBINADA
-- Ver el estado de todos los pasillos
SELECT 
  id,
  CONCAT('Pasillo 1: ', CASE pas1 WHEN 0 THEN 'EN SERVICIO' WHEN 1 THEN 'FUERA DE SERVICIO' ELSE 'DESCONOCIDO' END) AS pasillo1,
  CONCAT('Pasillo 2: ', CASE pas2 WHEN 0 THEN 'EN SERVICIO' WHEN 1 THEN 'FUERA DE SERVICIO' ELSE 'DESCONOCIDO' END) AS pasillo2,
  CONCAT('Pasillo 3: ', CASE pas3 WHEN 0 THEN 'EN SERVICIO' WHEN 1 THEN 'FUERA DE SERVICIO' ELSE 'DESCONOCIDO' END) AS pasillo3,
  CONCAT('Pasillo 4: ', CASE pas4 WHEN 0 THEN 'EN SERVICIO' WHEN 1 THEN 'FUERA DE SERVICIO' ELSE 'DESCONOCIDO' END) AS pasillo4,
  CONCAT('Pasillo 5: ', CASE pas5 WHEN 0 THEN 'EN SERVICIO' WHEN 1 THEN 'FUERA DE SERVICIO' ELSE 'DESCONOCIDO' END) AS pasillo5,
  CONCAT('Pasillo 6: ', CASE pas6 WHEN 0 THEN 'EN SERVICIO' WHEN 1 THEN 'FUERA DE SERVICIO' ELSE 'DESCONOCIDO' END) AS pasillo6,
  timestamp
FROM Pas_Status
WHERE id = 1;

-- Ver el estado de todas las mesas de entrada
SELECT 
  id,
  CONCAT('Mesa E1: ', CASE pep1 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_e1,
  CONCAT('Mesa E2: ', CASE pep2 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_e2,
  CONCAT('Mesa E3: ', CASE pep3 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_e3,
  CONCAT('Mesa E4: ', CASE pep4 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_e4,
  CONCAT('Mesa E5: ', CASE pep5 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_e5,
  CONCAT('Mesa E6: ', CASE pep6 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_e6,
  timestamp
FROM MesasEntrada_Status
WHERE id = 1;

-- Ver el estado de todas las mesas de salida
SELECT 
  id,
  CONCAT('Mesa S1: ', CASE psp1 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_s1,
  CONCAT('Mesa S2: ', CASE psp2 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_s2,
  CONCAT('Mesa S3: ', CASE psp3 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_s3,
  CONCAT('Mesa S4: ', CASE psp4 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_s4,
  CONCAT('Mesa S5: ', CASE psp5 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_s5,
  CONCAT('Mesa S6: ', CASE psp6 WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' WHEN 2 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS mesa_s6,
  timestamp
FROM MesasSalida_Status
WHERE id = 1;

-- Consulta para ver el estado del Puente Transferidor
SELECT 
  id,
  CONCAT('Ocupación: ', CASE ocupacion WHEN 0 THEN 'LIBRE' WHEN 1 THEN 'OCUPADO' ELSE 'DESCONOCIDO' END) AS ocupacion_pt,
  CONCAT('Estado: ', CASE estado WHEN 0 THEN 'OK' WHEN 1 THEN 'AVERÍA' ELSE 'DESCONOCIDO' END) AS estado_pt,
  CONCAT('Situación: ', CASE situacion WHEN 0 THEN 'PARADO' WHEN 1 THEN 'EN MOVIMIENTO' ELSE 'DESCONOCIDO' END) AS situacion_pt,
  CONCAT('Posición: ', posicion) AS posicion_pt,
  timestamp
FROM PT_Status
WHERE id = 1;

-- Consulta para obtener un resumen del estado del sistema
SELECT 
  (SELECT COUNT(*) FROM Pas_Status WHERE id = 1 AND (pas1 = 1 OR pas2 = 1 OR pas3 = 1 OR pas4 = 1 OR pas5 = 1 OR 
                                                    pas6 = 1 OR pas7 = 1 OR pas8 = 1 OR pas9 = 1 OR pas10 = 1 OR 
                                                    pas11 = 1 OR pas12 = 1)) AS pasillos_fuera_servicio,
  (SELECT COUNT(*) FROM MesasEntrada_Status WHERE id = 1 AND (pep1 = 1 OR pep2 = 1 OR pep3 = 1 OR pep4 = 1 OR pep5 = 1 OR 
                                                             pep6 = 1 OR pep7 = 1 OR pep8 = 1 OR pep9 = 1 OR pep10 = 1 OR 
                                                             pep11 = 1 OR pep12 = 1)) AS mesas_entrada_ocupadas,
  (SELECT COUNT(*) FROM MesasEntrada_Status WHERE id = 1 AND (pep1 = 2 OR pep2 = 2 OR pep3 = 2 OR pep4 = 2 OR pep5 = 2 OR 
                                                             pep6 = 2 OR pep7 = 2 OR pep8 = 2 OR pep9 = 2 OR pep10 = 2 OR 
                                                             pep11 = 2 OR pep12 = 2)) AS mesas_entrada_averia,
  (SELECT COUNT(*) FROM MesasSalida_Status WHERE id = 1 AND (psp1 = 1 OR psp2 = 1 OR psp3 = 1 OR psp4 = 1 OR psp5 = 1 OR 
                                                            psp6 = 1 OR psp7 = 1 OR psp8 = 1 OR psp9 = 1 OR psp10 = 1 OR 
                                                            psp11 = 1 OR psp12 = 1)) AS mesas_salida_ocupadas,
  (SELECT COUNT(*) FROM MesasSalida_Status WHERE id = 1 AND (psp1 = 2 OR psp2 = 2 OR psp3 = 2 OR psp4 = 2 OR psp5 = 2 OR 
                                                            psp6 = 2 OR psp7 = 2 OR psp8 = 2 OR psp9 = 2 OR psp10 = 2 OR 
                                                            psp11 = 2 OR psp12 = 2)) AS mesas_salida_averia,
  (SELECT ocupacion FROM PT_Status WHERE id = 1) AS pt_ocupacion,
  (SELECT estado FROM PT_Status WHERE id = 1) AS pt_estado,
  (SELECT situacion FROM PT_Status WHERE id = 1) AS pt_situacion,
  (SELECT posicion FROM PT_Status WHERE id = 1) AS pt_posicion;

-- Consulta para simular valores en las tablas (para pruebas)
-- Simular algunos pasillos fuera de servicio
UPDATE Pas_Status 
SET 
  pas1 = 0,
  pas2 = 0,
  pas3 = 1, -- Pasillo 3 fuera de servicio
  pas4 = 0,
  pas5 = 1, -- Pasillo 5 fuera de servicio
  pas6 = 0,
  pas7 = 0,
  pas8 = 0,
  pas9 = 0,
  pas10 = 0,
  pas11 = 0,
  pas12 = 0,
  timestamp = CURRENT_TIMESTAMP
WHERE 
  id = 1;

-- Simular algunas mesas de entrada ocupadas o con avería
UPDATE MesasEntrada_Status 
SET 
  pep1 = 1, -- Mesa 1 ocupada
  pep2 = 0,
  pep3 = 0,
  pep4 = 2, -- Mesa 4 con avería
  pep5 = 0,
  pep6 = 1, -- Mesa 6 ocupada
  pep7 = 0,
  pep8 = 0,
  pep9 = 0,
  pep10 = 0,
  pep11 = 0,
  pep12 = 0,
  timestamp = CURRENT_TIMESTAMP
WHERE 
  id = 1;

-- Simular algunas mesas de salida ocupadas o con avería
UPDATE MesasSalida_Status 
SET 
  psp1 = 0,
  psp2 = 1, -- Mesa 2 ocupada
  psp3 = 0,
  psp4 = 0,
  psp5 = 2, -- Mesa 5 con avería
  psp6 = 0,
  psp7 = 1, -- Mesa 7 ocupada
  psp8 = 0,
  psp9 = 0,
  psp10 = 0,
  psp11 = 0,
  psp12 = 0,
  timestamp = CURRENT_TIMESTAMP
WHERE 
  id = 1;

-- Simular un estado específico del Puente Transferidor
UPDATE PT_Status 
SET 
  ocupacion = 1, -- Ocupado
  estado = 0,    -- OK
  situacion = 1, -- En movimiento
  posicion = 3,  -- Posición 3
  timestamp = CURRENT_TIMESTAMP
WHERE 
  id = 1;
