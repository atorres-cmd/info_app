// Script para verificar y crear la tabla CT_Status si no existe
require('dotenv').config();
const { query } = require('./src/db/mariadb-config');

async function checkAndCreateCTStatusTable() {
  try {
    console.log('Verificando si la tabla CT_Status existe...');
    
    // Verificar si la tabla existe
    const checkTableSql = `
      SELECT COUNT(*) as count 
      FROM information_schema.tables 
      WHERE table_schema = DATABASE() 
      AND table_name = 'CT_Status'
    `;
    
    const [checkResult] = await query(checkTableSql);
    
    if (checkResult.count === 0) {
      // La tabla no existe, vamos a crearla
      console.log('La tabla CT_Status no existe. Creándola...');
      
      const createTableSql = `
        CREATE TABLE CT_Status (
          id INT AUTO_INCREMENT PRIMARY KEY,
          timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          StConectado TINYINT DEFAULT 0,
          StDefecto TINYINT DEFAULT 0,
          St_Auto TINYINT DEFAULT 0,
          St_Semi TINYINT DEFAULT 0,
          St_Manual TINYINT DEFAULT 0,
          St_Puerta TINYINT DEFAULT 0,
          St_Datos TINYINT DEFAULT 0,
          MatEntrada INT DEFAULT 0,
          MatSalida INT DEFAULT 0,
          PasDestino TINYINT DEFAULT 0,
          CicloTrabajo TINYINT DEFAULT 0,
          PasActual TINYINT DEFAULT 0,
          St_Carro TINYINT DEFAULT 0
        )
      `;
      
      await query(createTableSql);
      console.log('Tabla CT_Status creada correctamente.');
      
      // Insertar el primer registro
      const insertSql = `
        INSERT INTO CT_Status (
          StConectado, StDefecto, St_Auto, St_Semi, St_Manual, 
          St_Puerta, St_Datos, MatEntrada, MatSalida, 
          PasDestino, CicloTrabajo, PasActual, St_Carro
        ) 
        VALUES (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
      `;
      
      await query(insertSql);
      console.log('Primer registro insertado en la tabla CT_Status.');
    } else {
      console.log('La tabla CT_Status ya existe.');
      
      // Mostrar la estructura de la tabla
      console.log('Estructura de la tabla CT_Status:');
      const describeTableSql = `DESCRIBE CT_Status`;
      const tableStructure = await query(describeTableSql);
      console.log(tableStructure);
    }
    
    // Mostrar los datos actuales
    console.log('Datos actuales en la tabla CT_Status:');
    const selectDataSql = `SELECT * FROM CT_Status`;
    const currentData = await query(selectDataSql);
    console.log(currentData);
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

// Ejecutar la función principal
checkAndCreateCTStatusTable();
