/**
 * Script para verificar la tabla CT_Alarmas
 */
const { query } = require('./src/db/mariadb-config');
const { logger } = require('./src/utils/logger');

async function checkCTAlarmas() {
  try {
    logger.info('Verificando tabla CT_Alarmas...');
    
    // Verificar si la tabla existe
    const tablesResult = await query('SHOW TABLES LIKE "CT_Alarmas"');
    if (tablesResult.length === 0) {
      logger.info('La tabla CT_Alarmas no existe, creando...');
      
      // Crear la tabla CT_Alarmas
      await query(`
        CREATE TABLE IF NOT EXISTS CT_Alarmas (
          id INT AUTO_INCREMENT PRIMARY KEY,
          error_comunicacion BOOLEAN DEFAULT FALSE,
          emergencia_armario_carro BOOLEAN DEFAULT FALSE,
          anomalia_variador BOOLEAN DEFAULT FALSE,
          anomalia_motor_traslacion BOOLEAN DEFAULT FALSE,
          anomalia_motor_entrada BOOLEAN DEFAULT FALSE,
          anomalia_motor_salida BOOLEAN DEFAULT FALSE,
          final_carrera_pasillo_1 BOOLEAN DEFAULT FALSE,
          final_carrera_pasillo_12 BOOLEAN DEFAULT FALSE,
          paleta_descentrada_transfer_entrada BOOLEAN DEFAULT FALSE,
          paleta_descentrada_transfer_salida BOOLEAN DEFAULT FALSE,
          limite_inferior_lectura_encoder BOOLEAN DEFAULT FALSE,
          limite_superior_lectura_encoder BOOLEAN DEFAULT FALSE,
          tiempo_transferencia_mesa_salida_carro BOOLEAN DEFAULT FALSE,
          telemetro BOOLEAN DEFAULT FALSE,
          tiempo_entrada BOOLEAN DEFAULT FALSE,
          tiempo_salida BOOLEAN DEFAULT FALSE,
          paleta_entrada_sin_codigo BOOLEAN DEFAULT FALSE,
          paleta_salida_sin_codigo BOOLEAN DEFAULT FALSE,
          timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
      `);
      logger.info('Tabla CT_Alarmas creada correctamente');
      
      // Insertar un registro inicial
      await query(`
        INSERT INTO CT_Alarmas (
          error_comunicacion, emergencia_armario_carro, anomalia_variador,
          anomalia_motor_traslacion, anomalia_motor_entrada, anomalia_motor_salida,
          final_carrera_pasillo_1, final_carrera_pasillo_12,
          paleta_descentrada_transfer_entrada, paleta_descentrada_transfer_salida,
          limite_inferior_lectura_encoder, limite_superior_lectura_encoder,
          tiempo_transferencia_mesa_salida_carro, telemetro,
          tiempo_entrada, tiempo_salida,
          paleta_entrada_sin_codigo, paleta_salida_sin_codigo
        ) VALUES (
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
        )
      `);
      logger.info('Registro inicial insertado en CT_Alarmas');
    } else {
      logger.info('La tabla CT_Alarmas existe');
    }
    
    // Consultar los datos actuales
    const data = await query('SELECT * FROM CT_Alarmas');
    logger.info(`Se encontraron ${data.length} registros en CT_Alarmas`);
    logger.info('Datos en CT_Alarmas:', JSON.stringify(data, null, 2));
    
    process.exit(0);
  } catch (error) {
    logger.error('Error al verificar la tabla CT_Alarmas:', error);
    process.exit(1);
  }
}

// Ejecutar la función principal
checkCTAlarmas();
