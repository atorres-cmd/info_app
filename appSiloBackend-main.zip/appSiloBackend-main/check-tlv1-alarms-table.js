// Script para verificar la tabla tlv1Alarms
const { query } = require('./src/db/mariadb-config');

async function checkTable() {
  try {
    console.log('Verificando la tabla tlv1Alarms...');
    
    // Verificar si la tabla existe
    const checkTableSql = `
      SELECT COUNT(*) as count 
      FROM information_schema.tables 
      WHERE table_schema = 'operator_insight' 
      AND table_name = 'tlv1Alarms'
    `;
    
    const [checkResult] = await query(checkTableSql);
    
    if (checkResult.count === 0) {
      console.log('La tabla tlv1Alarms NO existe.');
      return;
    }
    
    console.log('La tabla tlv1Alarms existe.');
    
    // Obtener la estructura de la tabla
    const describeTableSql = `DESCRIBE tlv1Alarms`;
    const describeResult = await query(describeTableSql);
    
    console.log('Estructura de la tabla tlv1Alarms:');
    console.log(JSON.stringify(describeResult, null, 2));
    
    // Insertar un registro de prueba
    const insertSql = `
      INSERT INTO tlv1Alarms (
        error_comunicacion,
        emergencia_armario_carro,
        anomalia_variador,
        anomalia_motor_traslacion,
        anomalia_motor_entrada,
        anomalia_motor_salida,
        final_carrera_pasillo_1,
        final_carrera_pasillo_12,
        paleta_descentrada_transfer_entrada,
        paleta_descentrada_transfer_salida,
        limite_inferior_lectura_encoder,
        limite_superior_lectura_encoder,
        tiempo_transferencia_mesa_salida_carro,
        telemetro,
        tiempo_entrada,
        tiempo_salida,
        paleta_entrada_sin_codigo,
        paleta_salida_sin_codigo
      ) VALUES (
        true, false, true, false, true, false, true, false, 
        true, false, true, false, true, false, true, false, true, false
      )
    `;
    
    await query(insertSql);
    console.log('Registro de prueba insertado correctamente.');
    
    // Consultar los datos
    const selectSql = `SELECT * FROM tlv1Alarms`;
    const selectResult = await query(selectSql);
    
    console.log('Datos en la tabla tlv1Alarms:');
    console.log(JSON.stringify(selectResult, null, 2));
    
    process.exit(0);
  } catch (error) {
    console.error('Error al verificar la tabla tlv1Alarms:', error);
    process.exit(1);
  }
}

// Ejecutar la función
checkTable();
