// Script para simular un defecto en el Carro Transferidor (CT)
require('dotenv').config();
const { query } = require('./src/db/mariadb-config');

async function testCTStatusDefect() {
  try {
    console.log('Simulando defecto en el Carro Transferidor (CT)...');
    
    // Activar el defecto en la tabla CT_Status (StDefecto = 1)
    const updateSql = `
      UPDATE CT_Status 
      SET 
        StDefecto = 1,
        StConectado = 0,
        timestamp = CURRENT_TIMESTAMP
      WHERE id = (SELECT id FROM CT_Status ORDER BY id DESC LIMIT 1)
    `;
    
    await query(updateSql);
    console.log('Defecto activado en CT_Status: StDefecto = 1, StConectado = 0');
    
    // Consultar el estado actual
    const selectSql = `SELECT * FROM CT_Status ORDER BY id DESC LIMIT 1`;
    const result = await query(selectSql);
    
    console.log('Estado actual del CT:');
    console.log(JSON.stringify(result[0], null, 2));
    
    // Esperar 30 segundos y luego desactivar el defecto
    console.log('Esperando 30 segundos antes de desactivar el defecto...');
    setTimeout(async () => {
      // Desactivar el defecto
      const resetSql = `
        UPDATE CT_Status 
        SET 
          StDefecto = 0,
          StConectado = 1,
          timestamp = CURRENT_TIMESTAMP
        WHERE id = (SELECT id FROM CT_Status ORDER BY id DESC LIMIT 1)
      `;
      
      await query(resetSql);
      console.log('Defecto desactivado en CT_Status: StDefecto = 0, StConectado = 1');
      
      // Consultar el estado actualizado
      const updatedResult = await query(selectSql);
      console.log('Estado actualizado del CT:');
      console.log(JSON.stringify(updatedResult[0], null, 2));
      
      process.exit(0);
    }, 30000);
  } catch (error) {
    console.error('Error al simular defecto en el CT:', error);
    process.exit(1);
  }
}

// Ejecutar la función
testCTStatusDefect();
