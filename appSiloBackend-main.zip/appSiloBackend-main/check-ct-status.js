/**
 * Script para verificar los datos en la tabla CT_Status
 */
const mariadb = require('mariadb');
require('dotenv').config();

// Configurar la conexión a la base de datos
const pool = mariadb.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'operator_insight',
  connectionLimit: 5
});

async function checkCTStatus() {
  let conn;
  try {
    conn = await pool.getConnection();
    
    // Verificar si la tabla CT_Status existe
    const tables = await conn.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = DATABASE() 
      AND table_name = 'CT_Status'
    `);
    
    if (tables.length === 0) {
      console.log('La tabla CT_Status no existe');
      return;
    }
    
    // Consultar los datos de la tabla CT_Status
    const rows = await conn.query('SELECT * FROM CT_Status');
    
    console.log('Datos en la tabla CT_Status:');
    console.log(JSON.stringify(rows, null, 2));
    
  } catch (err) {
    console.error('Error al consultar la tabla CT_Status:', err);
  } finally {
    if (conn) conn.release();
    pool.end();
  }
}

// Ejecutar la función
checkCTStatus();
