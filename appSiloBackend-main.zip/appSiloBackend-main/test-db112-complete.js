/**
 * Script para probar la lectura de todas las variables del DB112
 */
const nodes7 = require('nodes7');
require('dotenv').config();

// Función para leer datos del PLC
async function readPLCData() {
  return new Promise((resolve, reject) => {
    // Crear una nueva conexión al PLC
    const conn = new nodes7();
    
    // Configurar la conexión al PLC
    conn.initiateConnection(
      {
        host: process.env.PLC_IP || '10.21.178.100',
        port: parseInt(process.env.PLC_PORT || '102'),
        rack: parseInt(process.env.PLC_RACK || '0'),
        slot: parseInt(process.env.PLC_SLOT || '3'),
        timeout: 5000
      },
      (err) => {
        if (err) {
          console.error(`Error al conectar con el PLC: ${err}`);
          reject(err);
          return;
        }
        
        console.log('Conexión establecida con el PLC');
        
        // Lista completa de variables a leer
        const variables = [
          'DB112,X130.0', // Status-Conectado
          'DB112,X130.1', // Status-Defecto
          'DB112,X130.2', // Status-Automático
          'DB112,X130.3', // Status-Semiautomático
          'DB112,X130.4', // Status-Manual
          'DB112,X130.5', // Status-Emergencia puerta armario
          'DB112,X130.6', // Status-Con datos
          'DB112,X130.7', // Sin descripción
          'DB112,X131.0', // Sin descripción
          'DB112,X131.1', // Sin descripción
          'DB112,X131.2', // Autorización de transferencia desde TC26
          'DB112,X131.3', // Fin de transferencia desde TC26
          'DB112,X131.4', // Petición de transferencia desde TC30
          'DB112,X131.5', // Sin descripción
          'DB112,X131.6', // Sin descripción
          'DB112,X131.7', // Acuse de orden recibida
          'DB112,W132',   // Matrícula paleta en transportador de entrada
          'DB112,W134',   // Matrícula paleta en transportador de salida
          'DB112,B136',   // Pasillo destino
          'DB112,B137',   // Ciclo de trabajo
          'DB112,B138',   // Sin descripción
          'DB112,B139',   // Sin descripción
          'DB112,B140',   // Numero de pasillo actual
          'DB112,B141',   // Estado carro (0=Libre 1=Ocupado 2=Avería)
          'DB112,X142.0', // Defecto-Error de comunicación
          'DB112,X142.1', // Defecto-Emergencia armario carro
          'DB112,X142.2', // Defecto-Anomalía variador
          'DB112,X142.3', // Defecto-Anomalía motor traslación
          'DB112,X142.4', // Defecto-Anomalía motor entrada
          'DB112,X142.5', // Defecto-Anomalía motor salida
          'DB112,X142.6', // Defecto-Final de carrera pasillo 1
          'DB112,X142.7', // Defecto-Final de carrera pasillo 12
          'DB112,X143.0', // Defecto-Paleta descentrada en transfer de entrada
          'DB112,X143.1', // Defecto-Paleta descentrada en transfer de salida
          'DB112,X143.2', // Sin descripción
          'DB112,X143.3', // Sin descripción
          'DB112,X143.4', // Sin descripción
          'DB112,X143.5', // Sin descripción
          'DB112,X143.6', // Sin descripción
          'DB112,X143.7', // Sin descripción
          'DB112,X144.0', // Visualización-Centraje traslación adelante
          'DB112,X144.1', // Visualización-Centraje traslación atrás
          'DB112,X144.2', // Visualización-Presencia delantera de paleta en entrada
          'DB112,X144.3', // Visualización-Presencia trasera de paleta en entrada
          'DB112,X144.4', // Visualización-Presencia delantera de paleta en salida
          'DB112,X144.5', // Visualización-Presencia trasera de paleta en salida
          'DB112,X144.6', // Sin descripción
          'DB112,X144.7', // Sin descripción
          'DB112,X145.0', // Visualización-Marcha traslación adelante
          'DB112,X145.1', // Visualización-Marcha traslación atrás
          'DB112,X145.2', // Visualización-Motor traslación parado
          'DB112,X145.3', // Visualización-Centraje traslación
          'DB112,X145.4', // Visualización-Marcha transportador entrada
          'DB112,X145.5', // Visualización-Marcha transportador salida
          'DB112,X145.6', // Visualización-Defecto traslación
          'DB112,X145.7'  // Visualización-Defecto transportador
        ];
        
        // Añadir variables a la conexión
        conn.addItems(variables);
        
        // Leer las variables
        conn.readAllItems((err, values) => {
          // Desconectar del PLC después de leer
          conn.dropConnection(() => {
            console.log('Desconectado del PLC');
          });
          
          if (err) {
            console.error(`Error al leer datos del PLC: ${err}`);
            reject(err);
            return;
          }
          
          // Crear un objeto con los nombres de las variables
          const namedValues = {};
          const descriptions = {
            'DB112,X130.0': 'Status-Conectado',
            'DB112,X130.1': 'Status-Defecto',
            'DB112,X130.2': 'Status-Automático',
            'DB112,X130.3': 'Status-Semiautomático',
            'DB112,X130.4': 'Status-Manual',
            'DB112,X130.5': 'Status-Emergencia puerta armario',
            'DB112,X130.6': 'Status-Con datos',
            'DB112,X130.7': 'Sin descripción',
            'DB112,X131.0': 'Sin descripción',
            'DB112,X131.1': 'Sin descripción',
            'DB112,X131.2': 'Autorización de transferencia desde TC26',
            'DB112,X131.3': 'Fin de transferencia desde TC26',
            'DB112,X131.4': 'Petición de transferencia desde TC30',
            'DB112,X131.5': 'Sin descripción',
            'DB112,X131.6': 'Sin descripción',
            'DB112,X131.7': 'Acuse de orden recibida',
            'DB112,W132': 'Matrícula paleta en transportador de entrada',
            'DB112,W134': 'Matrícula paleta en transportador de salida',
            'DB112,B136': 'Pasillo destino',
            'DB112,B137': 'Ciclo de trabajo',
            'DB112,B138': 'Sin descripción',
            'DB112,B139': 'Sin descripción',
            'DB112,B140': 'Numero de pasillo actual',
            'DB112,B141': 'Estado carro (0=Libre 1=Ocupado 2=Avería)',
            'DB112,X142.0': 'Defecto-Error de comunicación',
            'DB112,X142.1': 'Defecto-Emergencia armario carro',
            'DB112,X142.2': 'Defecto-Anomalía variador',
            'DB112,X142.3': 'Defecto-Anomalía motor traslación',
            'DB112,X142.4': 'Defecto-Anomalía motor entrada',
            'DB112,X142.5': 'Defecto-Anomalía motor salida',
            'DB112,X142.6': 'Defecto-Final de carrera pasillo 1',
            'DB112,X142.7': 'Defecto-Final de carrera pasillo 12',
            'DB112,X143.0': 'Defecto-Paleta descentrada en transfer de entrada',
            'DB112,X143.1': 'Defecto-Paleta descentrada en transfer de salida',
            'DB112,X143.2': 'Sin descripción',
            'DB112,X143.3': 'Sin descripción',
            'DB112,X143.4': 'Sin descripción',
            'DB112,X143.5': 'Sin descripción',
            'DB112,X143.6': 'Sin descripción',
            'DB112,X143.7': 'Sin descripción',
            'DB112,X144.0': 'Visualización-Centraje traslación adelante',
            'DB112,X144.1': 'Visualización-Centraje traslación atrás',
            'DB112,X144.2': 'Visualización-Presencia delantera de paleta en entrada',
            'DB112,X144.3': 'Visualización-Presencia trasera de paleta en entrada',
            'DB112,X144.4': 'Visualización-Presencia delantera de paleta en salida',
            'DB112,X144.5': 'Visualización-Presencia trasera de paleta en salida',
            'DB112,X144.6': 'Sin descripción',
            'DB112,X144.7': 'Sin descripción',
            'DB112,X145.0': 'Visualización-Marcha traslación adelante',
            'DB112,X145.1': 'Visualización-Marcha traslación atrás',
            'DB112,X145.2': 'Visualización-Motor traslación parado',
            'DB112,X145.3': 'Visualización-Centraje traslación',
            'DB112,X145.4': 'Visualización-Marcha transportador entrada',
            'DB112,X145.5': 'Visualización-Marcha transportador salida',
            'DB112,X145.6': 'Visualización-Defecto traslación',
            'DB112,X145.7': 'Visualización-Defecto transportador'
          };
          
          // Organizar los valores por categorías
          const categorizedValues = {
            status: {},
            autorizaciones: {},
            matriculas: {},
            pasillos: {},
            defectos: {},
            visualizacion: {}
          };
          
          // Procesar cada valor
          for (const [address, value] of Object.entries(values)) {
            const description = descriptions[address] || 'Sin descripción';
            namedValues[description] = value;
            
            // Categorizar valores
            if (description.startsWith('Status-')) {
              categorizedValues.status[description] = value;
            } else if (description.startsWith('Autorización') || description.startsWith('Petición') || description.startsWith('Fin de transferencia') || description.startsWith('Acuse')) {
              categorizedValues.autorizaciones[description] = value;
            } else if (description.startsWith('Matrícula')) {
              categorizedValues.matriculas[description] = value;
            } else if (description.startsWith('Pasillo') || description.startsWith('Ciclo') || description.startsWith('Numero') || description.startsWith('Estado carro')) {
              categorizedValues.pasillos[description] = value;
            } else if (description.startsWith('Defecto-')) {
              categorizedValues.defectos[description] = value;
            } else if (description.startsWith('Visualización')) {
              categorizedValues.visualizacion[description] = value;
            }
          }
          
          // Mostrar los valores leídos
          console.log('==== VALORES LEÍDOS DEL PLC (DB112) ====');
          console.log(JSON.stringify(values, null, 2));
          console.log('=======================================');
          
          // Mostrar los valores con nombres
          console.log('==== VALORES CON NOMBRES ====');
          console.log(JSON.stringify(namedValues, null, 2));
          console.log('============================');
          
          // Mostrar los valores categorizados
          console.log('==== VALORES CATEGORIZADOS ====');
          console.log(JSON.stringify(categorizedValues, null, 2));
          console.log('==============================');
          
          resolve(values);
        });
      }
    );
  });
}

// Función principal
async function main() {
  try {
    console.log('Iniciando lectura de variables del DB112...');
    
    // Leer datos del PLC
    await readPLCData();
    
    console.log('Lectura completada con éxito');
  } catch (err) {
    console.error('Error en la lectura:', err);
  }
}

// Ejecutar la función principal
main();
