// Script para probar alarmas simultáneas en CT y TLV1
require('dotenv').config();
const { query } = require('./src/db/mariadb-config');

async function testAllAlarms() {
  try {
    console.log('Simulando alarmas activas en CT y TLV1 simultáneamente...');
    
    // Activar 2 alarmas en CT
    const updateCTSql = `
      UPDATE CT_Alarmas 
      SET 
        error_comunicacion = 1,
        anomalia_variador = 1,
        timestamp = CURRENT_TIMESTAMP
      WHERE id = (SELECT id FROM CT_Alarmas ORDER BY id DESC LIMIT 1)
    `;
    
    await query(updateCTSql);
    console.log('Alarmas CT activadas: error_comunicacion, anomalia_variador');
    
    // Activar 2 alarmas en TLV1
    const updateTLV1Sql = `
      UPDATE TLV1_Alarmas 
      SET 
        EMERGENCIA_GENERAL = TRUE,
        PUERTA_CABINA_ABIERTA = TRUE,
        timestamp = CURRENT_TIMESTAMP
      WHERE id = (SELECT id FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1)
    `;
    
    await query(updateTLV1Sql);
    console.log('Alarmas TLV1 activadas: EMERGENCIA_GENERAL, PUERTA_CABINA_ABIERTA');
    
    // Consultar el estado actual de las alarmas CT
    const selectCTSql = `SELECT * FROM CT_Alarmas ORDER BY id DESC LIMIT 1`;
    const ctResult = await query(selectCTSql);
    
    console.log('Estado actual de las alarmas CT:');
    console.log(JSON.stringify(ctResult[0], null, 2));
    
    // Consultar el estado actual de las alarmas TLV1
    const selectTLV1Sql = `SELECT * FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1`;
    const tlv1Result = await query(selectTLV1Sql);
    
    console.log('Estado actual de las alarmas TLV1:');
    console.log(JSON.stringify(tlv1Result[0], null, 2));
    
    // Esperar 60 segundos y luego desactivar todas las alarmas
    console.log('Esperando 60 segundos antes de desactivar las alarmas...');
    setTimeout(async () => {
      // Desactivar alarmas CT
      const resetCTSql = `
        UPDATE CT_Alarmas 
        SET 
          error_comunicacion = 0,
          emergencia_armario_carro = 0,
          anomalia_variador = 0,
          anomalia_motor_traslacion = 0,
          anomalia_motor_entrada = 0,
          anomalia_motor_salida = 0,
          final_carrera_pasillo_1 = 0,
          final_carrera_pasillo_12 = 0,
          paleta_descentrada_transfer_entrada = 0,
          paleta_descentrada_transfer_salida = 0,
          limite_inferior_lectura_encoder = 0,
          limite_superior_lectura_encoder = 0,
          tiempo_transferencia_mesa_salida_carro = 0,
          telemetro = 0,
          tiempo_entrada = 0,
          tiempo_salida = 0,
          paleta_entrada_sin_codigo = 0,
          paleta_salida_sin_codigo = 0,
          timestamp = CURRENT_TIMESTAMP
        WHERE id = (SELECT id FROM CT_Alarmas ORDER BY id DESC LIMIT 1)
      `;
      
      await query(resetCTSql);
      console.log('Alarmas CT desactivadas');
      
      // Desactivar alarmas TLV1
      const resetTLV1Sql = `
        UPDATE TLV1_Alarmas 
        SET 
          EMERGENCIA_GENERAL = FALSE,
          PUERTA_CABINA_ABIERTA = FALSE,
          EXCESO_RECORRIDO_ADELANTE = FALSE,
          EXCESO_RECORRIDO_ATRAS = FALSE,
          EXCESO_RECORRIDO_SUBIDA = FALSE,
          EXCESO_RECORRIDO_BAJADA = FALSE,
          PARACAIDAS_ELEVACION = FALSE,
          CABLES_FLOJOS_ELEVACION = FALSE,
          PROTECCION_CONVERTIDOR_TRASLACION = FALSE,
          PROTECCION_CONVERTIDOR_ELEVACION = FALSE,
          PROTECCION_CONVERTIDOR_HORQUILLAS = FALSE,
          PROTECCION_MOTOR_TRASLACION = FALSE,
          PROTECCION_MOTOR_ELEVACION = FALSE,
          PROTECCION_MOTOR_HORQUILLAS = FALSE,
          DEFECTO_CONVERTIDOR_TRASLACION = FALSE,
          DEFECTO_CONVERTIDOR_ELEVACION = FALSE,
          DEFECTO_CONVERTIDOR_HORQUILLAS = FALSE,
          EXCESO_VELOCIDAD_TRASLACION = FALSE,
          EXCESO_VELOCIDAD_ELEVACION = FALSE,
          DEFECTO_FOTOCELLULAS_DE_CENTRAJE_HORQUILLAS = FALSE,
          DEFECTO_GIRO_TRASLACION = FALSE,
          DEFECTO_GIRO_ELEVACION = FALSE,
          DEFECTO_GIRO_HORQUILLAS = FALSE,
          TIEMPO_CENTRAJE_TRASLACION = FALSE,
          TIEMPO_CENTRAJE_ELEVACION = FALSE,
          TIEMPO_CICLO_HORQUILLAS = FALSE,
          TIEMPO_CICLO_TOPE_DE_SEGURIDAD = FALSE,
          DEFECTO_DETECTORES_TRASLACION = FALSE,
          DEFECTO_DETECTORES_ELEVACION = FALSE,
          DEFECTO_DETECTORES_HORQUILLAS = FALSE,
          DEFECTO_DETECTORES_TOPE_DE_SEGURIDAD = FALSE,
          DEFECTO_IMPULSOR_ENCODER_TRASLACION = FALSE,
          DEFECTO_IMPULSOR_ENCODER_ELEVACION = FALSE,
          DEFECTO_IMPULSOR_ENCODER_HORQUILLAS = FALSE,
          CONTADOR_IMPULSOR_ENCODER_TRASL_DESFASADO = FALSE,
          CONTADOR_IMPULSOR_ENCODER_ELEV_DESFASADO = FALSE,
          DEFECTO_COMUNICACION_PERIFERIA = FALSE,
          DEFECTO_FOTOCELLULAS_DE_CENTRAJE_TRASLACION = FALSE,
          DEFECTOS_DETECTORES_LECTURA_PASILLO = FALSE,
          DEFECTO_CHOPPER_FRENADO_ELEVACION = FALSE,
          DEFECTO_DE_GALIBO = FALSE,
          DEFECTO_PRESENCIA_DE_PALETA = FALSE,
          DEF_FOTOCELLULAS_PALPADORAS = FALSE,
          DEF_FOTOC_PUERTA_CERRADO = FALSE,
          PASILLO_FUERA_DE_SERVICIO = FALSE,
          timestamp = CURRENT_TIMESTAMP
        WHERE id = (SELECT id FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1)
      `;
      
      await query(resetTLV1Sql);
      console.log('Alarmas TLV1 desactivadas');
      
      // Consultar el estado actualizado
      const updatedCTResult = await query(selectCTSql);
      console.log('Estado actualizado de las alarmas CT:');
      console.log(JSON.stringify(updatedCTResult[0], null, 2));
      
      const updatedTLV1Result = await query(selectTLV1Sql);
      console.log('Estado actualizado de las alarmas TLV1:');
      console.log(JSON.stringify(updatedTLV1Result[0], null, 2));
      
      process.exit(0);
    }, 60000);
  } catch (error) {
    console.error('Error al probar las alarmas:', error);
    process.exit(1);
  }
}

// Ejecutar la función
testAllAlarms();
