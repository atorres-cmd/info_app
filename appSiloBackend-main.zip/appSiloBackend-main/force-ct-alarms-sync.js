// Script para forzar la sincronización de alarmas del Carro Transferidor (CT) con datos reales del PLC
require('dotenv').config();
const { query } = require('./src/db/mariadb-config');
const nodes7 = require('nodes7');
const { logger } = require('./src/utils/logger');

async function syncCTAlarms() {
  try {
    console.log('Forzando sincronización de alarmas del Carro Transferidor (CT) con datos reales del PLC...');
    
    // Crear una conexión al PLC y leer los datos del DB111
    const conn = new nodes7();
    
    // Configuración de conexión al PLC
    const connectionParams = {
      host: process.env.PLC_IP || '10.21.178.100',
      port: 102,
      rack: parseInt(process.env.PLC_RACK || '0'),
      slot: parseInt(process.env.PLC_SLOT || '3'),
      timeout: 5000
    };
    
    // Variables de defectos a leer
    const defectVariables = {
      'DB111,X60.0': 'error_comunicacion',
      'DB111,X60.1': 'emergencia_armario_carro',
      'DB111,X60.2': 'anomalia_variador',
      'DB111,X60.3': 'anomalia_motor_traslacion',
      'DB111,X60.4': 'anomalia_motor_entrada',
      'DB111,X60.5': 'anomalia_motor_salida',
      'DB111,X60.6': 'final_carrera_pasillo_1',
      'DB111,X60.7': 'final_carrera_pasillo_12',
      'DB111,X60.8': 'paleta_descentrada_transfer_entrada',
      'DB111,X60.9': 'paleta_descentrada_transfer_salida',
      'DB111,X62.0': 'limite_inferior_lectura_encoder',
      'DB111,X62.1': 'limite_superior_lectura_encoder',
      'DB111,X62.2': 'tiempo_transferencia_mesa_salida_carro',
      'DB111,X62.3': 'telemetro',
      'DB111,X64.0': 'tiempo_entrada',
      'DB111,X64.1': 'tiempo_salida',
      'DB111,X64.2': 'paleta_entrada_sin_codigo',
      'DB111,X64.3': 'paleta_salida_sin_codigo'
    };
    
    // Leer los datos del PLC
    const plcData = await new Promise((resolve, reject) => {
      // Conectar al PLC
      conn.initiateConnection(connectionParams, (err) => {
        if (err) {
          console.error('Error al conectar con el PLC para leer defectos:', err);
          reject(err);
          return;
        }
        
        console.log('Conexión establecida con el PLC');
        
        // Extraer las direcciones de las variables
        const variableAddresses = Object.keys(defectVariables);
        
        // Añadir variables para leer
        conn.addItems(variableAddresses);
        
        // Leer todas las variables
        conn.readAllItems((err, values) => {
          // Desconectar del PLC después de leer
          conn.dropConnection(() => {
            console.log('Desconectado del PLC después de leer valores de defectos');
          });
          
          if (err) {
            console.error('Error al leer valores de defectos del PLC:', err);
            reject(err);
            return;
          }
          
          // Verificar si los valores del PLC son válidos
          const hasValidValues = Object.values(values).some(value => 
            value !== null && value !== undefined);
          
          if (hasValidValues) {
            console.log('Valores de defectos leídos correctamente del PLC');
            console.log('Datos leídos:', values);
            resolve(values);
          } else {
            reject(new Error('No se obtuvieron valores válidos de defectos del PLC'));
          }
        });
      });
    });
    
    // Preparar los valores para la consulta SQL
    const values = {};
    
    // Convertir los datos del PLC a valores booleanos
    for (const [address, fieldName] of Object.entries(defectVariables)) {
      values[fieldName] = Boolean(plcData[address]);
    }
    
    console.log('Valores formateados para la base de datos:', values);
    
    // Verificar si la tabla tiene registros
    const checkTableSql = `
      SELECT COUNT(*) as count 
      FROM CT_Alarmas
    `;
    
    const [checkResult] = await query(checkTableSql);
    
    if (checkResult.count === 0) {
      // No hay registros, insertar uno nuevo
      const fields = Object.keys(values).join(', ');
      const placeholders = Object.keys(values).map(() => '?').join(', ');
      
      const insertSql = `
        INSERT INTO CT_Alarmas (${fields})
        VALUES (${placeholders})
      `;
      
      await query(insertSql, Object.values(values));
      console.log('Primer registro insertado en la tabla CT_Alarmas con datos reales del PLC');
    } else {
      // Actualizar el registro existente (el más reciente)
      const setClause = Object.keys(values)
        .map(field => `${field} = ?`)
        .join(', ');
      
      const updateSql = `
        UPDATE CT_Alarmas 
        SET ${setClause}, timestamp = CURRENT_TIMESTAMP
        WHERE id = (SELECT id FROM CT_Alarmas ORDER BY id DESC LIMIT 1)
      `;
      
      await query(updateSql, Object.values(values));
      console.log('Registro actualizado en la tabla CT_Alarmas con datos reales del PLC');
    }
    
    // Consultar los datos actualizados
    const selectSql = `SELECT * FROM CT_Alarmas ORDER BY id DESC LIMIT 1`;
    const selectResult = await query(selectSql);
    
    console.log('Datos actualizados en la tabla CT_Alarmas:');
    console.log(JSON.stringify(selectResult, null, 2));
    
    console.log('Sincronización de alarmas del Carro Transferidor (CT) completada con éxito.');
    
    // Si se ejecuta como script independiente, salir del proceso
    if (require.main === module) {
      process.exit(0);
    }
    
    return selectResult;
  } catch (error) {
    console.error('Error al sincronizar alarmas del Carro Transferidor (CT):', error);
    
    // Si se ejecuta como script independiente, salir del proceso
    if (require.main === module) {
      process.exit(1);
    }
    
    throw error;
  }
}

// Exportar la función para que pueda ser utilizada por otros módulos
module.exports = {
  syncCTAlarms
};

// Ejecutar la función principal solo si se llama directamente
if (require.main === module) {
  syncCTAlarms();
}
