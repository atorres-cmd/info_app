// Script para probar las alarmas del Transelevador 1 (TLV1)
require('dotenv').config();
const { query } = require('./src/db/mariadb-config');

async function testTLV1Alarms() {
  try {
    console.log('Simulando alarmas activas del Transelevador 1 (TLV1)...');
    
    // Verificar si existe algún registro en la tabla
    const checkSql = `SELECT COUNT(*) as count FROM TLV1_Alarmas`;
    const checkResult = await query(checkSql);
    
    // Si no hay registros, crear uno nuevo
    if (checkResult[0].count === 0) {
      console.log('No hay registros en la tabla TLV1_Alarmas. Creando uno nuevo...');
      const insertSql = `INSERT INTO TLV1_Alarmas (timestamp) VALUES (CURRENT_TIMESTAMP)`;
      await query(insertSql);
      console.log('Registro creado correctamente.');
    }
    
    // Activar varias alarmas (poner valores en TRUE)
    const updateSql = `
      UPDATE TLV1_Alarmas 
      SET 
        EMERGENCIA_GENERAL = TRUE,
        PUERTA_CABINA_ABIERTA = TRUE,
        DEFECTO_CONVERTIDOR_TRASLACION = TRUE,
        EXCESO_RECORRIDO_ADELANTE = TRUE,
        EXCESO_RECORRIDO_ATRAS = TRUE,
        PARACAIDAS_ELEVACION = TRUE,
        DEFECTO_GIRO_TRASLACION = TRUE,
        timestamp = CURRENT_TIMESTAMP
      WHERE id = (SELECT id FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1)
    `;
    
    await query(updateSql);
    console.log('Alarmas activadas: EMERGENCIA_GENERAL, PUERTA_CABINA_ABIERTA, DEFECTO_CONVERTIDOR_TRASLACION, EXCESO_RECORRIDO_ADELANTE, EXCESO_RECORRIDO_ATRAS, PARACAIDAS_ELEVACION, DEFECTO_GIRO_TRASLACION');
    
    // Consultar el estado actual
    const selectSql = `SELECT * FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1`;
    const result = await query(selectSql);
    
    console.log('Estado actual de las alarmas:');
    console.log(JSON.stringify(result[0], null, 2));
    
    // Esperar 60 segundos y luego desactivar las alarmas
    console.log('Esperando 60 segundos antes de desactivar las alarmas...');
    setTimeout(async () => {
      // Desactivar todas las alarmas (poner valores en FALSE)
      const resetSql = `
        UPDATE TLV1_Alarmas 
        SET 
          EMERGENCIA_GENERAL = FALSE,
          PUERTA_CABINA_ABIERTA = FALSE,
          EXCESO_RECORRIDO_ADELANTE = FALSE,
          EXCESO_RECORRIDO_ATRAS = FALSE,
          EXCESO_RECORRIDO_SUBIDA = FALSE,
          EXCESO_RECORRIDO_BAJADA = FALSE,
          PARACAIDAS_ELEVACION = FALSE,
          CABLES_FLOJOS_ELEVACION = FALSE,
          PROTECCION_CONVERTIDOR_TRASLACION = FALSE,
          PROTECCION_CONVERTIDOR_ELEVACION = FALSE,
          PROTECCION_CONVERTIDOR_HORQUILLAS = FALSE,
          PROTECCION_MOTOR_TRASLACION = FALSE,
          PROTECCION_MOTOR_ELEVACION = FALSE,
          PROTECCION_MOTOR_HORQUILLAS = FALSE,
          DEFECTO_CONVERTIDOR_TRASLACION = FALSE,
          DEFECTO_CONVERTIDOR_ELEVACION = FALSE,
          DEFECTO_CONVERTIDOR_HORQUILLAS = FALSE,
          EXCESO_VELOCIDAD_TRASLACION = FALSE,
          EXCESO_VELOCIDAD_ELEVACION = FALSE,
          DEFECTO_FOTOCELLULAS_DE_CENTRAJE_HORQUILLAS = FALSE,
          DEFECTO_GIRO_TRASLACION = FALSE,
          DEFECTO_GIRO_ELEVACION = FALSE,
          DEFECTO_GIRO_HORQUILLAS = FALSE,
          TIEMPO_CENTRAJE_TRASLACION = FALSE,
          TIEMPO_CENTRAJE_ELEVACION = FALSE,
          TIEMPO_CICLO_HORQUILLAS = FALSE,
          TIEMPO_CICLO_TOPE_DE_SEGURIDAD = FALSE,
          DEFECTO_DETECTORES_TRASLACION = FALSE,
          DEFECTO_DETECTORES_ELEVACION = FALSE,
          DEFECTO_DETECTORES_HORQUILLAS = FALSE,
          DEFECTO_DETECTORES_TOPE_DE_SEGURIDAD = FALSE,
          DEFECTO_IMPULSOR_ENCODER_TRASLACION = FALSE,
          DEFECTO_IMPULSOR_ENCODER_ELEVACION = FALSE,
          DEFECTO_IMPULSOR_ENCODER_HORQUILLAS = FALSE,
          CONTADOR_IMPULSOR_ENCODER_TRASL_DESFASADO = FALSE,
          CONTADOR_IMPULSOR_ENCODER_ELEV_DESFASADO = FALSE,
          DEFECTO_COMUNICACION_PERIFERIA = FALSE,
          DEFECTO_FOTOCELLULAS_DE_CENTRAJE_TRASLACION = FALSE,
          DEFECTOS_DETECTORES_LECTURA_PASILLO = FALSE,
          DEFECTO_CHOPPER_FRENADO_ELEVACION = FALSE,
          DEFECTO_DE_GALIBO = FALSE,
          DEFECTO_PRESENCIA_DE_PALETA = FALSE,
          DEF_FOTOCELLULAS_PALPADORAS = FALSE,
          DEF_FOTOC_PUERTA_CERRADO = FALSE,
          PASILLO_FUERA_DE_SERVICIO = FALSE,
          timestamp = CURRENT_TIMESTAMP
        WHERE id = (SELECT id FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1)
      `;
      
      await query(resetSql);
      console.log('Todas las alarmas han sido desactivadas');
      
      // Consultar el estado actualizado
      const updatedResult = await query(selectSql);
      console.log('Estado actualizado de las alarmas:');
      console.log(JSON.stringify(updatedResult[0], null, 2));
      
      process.exit(0);
    }, 60000);
  } catch (error) {
    console.error('Error al probar las alarmas del TLV1:', error);
    process.exit(1);
  }
}

// Ejecutar la función
testTLV1Alarms();
