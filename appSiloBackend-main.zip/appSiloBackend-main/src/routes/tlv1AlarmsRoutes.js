// Rutas para las alarmas del Transelevador 1 (TLV1)
const express = require('express');
const router = express.Router();
const { query } = require('../db/mariadb-config');
const { syncTLV1Alarms } = require('../../force-tlv1-alarms-sync');
const { logger } = require('../utils/logger');

// Obtener todas las alarmas del TLV1
router.get('/', async (req, res) => {
  try {
    const sql = `SELECT * FROM TLV1_Alarmas ORDER BY timestamp DESC`;
    const results = await query(sql);
    
    res.json({
      success: true,
      data: results
    });
  } catch (error) {
    logger.error(`Error al obtener alarmas TLV1: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Obtener alarmas activas del TLV1
router.get('/active', async (req, res) => {
  try {
    // Obtener el registro más reciente
    const sql = `
      SELECT * FROM TLV1_Alarmas 
      ORDER BY timestamp DESC 
      LIMIT 1
    `;
    
    const [latestRecord] = await query(sql);
    
    if (!latestRecord) {
      return res.json({
        success: true,
        data: []
      });
    }
    
    // Filtrar solo los campos de alarmas que están activos
    const activeAlarms = [];
    const timestamp = latestRecord.timestamp;
    
    // Recorrer todas las propiedades del registro
    for (const [key, value] of Object.entries(latestRecord)) {
      // Solo procesar campos de alarmas (ignorar id, timestamp, acknowledged, resolved)
      if (key !== 'id' && key !== 'timestamp' && key !== 'acknowledged' && key !== 'resolved' && value === 1) {
        // Crear un objeto de alarma para cada alarma activa
        activeAlarms.push({
          id: `tlv1-${key}`,
          deviceId: 'TLV1',
          deviceName: 'Transelevador 1',
          message: key.replace(/_/g, ' '), // Convertir EXCESO_RECORRIDO_ADELANTE a "EXCESO RECORRIDO ADELANTE"
          severity: key.includes('EMERGENCIA') || key.includes('ERROR') ? 'critical' : 'warning',
          timestamp: timestamp,
          acknowledged: Boolean(latestRecord.acknowledged)
        });
      }
    }
    
    res.json({
      success: true,
      data: activeAlarms
    });
  } catch (error) {
    logger.error(`Error al obtener alarmas activas TLV1: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Obtener historial de alarmas TLV1
router.get('/history', async (req, res) => {
  try {
    const sql = `SELECT * FROM TLV1_Alarmas ORDER BY timestamp DESC LIMIT 50`;
    const results = await query(sql);
    
    res.json({
      success: true,
      data: results
    });
  } catch (error) {
    logger.error(`Error al obtener historial de alarmas TLV1: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Forzar sincronización de alarmas TLV1
router.post('/sync', async (req, res) => {
  try {
    logger.info('Solicitud de sincronización manual de alarmas TLV1 recibida');
    
    // Ejecutar sincronización
    await syncTLV1Alarms();
    
    res.json({
      success: true,
      message: 'Sincronización de alarmas TLV1 completada'
    });
  } catch (error) {
    logger.error(`Error al sincronizar alarmas TLV1: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;
