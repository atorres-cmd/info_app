// src/routes/mesasEntradaRoutes.js
const express = require('express');
const mesasEntradaController = require('../controllers/mesasEntradaMariaDBController');

const router = express.Router();

// Ruta para obtener los datos actuales de las mesas de entrada desde MariaDB
router.get('/status', mesasEntradaController.getMesasEntradaStatus.bind(mesasEntradaController));

// Ruta para sincronizar manualmente los datos de las mesas de entrada con MariaDB
router.post('/sync', mesasEntradaController.syncPLCToDatabase.bind(mesasEntradaController));

module.exports = router;
