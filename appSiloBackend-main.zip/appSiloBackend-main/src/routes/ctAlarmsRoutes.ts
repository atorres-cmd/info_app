// src/routes/ctAlarmsRoutes.ts
import express from 'express';
import ctAlarmsController from '../controllers/ctAlarmsController';

// Crear router
const router = express.Router();

// Ruta para obtener las alarmas actuales
router.get('/', (req, res) => ctAlarmsController.getAlarms(req, res));

// Ruta para obtener solo las alarmas activas
router.get('/active', (req, res) => ctAlarmsController.getActiveAlarms(req, res));

// Ruta para obtener el historial de alarmas
router.get('/history', (req, res) => ctAlarmsController.getAlarmsHistory(req, res));

// Ruta para sincronizar manualmente las alarmas
router.post('/sync', (req, res) => ctAlarmsController.syncAlarms(req, res));

// Exportar el router directamente
export default router;
