// src/routes/mesasEntradaRoutes.ts
import { Router } from 'express';
const mesasEntradaController = require('../controllers/mesasEntradaMariaDBController');

const router = Router();

// Ruta para obtener los datos actuales de las mesas de entrada desde MariaDB
router.get('/status', mesasEntradaController.getMesasEntradaStatus.bind(mesasEntradaController));

// Ruta para sincronizar manualmente los datos de las mesas de entrada con MariaDB
router.post('/sync', mesasEntradaController.syncPLCToDatabase.bind(mesasEntradaController));

export default router;
