// src/routes/pasRoutes.ts
import { Router } from 'express';
const pasController = require('../controllers/pasMariaDBController');

const router = Router();

// Ruta para obtener los datos actuales de los pasillos desde MariaDB
router.get('/status', pasController.getPasStatus.bind(pasController));

// Ruta para sincronizar manualmente los datos de los pasillos con MariaDB
router.post('/sync', pasController.syncPLCToDatabase.bind(pasController));

export default router;
