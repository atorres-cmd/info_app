// Rutas para acceder directamente a las tablas de MariaDB
const express = require('express');
const { query } = require('../db/mariadb-config');
const router = express.Router();

// Obtener todos los registros de una tabla
router.get('/:tableName', async (req, res) => {
  try {
    const { tableName } = req.params;
    const { limit = 100 } = req.query;
    
    // Validar el nombre de la tabla para evitar inyección SQL
    const validTables = ['TLV1_Status', 'TLV2_Status', 'PT_Status', 'CT_Status', 'CT_Alarmas'];
    if (!validTables.includes(tableName)) {
      return res.status(400).json({
        success: false,
        message: `Tabla no válida. Tablas permitidas: ${validTables.join(', ')}`
      });
    }
    
    const sql = `SELECT * FROM ${tableName} ORDER BY id DESC LIMIT ${parseInt(limit)}`;
    const rows = await query(sql);
    
    res.json({
      success: true,
      data: rows
    });
  } catch (error) {
    console.error(`Error al obtener datos de la tabla:`, error);
    res.status(500).json({
      success: false,
      message: 'Error al consultar la base de datos',
      error: error.message
    });
  }
});

// Obtener el último registro de una tabla
router.get('/:tableName/latest', async (req, res) => {
  try {
    const { tableName } = req.params;
    
    // Validar el nombre de la tabla para evitar inyección SQL
    const validTables = ['TLV1_Status', 'TLV2_Status', 'PT_Status', 'CT_Status', 'CT_Alarmas'];
    if (!validTables.includes(tableName)) {
      return res.status(400).json({
        success: false,
        message: `Tabla no válida. Tablas permitidas: ${validTables.join(', ')}`
      });
    }
    
    const sql = `SELECT * FROM ${tableName} ORDER BY id DESC LIMIT 1`;
    const rows = await query(sql);
    
    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No se encontraron registros en la tabla ${tableName}`
      });
    }
    
    res.json({
      success: true,
      data: rows[0]
    });
  } catch (error) {
    console.error(`Error al obtener el último registro de la tabla:`, error);
    res.status(500).json({
      success: false,
      message: 'Error al consultar la base de datos',
      error: error.message
    });
  }
});

module.exports = router;
