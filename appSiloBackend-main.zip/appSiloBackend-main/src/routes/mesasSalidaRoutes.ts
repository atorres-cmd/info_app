// src/routes/mesasSalidaRoutes.ts
import { Router } from 'express';
const mesasSalidaController = require('../controllers/mesasSalidaMariaDBController');

const router = Router();

// Ruta para obtener los datos actuales de las mesas de salida desde MariaDB
router.get('/status', mesasSalidaController.getMesasSalidaStatus.bind(mesasSalidaController));

// Ruta para sincronizar manualmente los datos de las mesas de salida con MariaDB
router.post('/sync', mesasSalidaController.syncPLCToDatabase.bind(mesasSalidaController));

export default router;
