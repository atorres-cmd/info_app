// src/routes/db112Routes.ts
import { Router } from 'express';
import { Request, Response } from 'express';
import { DB112Controller } from '../controllers/db112Controller';

const createDB112Routes = () => {
  const router = Router();
  
  // Crear una instancia del controlador DB112
  const db112Controller = new DB112Controller();
  
  // Configurar la sincronización programada (cada 5 segundos)
  db112Controller.setupScheduledSync(5);
  
  // Ruta para leer datos del DB112
  router.get('/read', (req: Request, res: Response) => {
    db112Controller.getDB112Status(req, res);
  });
  
  return router;
};

export default createDB112Routes;
