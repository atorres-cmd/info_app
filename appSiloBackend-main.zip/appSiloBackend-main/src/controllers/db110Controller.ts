// src/controllers/db110Controller.ts
import { Request, Response } from 'express';
import { logger } from '../utils/logger';
import { query } from '../db/mariadb-config';

// Importar nodes7 de forma dinámica para evitar problemas de tipado
const nodes7 = require('nodes7');

// Interfaz para el servicio PLC
interface PLCServiceInterface {
  readAllItems?(): Promise<Record<string, any>>;
  writeItem?(address: string, value: any): Promise<boolean> | boolean;
}

export class DB110Controller {
  private service: PLCServiceInterface;

  constructor(service?: PLCServiceInterface) {
    this.service = service || {};
    
    // Inicializar tablas al crear la instancia
    this.initMesasEntradaTable()
      .then(() => {
        logger.info('Tabla MesasEntrada_Status inicializada correctamente');
        // Configurar sincronización automática cada 30 segundos para mesas de entrada
        this.setupMesasEntradaScheduledSync(30);
      })
      .catch((error: Error) => {
        logger.error('Error al inicializar la tabla MesasEntrada_Status:', error);
      });
      
    this.initMesasSalidaTable()
      .then(() => {
        logger.info('Tabla MesasSalida_Status inicializada correctamente');
        // Configurar sincronización automática cada 30 segundos para mesas de salida
        this.setupMesasSalidaScheduledSync(30);
      })
      .catch((error: Error) => {
        logger.error('Error al inicializar la tabla MesasSalida_Status:', error);
      });
  }
  
  // Métodos para mesas de entrada
  public getMesasEntradaStatus = async (req: Request, res: Response): Promise<void> => {
    try {
      // Obtener datos de la tabla MesasEntrada_Status
      const result = await query('SELECT * FROM MesasEntrada_Status WHERE id = 1');
      
      if (result && result.length > 0) {
        const mesasData = result[0];
        console.log('Datos de mesas de entrada encontrados:', JSON.stringify(mesasData, null, 2));
        res.json(mesasData);
      } else {
        console.log('No se encontraron datos de mesas de entrada en la base de datos');
        res.status(404).json({
          success: false,
          message: 'No se encontraron datos de mesas de entrada'
        });
      }
    } catch (error) {
      logger.error('Error al obtener datos de mesas de entrada desde MariaDB:', error);
      console.error('Error completo:', error);
      res.status(500).json({
        success: false,
        message: 'Error al obtener datos de mesas de entrada',
        error: (error as Error).message
      });
    }
  }
  
  public syncMesasEntradaToDatabase = async (req: Request, res: Response): Promise<void> => {
    try {
      // Leer datos del PLC para mesas de entrada
      const plcData = await this.readMesasEntradaPLCData();
      
      if (!plcData) {
        res.status(500).json({
          success: false,
          message: 'No se pudieron leer los datos de mesas de entrada del PLC'
        });
        return;
      }
      
      // Convertir datos del PLC al formato de la tabla MesasEntrada_Status
      const dbData = this.convertMesasEntradaToDBFormat(plcData);
      
      // Guardar datos en la base de datos
      await this.saveMesasEntradaToDatabase(dbData);
      
      // Responder con los datos guardados
      res.json({
        success: true,
        message: 'Datos de mesas de entrada sincronizados correctamente',
        data: dbData
      });
    } catch (error) {
      logger.error('Error al sincronizar datos de mesas de entrada con MariaDB:', error);
      res.status(500).json({
        success: false,
        message: 'Error al sincronizar datos de mesas de entrada',
        error: (error as Error).message
      });
    }
  }
  
  // Métodos para mesas de salida
  public getMesasSalidaStatus = async (req: Request, res: Response): Promise<void> => {
    try {
      // Obtener datos de la tabla MesasSalida_Status
      const result = await query('SELECT * FROM MesasSalida_Status WHERE id = 1');
      
      if (result && result.length > 0) {
        const mesasData = result[0];
        console.log('Datos de mesas de salida encontrados:', JSON.stringify(mesasData, null, 2));
        res.json(mesasData);
      } else {
        console.log('No se encontraron datos de mesas de salida en la base de datos');
        res.status(404).json({
          success: false,
          message: 'No se encontraron datos de mesas de salida'
        });
      }
    } catch (error) {
      logger.error('Error al obtener datos de mesas de salida desde MariaDB:', error);
      console.error('Error completo:', error);
      res.status(500).json({
        success: false,
        message: 'Error al obtener datos de mesas de salida',
        error: (error as Error).message
      });
    }
  }
  
  public syncMesasSalidaToDatabase = async (req: Request, res: Response): Promise<void> => {
    try {
      // Leer datos del PLC para mesas de salida
      const plcData = await this.readMesasSalidaPLCData();
      
      if (!plcData) {
        res.status(500).json({
          success: false,
          message: 'No se pudieron leer los datos de mesas de salida del PLC'
        });
        return;
      }
      
      // Convertir datos del PLC al formato de la tabla MesasSalida_Status
      const dbData = this.convertMesasSalidaToDBFormat(plcData);
      
      // Guardar datos en la base de datos
      await this.saveMesasSalidaToDatabase(dbData);
      
      // Responder con los datos guardados
      res.json({
        success: true,
        message: 'Datos de mesas de salida sincronizados correctamente',
        data: dbData
      });
    } catch (error) {
      logger.error('Error al sincronizar datos de mesas de salida con MariaDB:', error);
      res.status(500).json({
        success: false,
        message: 'Error al sincronizar datos de mesas de salida',
        error: (error as Error).message
      });
    }
  }

  // Obtener todos los valores del DB110 (Puente Transferidor)
  public getAllValues = async (req: Request, res: Response): Promise<void> => {
    try {
      // Forzar la lectura directa de valores del PLC real
      const conn = new nodes7();

      // Configuración de conexión al PLC
      const connectionParams = {
        host: process.env.PLC_IP || '10.21.178.100',
        port: 102,
        rack: parseInt(process.env.PLC_RACK || '0'),
        slot: parseInt(process.env.PLC_SLOT || '3'),
        timeout: 5000
      };

      // Intentar leer valores reales del PLC
      try {
        // Crear una promesa para manejar la conexión asíncrona
        const plcValues = await new Promise<Record<string, any>>((resolve, reject) => {
          // Conectar al PLC
          conn.initiateConnection(connectionParams, (err: any) => {
            if (err) {
              logger.error('Error al conectar con el PLC para DB110:', err);
              reject(err);
              return;
            }

            // Añadir variables para leer - Específicas del Puente Transferidor
            conn.addItems(['DB110,B30', 'DB110,B31', 'DB110,B32', 'DB110,B33']);

            // Leer todas las variables
            conn.readAllItems((err: any, values: Record<string, any>) => {
              // Desconectar del PLC después de leer
              conn.dropConnection(() => {
                logger.info('Desconectado del PLC después de leer valores del Puente Transferidor');
              });

              if (err) {
                logger.error('Error al leer valores del PLC para DB110:', err);
                reject(err);
                return;
              }
              
              // Devolver los valores leídos
              console.log('Valores leídos del PLC para Puente Transferidor:', values);
              resolve(values);
            });
          });
        });
        
        // Verificar si los valores del PLC son válidos
        const hasValidValues = Object.values(plcValues).some(value => value !== null && value !== undefined);
        
        if (hasValidValues) {
          logger.info('Valores leídos correctamente del PLC real para Puente Transferidor');
          
          // Formatear los datos para la respuesta
          const formattedData = this.formatDB110Data(plcValues);
          
          // Mostrar algunos valores para depuración
          console.log('Enviando datos reales del Puente Transferidor al cliente:', {
            ocupacion: formattedData.ocupacion.value,
            estado: formattedData.estado.value,
            situacion: formattedData.situacion.value,
            posicion: formattedData.posicion.value
          });
          
          // Nota: Ya no sincronizamos con la tabla PT_Status desde este controlador
          // La sincronización se maneja directamente desde el controlador del puente transferidor
          
          res.json(formattedData);
          return;
        }
      } catch (plcError) {
        logger.error('Error al leer valores del PLC real para DB110:', plcError);
        logger.warn('No se pudo conectar con el PLC real para el Puente Transferidor. Asegúrese de que el PLC esté encendido y accesible.');
        
        // No hay modo simulación, devolver error
        res.status(500).json({
          success: false,
          message: 'Error al obtener datos del PLC para el Puente Transferidor',
          error: (plcError as Error).message
        });
        return;
      }
    } catch (error) {
      logger.error('Error al obtener valores del DB110:', error);
      res.status(500).json({
        success: false,
        message: 'Error al obtener datos del Puente Transferidor',
        error: (error as Error).message
      });
    }
  };

  // Formatear los datos del DB110 para la respuesta
  private formatDB110Data(values: Record<string, any>) {
    // Mapear los valores a un formato más amigable
    const mappedValues = {
      ocupacion: values['DB110,DBB30'] !== undefined ? values['DB110,DBB30'] : 0,
      estado: values['DB110,DBB31'] !== undefined ? values['DB110,DBB31'] : 0,
      situacion: values['DB110,DBB32'] !== undefined ? values['DB110,DBB32'] : 0,
      posicion: values['DB110,DBB33'] !== undefined ? values['DB110,DBB33'] : 1
    };

    // Formatear los datos con descripciones
    return {
      ocupacion: {
        value: mappedValues.ocupacion,
        description: this.getOcupacionText(mappedValues.ocupacion),
        address: 'DB110,DBB30'
      },
      estado: {
        value: mappedValues.estado,
        description: this.getEstadoText(mappedValues.estado),
        address: 'DB110,DBB31'
      },
      situacion: {
        value: mappedValues.situacion,
        description: this.getSituacionText(mappedValues.situacion),
        address: 'DB110,DBB32'
      },
      posicion: {
        value: mappedValues.posicion,
        description: `Posición ${mappedValues.posicion}`,
        address: 'DB110,DBB33'
      }
    };
  }

  // Convertir el valor según el tipo de dato esperado
  private convertValue(address: string, value: any): any {
    if (address.includes(',X')) {
      // Bit (0 o 1)
      return value ? 1 : 0;
    } else if (address.includes(',B') || address.includes(',DBB')) {
      // Byte (0-255)
      const numValue = Number(value);
      return isNaN(numValue) ? 0 : Math.min(255, Math.max(0, Math.floor(numValue)));
    } else if (address.includes(',W') || address.includes(',DBW')) {
      // Word (0-65535)
      const numValue = Number(value);
      return isNaN(numValue) ? 0 : Math.min(65535, Math.max(0, Math.floor(numValue)));
    } else {
      // Valor por defecto
      return value;
    }
  }

  // Funciones auxiliares para obtener textos descriptivos
  private getOcupacionText(ocupacion: number): string {
    switch (ocupacion) {
      case 0: return 'LIBRE';
      case 1: return 'OCUPADO';
      default: return 'DESCONOCIDO';
    }
  }

  private getEstadoText(estado: number): string {
    switch (estado) {
      case 0: return 'OK';
      case 1: return 'AVERÍA';
      default: return 'DESCONOCIDO';
    }
  }

  private getSituacionText(situacion: number): string {
    switch (situacion) {
      case 0: return 'PARADO';
      case 1: return 'EN MOVIMIENTO';
      default: return 'DESCONOCIDO';
    }
  }
  
  // Métodos auxiliares para mesas de entrada
  private async readMesasEntradaPLCData(): Promise<Record<string, any> | null> {
    const conn = new nodes7();
    
    // Configuración de conexión al PLC
    const connectionParams = {
      host: process.env.PLC_IP || '10.21.178.100',
      port: 102,
      rack: parseInt(process.env.PLC_RACK || '0'),
      slot: parseInt(process.env.PLC_SLOT || '3'),
      timeout: 5000
    };
    
    try {
      // Crear una promesa para manejar la conexión asíncrona
      return await new Promise<Record<string, any>>((resolve, reject) => {
        // Conectar al PLC
        conn.initiateConnection(connectionParams, (err: any) => {
          if (err) {
            logger.error('Error al conectar con el PLC para leer estado de mesas de entrada:', err);
            reject(err);
            return;
          }
          
          // Añadir variables para leer (estado de mesas de entrada ME1 a ME12)
          const statusMesasEntrada = [
            'DB110,B50', 'DB110,B51', 'DB110,B52', 'DB110,B53', 'DB110,B54', 
            'DB110,B55', 'DB110,B56', 'DB110,B57', 'DB110,B58', 'DB110,B59', 
            'DB110,B60', 'DB110,B61'
          ];
          
          conn.addItems(statusMesasEntrada);
          
          // Leer todas las variables
          conn.readAllItems((err: any, values: Record<string, any>) => {
            // Desconectar del PLC después de leer
            conn.dropConnection(() => {
              logger.info('Desconectado del PLC después de leer valores de mesas de entrada');
            });
            
            if (err) {
              logger.error('Error al leer valores de mesas de entrada del PLC:', err);
              reject(err);
              return;
            }
            
            // Mostrar los valores crudos exactos que se leen del PLC
            console.log('\n==== VALORES CRUDOS LEÍDOS DEL PLC (MESAS DE ENTRADA) ====');
            console.log(JSON.stringify(values, null, 2));
            console.log('===============================================\n');
            
            // Verificar si los valores del PLC son válidos
            const hasValidValues = Object.values(values).some(value => 
              value !== null && value !== undefined);
            
            if (hasValidValues) {
              resolve(values);
            } else {
              logger.warn('No se obtuvieron valores válidos del PLC para mesas de entrada');
              reject(new Error('No se obtuvieron valores válidos del PLC para mesas de entrada'));
            }
          });
        });
      });
    } catch (error) {
      logger.error('Error al leer datos de mesas de entrada del PLC:', error);
      return null;
    }
  }
  
  private convertMesasEntradaToDBFormat(plcData: Record<string, any>): any {
    // Convertir los datos del PLC al formato esperado por la tabla MesasEntrada_Status
    return {
      pep1: plcData['DB110,B50'] !== undefined ? plcData['DB110,B50'] : 0,
      pep2: plcData['DB110,B51'] !== undefined ? plcData['DB110,B51'] : 0,
      pep3: plcData['DB110,B52'] !== undefined ? plcData['DB110,B52'] : 0,
      pep4: plcData['DB110,B53'] !== undefined ? plcData['DB110,B53'] : 0,
      pep5: plcData['DB110,B54'] !== undefined ? plcData['DB110,B54'] : 0,
      pep6: plcData['DB110,B55'] !== undefined ? plcData['DB110,B55'] : 0,
      pep7: plcData['DB110,B56'] !== undefined ? plcData['DB110,B56'] : 0,
      pep8: plcData['DB110,B57'] !== undefined ? plcData['DB110,B57'] : 0,
      pep9: plcData['DB110,B58'] !== undefined ? plcData['DB110,B58'] : 0,
      pep10: plcData['DB110,B59'] !== undefined ? plcData['DB110,B59'] : 0,
      pep11: plcData['DB110,B60'] !== undefined ? plcData['DB110,B60'] : 0,
      pep12: plcData['DB110,B61'] !== undefined ? plcData['DB110,B61'] : 0
    };
  }
  
  private async saveMesasEntradaToDatabase(data: any): Promise<void> {
    try {
      console.log('Guardando datos de mesas de entrada en MariaDB:', data);
      
      // Verificar si ya existe un registro con id=1
      const checkResult = await query('SELECT COUNT(*) as count FROM MesasEntrada_Status WHERE id = 1');
      
      // Manejar diferentes formatos de resultado
      let count = 0;
      if (Array.isArray(checkResult) && checkResult.length > 0) {
        if (checkResult[0] && Array.isArray(checkResult[0]) && checkResult[0].length > 0) {
          count = checkResult[0][0].count || 0;
        } else if (checkResult[0] && typeof checkResult[0] === 'object') {
          count = checkResult[0].count || 0;
        }
      }
      
      // Construir la consulta SQL
      let sql = '';
      const values = [
        data.pep1, data.pep2, data.pep3, data.pep4, data.pep5, data.pep6,
        data.pep7, data.pep8, data.pep9, data.pep10, data.pep11, data.pep12
      ];
      
      if (count > 0) {
        // Actualizar el registro existente con id=1
        sql = `
          UPDATE MesasEntrada_Status 
          SET 
            pep1 = ?, pep2 = ?, pep3 = ?, pep4 = ?, pep5 = ?, pep6 = ?,
            pep7 = ?, pep8 = ?, pep9 = ?, pep10 = ?, pep11 = ?, pep12 = ?,
            timestamp = CURRENT_TIMESTAMP
          WHERE id = 1
        `;
      } else {
        // Insertar un nuevo registro con id=1
        sql = `
          INSERT INTO MesasEntrada_Status 
          (id, pep1, pep2, pep3, pep4, pep5, pep6, pep7, pep8, pep9, pep10, pep11, pep12)
          VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
      }
      
      // Ejecutar la consulta
      await query(sql, values);
      
      logger.info('Datos de mesas de entrada guardados correctamente en MariaDB');
    } catch (error) {
      logger.error('Error al guardar datos de mesas de entrada en MariaDB:', error);
      throw error;
    }
  }
  
  // Métodos auxiliares para mesas de salida
  private async readMesasSalidaPLCData(): Promise<Record<string, any> | null> {
    const conn = new nodes7();
    
    // Configuración de conexión al PLC
    const connectionParams = {
      host: process.env.PLC_IP || '10.21.178.100',
      port: 102,
      rack: parseInt(process.env.PLC_RACK || '0'),
      slot: parseInt(process.env.PLC_SLOT || '3'),
      timeout: 5000
    };
    
    try {
      // Crear una promesa para manejar la conexión asíncrona
      return await new Promise<Record<string, any>>((resolve, reject) => {
        // Conectar al PLC
        conn.initiateConnection(connectionParams, (err: any) => {
          if (err) {
            logger.error('Error al conectar con el PLC para leer estado de mesas de salida:', err);
            reject(err);
            return;
          }
          
          // Añadir variables para leer (estado de mesas de salida MS1 a MS12)
          const statusMesasSalida = [
            'DB110,B70', 'DB110,B71', 'DB110,B72', 'DB110,B73', 'DB110,B74', 
            'DB110,B75', 'DB110,B76', 'DB110,B77', 'DB110,B78', 'DB110,B79', 
            'DB110,B80', 'DB110,B81'
          ];
          
          conn.addItems(statusMesasSalida);
          
          // Leer todas las variables
          conn.readAllItems((err: any, values: Record<string, any>) => {
            // Desconectar del PLC después de leer
            conn.dropConnection(() => {
              logger.info('Desconectado del PLC después de leer valores de mesas de salida');
            });
            
            if (err) {
              logger.error('Error al leer valores de mesas de salida del PLC:', err);
              reject(err);
              return;
            }
            
            // Mostrar los valores crudos exactos que se leen del PLC
            console.log('\n==== VALORES CRUDOS LEÍDOS DEL PLC (MESAS DE SALIDA) ====');
            console.log(JSON.stringify(values, null, 2));
            console.log('===============================================\n');
            
            // Verificar si los valores del PLC son válidos
            const hasValidValues = Object.values(values).some(value => 
              value !== null && value !== undefined);
            
            if (hasValidValues) {
              resolve(values);
            } else {
              logger.warn('No se obtuvieron valores válidos del PLC para mesas de salida');
              reject(new Error('No se obtuvieron valores válidos del PLC para mesas de salida'));
            }
          });
        });
      });
    } catch (error) {
      logger.error('Error al leer datos de mesas de salida del PLC:', error);
      return null;
    }
  }
  
  private convertMesasSalidaToDBFormat(plcData: Record<string, any>): any {
    // Convertir los datos del PLC al formato esperado por la tabla MesasSalida_Status
    return {
      psp1: plcData['DB110,B70'] !== undefined ? plcData['DB110,B70'] : 0,
      psp2: plcData['DB110,B71'] !== undefined ? plcData['DB110,B71'] : 0,
      psp3: plcData['DB110,B72'] !== undefined ? plcData['DB110,B72'] : 0,
      psp4: plcData['DB110,B73'] !== undefined ? plcData['DB110,B73'] : 0,
      psp5: plcData['DB110,B74'] !== undefined ? plcData['DB110,B74'] : 0,
      psp6: plcData['DB110,B75'] !== undefined ? plcData['DB110,B75'] : 0,
      psp7: plcData['DB110,B76'] !== undefined ? plcData['DB110,B76'] : 0,
      psp8: plcData['DB110,B77'] !== undefined ? plcData['DB110,B77'] : 0,
      psp9: plcData['DB110,B78'] !== undefined ? plcData['DB110,B78'] : 0,
      psp10: plcData['DB110,B79'] !== undefined ? plcData['DB110,B79'] : 0,
      psp11: plcData['DB110,B80'] !== undefined ? plcData['DB110,B80'] : 0,
      psp12: plcData['DB110,B81'] !== undefined ? plcData['DB110,B81'] : 0
    };
  }
  
  private async saveMesasSalidaToDatabase(data: any): Promise<void> {
    try {
      console.log('Guardando datos de mesas de salida en MariaDB:', data);
      
      // Verificar si ya existe un registro con id=1
      const checkResult = await query('SELECT COUNT(*) as count FROM MesasSalida_Status WHERE id = 1');
      
      // Manejar diferentes formatos de resultado
      let count = 0;
      if (Array.isArray(checkResult) && checkResult.length > 0) {
        if (checkResult[0] && Array.isArray(checkResult[0]) && checkResult[0].length > 0) {
          count = checkResult[0][0].count || 0;
        } else if (checkResult[0] && typeof checkResult[0] === 'object') {
          count = checkResult[0].count || 0;
        }
      }
      
      // Construir la consulta SQL
      let sql = '';
      const values = [
        data.psp1, data.psp2, data.psp3, data.psp4, data.psp5, data.psp6,
        data.psp7, data.psp8, data.psp9, data.psp10, data.psp11, data.psp12
      ];
      
      if (count > 0) {
        // Actualizar el registro existente con id=1
        sql = `
          UPDATE MesasSalida_Status 
          SET 
            psp1 = ?, psp2 = ?, psp3 = ?, psp4 = ?, psp5 = ?, psp6 = ?,
            psp7 = ?, psp8 = ?, psp9 = ?, psp10 = ?, psp11 = ?, psp12 = ?,
            timestamp = CURRENT_TIMESTAMP
          WHERE id = 1
        `;
      } else {
        // Insertar un nuevo registro con id=1
        sql = `
          INSERT INTO MesasSalida_Status 
          (id, psp1, psp2, psp3, psp4, psp5, psp6, psp7, psp8, psp9, psp10, psp11, psp12)
          VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
      }
      
      // Ejecutar la consulta
      await query(sql, values);
      
      logger.info('Datos de mesas de salida guardados correctamente en MariaDB');
    } catch (error) {
      logger.error('Error al guardar datos de mesas de salida en MariaDB:', error);
      throw error;
    }
  }
  
  // Métodos para inicializar tablas
  private async initMesasEntradaTable(): Promise<void> {
    try {
      // Crear tabla MesasEntrada_Status si no existe
      await query(`
        CREATE TABLE IF NOT EXISTS MesasEntrada_Status (
          id INT AUTO_INCREMENT PRIMARY KEY,
          pep1 INT DEFAULT 0,
          pep2 INT DEFAULT 0,
          pep3 INT DEFAULT 0,
          pep4 INT DEFAULT 0,
          pep5 INT DEFAULT 0,
          pep6 INT DEFAULT 0,
          pep7 INT DEFAULT 0,
          pep8 INT DEFAULT 0,
          pep9 INT DEFAULT 0,
          pep10 INT DEFAULT 0,
          pep11 INT DEFAULT 0,
          pep12 INT DEFAULT 0,
          timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
      `);
      
      // Verificar si hay datos en la tabla
      const result = await query('SELECT COUNT(*) as count FROM MesasEntrada_Status');
      
      // Manejar diferentes formatos de resultado
      let count = 0;
      if (Array.isArray(result) && result.length > 0) {
        if (result[0] && Array.isArray(result[0]) && result[0].length > 0) {
          count = result[0][0].count || 0;
        } else if (result[0] && typeof result[0] === 'object') {
          count = result[0].count || 0;
        }
      }
      
      logger.info(`Verificación de datos en MesasEntrada_Status: ${count} registros encontrados`);
      
      // Si no hay datos, insertar datos iniciales con id=1
      if (count === 0) {
        await query(`
          INSERT INTO MesasEntrada_Status 
          (id, pep1, pep2, pep3, pep4, pep5, pep6, pep7, pep8, pep9, pep10, pep11, pep12)
          VALUES (1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
        `);
        logger.info('Datos iniciales para MesasEntrada_Status insertados correctamente');
      }
      
      logger.info('Tabla MesasEntrada_Status creada o ya existente');
    } catch (error) {
      logger.error('Error al inicializar la tabla MesasEntrada_Status:', error);
      throw error;
    }
  }
  
  private async initMesasSalidaTable(): Promise<void> {
    try {
      // Crear tabla MesasSalida_Status si no existe
      await query(`
        CREATE TABLE IF NOT EXISTS MesasSalida_Status (
          id INT AUTO_INCREMENT PRIMARY KEY,
          psp1 INT DEFAULT 0,
          psp2 INT DEFAULT 0,
          psp3 INT DEFAULT 0,
          psp4 INT DEFAULT 0,
          psp5 INT DEFAULT 0,
          psp6 INT DEFAULT 0,
          psp7 INT DEFAULT 0,
          psp8 INT DEFAULT 0,
          psp9 INT DEFAULT 0,
          psp10 INT DEFAULT 0,
          psp11 INT DEFAULT 0,
          psp12 INT DEFAULT 0,
          timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
      `);
      
      // Verificar si hay datos en la tabla
      const result = await query('SELECT COUNT(*) as count FROM MesasSalida_Status');
      
      // Manejar diferentes formatos de resultado
      let count = 0;
      if (Array.isArray(result) && result.length > 0) {
        if (result[0] && Array.isArray(result[0]) && result[0].length > 0) {
          count = result[0][0].count || 0;
        } else if (result[0] && typeof result[0] === 'object') {
          count = result[0].count || 0;
        }
      }
      
      logger.info(`Verificación de datos en MesasSalida_Status: ${count} registros encontrados`);
      
      // Si no hay datos, insertar datos iniciales con id=1
      if (count === 0) {
        await query(`
          INSERT INTO MesasSalida_Status 
          (id, psp1, psp2, psp3, psp4, psp5, psp6, psp7, psp8, psp9, psp10, psp11, psp12)
          VALUES (1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
        `);
        logger.info('Datos iniciales para MesasSalida_Status insertados correctamente');
      }
      
      logger.info('Tabla MesasSalida_Status creada o ya existente');
    } catch (error) {
      logger.error('Error al inicializar la tabla MesasSalida_Status:', error);
      throw error;
    }
  }
  
  // Métodos para configurar la sincronización programada
  private setupMesasEntradaScheduledSync(intervalSeconds = 30): void {
    // Configurar intervalo para sincronización automática
    setInterval(async () => {
      try {
        console.log(`Ejecutando sincronización automática de mesas de entrada (cada ${intervalSeconds} segundos)...`);
        
        // Leer datos del PLC
        const plcData = await this.readMesasEntradaPLCData();
        
        if (plcData) {
          // Convertir datos del PLC al formato de la tabla MesasEntrada_Status
          const dbData = this.convertMesasEntradaToDBFormat(plcData);
          
          // Guardar datos en la base de datos
          await this.saveMesasEntradaToDatabase(dbData);
          
          logger.info('Sincronización automática de mesas de entrada completada');
        } else {
          logger.warn('No se pudieron leer datos del PLC para la sincronización automática de mesas de entrada');
          // Actualizar solo el timestamp en caso de no tener datos
          try {
            await query('UPDATE MesasEntrada_Status SET timestamp = CURRENT_TIMESTAMP WHERE id = 1');
            logger.info('Timestamp de mesas de entrada actualizado a pesar de no tener datos del PLC');
          } catch (dbError) {
            logger.error('Error al actualizar timestamp de mesas de entrada:', dbError);
          }
        }
      } catch (error) {
        logger.error('Error en la sincronización automática de mesas de entrada:', error);
      }
    }, intervalSeconds * 1000);
    
    logger.info(`Sincronización automática de mesas de entrada configurada cada ${intervalSeconds} segundos`);
  }
  
  private setupMesasSalidaScheduledSync(intervalSeconds = 30): void {
    // Configurar intervalo para sincronización automática
    setInterval(async () => {
      try {
        console.log(`Ejecutando sincronización automática de mesas de salida (cada ${intervalSeconds} segundos)...`);
        
        // Leer datos del PLC
        const plcData = await this.readMesasSalidaPLCData();
        
        if (plcData) {
          // Convertir datos del PLC al formato de la tabla MesasSalida_Status
          const dbData = this.convertMesasSalidaToDBFormat(plcData);
          
          // Guardar datos en la base de datos
          await this.saveMesasSalidaToDatabase(dbData);
          
          logger.info('Sincronización automática de mesas de salida completada');
        } else {
          logger.warn('No se pudieron leer datos del PLC para la sincronización automática de mesas de salida');
          // Actualizar solo el timestamp en caso de no tener datos
          try {
            await query('UPDATE MesasSalida_Status SET timestamp = CURRENT_TIMESTAMP WHERE id = 1');
            logger.info('Timestamp de mesas de salida actualizado a pesar de no tener datos del PLC');
          } catch (dbError) {
            logger.error('Error al actualizar timestamp de mesas de salida:', dbError);
          }
        }
      } catch (error) {
        logger.error('Error en la sincronización automática de mesas de salida:', error);
      }
    }, intervalSeconds * 1000);
    
    logger.info(`Sincronización automática de mesas de salida configurada cada ${intervalSeconds} segundos`);
  }

  // Método para escribir valores en el DB110

  // Escribir valores en el DB110
  public writeValue = async (req: Request, res: Response): Promise<void> => {
    try {
      const { address, value } = req.body;
      
      if (!address || value === undefined) {
        res.status(400).json({
          success: false,
          message: 'Se requieren los campos address y value'
        });
        return;
      }

      // Validar que la dirección corresponda al DB110
      if (!address.startsWith('DB110')) {
        res.status(400).json({
          success: false,
          message: 'La dirección debe corresponder al DB110'
        });
        return;
      }

      // Convertir el valor según el tipo de dirección
      const convertedValue = this.convertValue(address, value);

      // Escribir el valor en el PLC
      const conn = new nodes7();
      const connectionParams = {
        host: process.env.PLC_IP || '10.21.178.100',
        port: 102,
        rack: parseInt(process.env.PLC_RACK || '0'),
        slot: parseInt(process.env.PLC_SLOT || '3'),
        timeout: 5000
      };

      await new Promise<void>((resolve, reject) => {
        conn.initiateConnection(connectionParams, (err: any) => {
          if (err) {
            logger.error('Error al conectar con el PLC para escribir en DB110:', err);
            reject(err);
            return;
          }

          // Escribir el valor
          conn.writeItems(address, convertedValue, (err: any) => {
            // Desconectar del PLC después de escribir
            conn.dropConnection(() => {
              logger.info('Desconectado del PLC después de escribir en DB110');
            });

            if (err) {
              logger.error('Error al escribir en el PLC para DB110:', err);
              reject(err);
              return;
            }

            logger.info(`Valor ${convertedValue} escrito correctamente en ${address}`);
            resolve();
          });
        });
      });

      res.json({
        success: true,
        message: `Valor ${convertedValue} escrito correctamente en ${address}`
      });
    } catch (error) {
      logger.error('Error al escribir en el DB110:', error);
      res.status(500).json({
        success: false,
        message: 'Error al escribir en el Puente Transferidor',
        error: (error as Error).message
      });
    }
  };
}