import { Request, Response } from 'express';
import { logger } from '../utils/logger';
import { query } from '../db/mariadb-config';

// Variable para almacenar la instancia de Socket.IO
let io: any = null;

// Función para establecer la instancia de Socket.IO
export function setSocketIO(socketIO: any) {
  io = socketIO;
  logger.info('Socket.IO configurado en el controlador de alarmas CT');
}

class CTAlarmsController {
  /**
   * Método para actualizar la tabla CT_Alarmas con los datos de defectos del DB111
   */
  async updateAlarms(): Promise<void> {
    try {
      logger.info('Actualizando tabla CT_Alarmas con datos de defectos del DB111');
      
      // Crear una conexión al PLC y leer los datos del DB111
      const conn = new (require('nodes7'))();
      
      // Configuración de conexión al PLC
      const connectionParams = {
        host: process.env.PLC_IP || '10.21.178.100',
        port: 102,
        rack: parseInt(process.env.PLC_RACK || '0'),
        slot: parseInt(process.env.PLC_SLOT || '3'),
        timeout: 5000
      };
      
      // Variables de defectos a leer
      const defectVariables = {
        'DB111,X60.0': 'error_comunicacion',
        'DB111,X60.1': 'emergencia_armario_carro',
        'DB111,X60.2': 'anomalia_variador',
        'DB111,X60.3': 'anomalia_motor_traslacion',
        'DB111,X60.4': 'anomalia_motor_entrada',
        'DB111,X60.5': 'anomalia_motor_salida',
        'DB111,X60.6': 'final_carrera_pasillo_1',
        'DB111,X60.7': 'final_carrera_pasillo_12',
        'DB111,X60.8': 'paleta_descentrada_transfer_entrada',
        'DB111,X60.9': 'paleta_descentrada_transfer_salida',
        'DB111,X62.0': 'limite_inferior_lectura_encoder',
        'DB111,X62.1': 'limite_superior_lectura_encoder',
        'DB111,X62.2': 'tiempo_transferencia_mesa_salida_carro',
        'DB111,X62.3': 'telemetro',
        'DB111,X64.0': 'tiempo_entrada',
        'DB111,X64.1': 'tiempo_salida',
        'DB111,X64.2': 'paleta_entrada_sin_codigo',
        'DB111,X64.3': 'paleta_salida_sin_codigo'
      };
      
      // Leer los datos del PLC
      const plcData = await new Promise<Record<string, any>>((resolve, reject) => {
        // Conectar al PLC
        conn.initiateConnection(connectionParams, (err: Error) => {
          if (err) {
            logger.error('Error al conectar con el PLC para leer defectos:', err);
            reject(err);
            return;
          }
          
          // Extraer las direcciones de las variables
          const variableAddresses = Object.keys(defectVariables);
          
          // Añadir variables para leer
          conn.addItems(variableAddresses);
          
          // Leer todas las variables
          conn.readAllItems((err: Error, values: Record<string, any>) => {
            // Desconectar del PLC después de leer
            conn.dropConnection(() => {
              logger.info('Desconectado del PLC después de leer valores de defectos');
            });
            
            if (err) {
              logger.error('Error al leer valores de defectos del PLC:', err);
              reject(err);
              return;
            }
            
            // Verificar si los valores del PLC son válidos
            const hasValidValues = Object.values(values).some(value => 
              value !== null && value !== undefined);
            
            if (hasValidValues) {
              logger.info('Valores de defectos leídos correctamente del PLC');
              resolve(values);
            } else {
              reject(new Error('No se obtuvieron valores válidos de defectos del PLC'));
            }
          });
        });
      });
      
      // Verificar si la tabla tiene registros
      const checkTableSql = `
        SELECT COUNT(*) as count 
        FROM CT_Alarmas
      `;
      
      const [checkResult] = await query(checkTableSql);
      
      // Preparar los valores para la consulta SQL
      const values: Record<string, boolean> = {};
      
      // Convertir los datos del PLC a valores booleanos
      for (const [address, fieldName] of Object.entries(defectVariables)) {
        values[fieldName] = Boolean(plcData[address]);
      }
      
      if (checkResult.count === 0) {
        // No hay registros, insertar uno nuevo
        const fields = Object.keys(values).join(', ');
        const placeholders = Object.keys(values).map(() => '?').join(', ');
        
        const insertSql = `
          INSERT INTO CT_Alarmas (${fields})
          VALUES (${placeholders})
        `;
        
        await query(insertSql, Object.values(values));
        logger.info('Primer registro insertado en la tabla CT_Alarmas');
      } else {
        // Actualizar el registro existente (el más reciente)
        const setClause = Object.keys(values)
          .map(field => `${field} = ?`)
          .join(', ');
        
        const updateSql = `
          UPDATE CT_Alarmas 
          SET ${setClause}, timestamp = CURRENT_TIMESTAMP
          WHERE id = (SELECT id FROM CT_Alarmas ORDER BY id DESC LIMIT 1)
        `;
        
        await query(updateSql, Object.values(values));
        logger.info('Registro actualizado en la tabla CT_Alarmas');
      }
    } catch (error) {
      logger.error(`Error al actualizar la tabla CT_Alarmas: ${error}`);
      throw error;
    }
  }

  /**
   * Método para configurar la sincronización programada de alarmas
   */
  setupScheduledSync(intervalSeconds: number = 30): NodeJS.Timeout {
    logger.info(`Configurando sincronización programada de alarmas CT cada ${intervalSeconds} segundos`);
    
    // Configurar el intervalo
    const interval = setInterval(async () => {
      try {
        logger.info('Iniciando sincronización programada de alarmas CT');
        await this.updateAlarms();
      } catch (error) {
        logger.error(`Error en la sincronización programada de alarmas CT: ${error}`);
      }
    }, intervalSeconds * 1000);
    
    logger.info(`Sincronización automática de alarmas CT configurada cada ${intervalSeconds} segundos`);
    return interval;
  }

  /**
   * Obtener todas las alarmas
   */
  async getAlarms(req: Request, res: Response): Promise<void> {
    try {
      // Consultar las alarmas en la base de datos
      const rows = await query('SELECT * FROM CT_Alarmas ORDER BY id DESC LIMIT 1');
      
      if (!rows || rows.length === 0) {
        res.status(404).json({
          success: false,
          message: 'No se encontraron datos de alarmas CT'
        });
        return;
      }
      
      res.json({
        success: true,
        data: rows[0]
      });
    } catch (error: any) {
      logger.error(`Error al obtener alarmas CT: ${error}`);
      res.status(500).json({
        success: false,
        message: 'Error al consultar la base de datos',
        error: error.message
      });
    }
  }

  /**
   * Obtener solo las alarmas activas (valores en true)
   */
  async getActiveAlarms(req: Request, res: Response): Promise<void> {
    try {
      // Consultar las alarmas en la base de datos
      const rows = await query('SELECT * FROM CT_Alarmas ORDER BY id DESC LIMIT 1');
      
      if (!rows || rows.length === 0) {
        res.status(404).json({
          success: false,
          message: 'No se encontraron datos de alarmas CT'
        });
        return;
      }
      
      const alarmData = rows[0];
      const activeAlarms = [];
      
      // Mapeo de nombres de campo a mensajes de alarma y severidad
      const alarmConfig: Record<string, {message: string, severity: "critical" | "warning" | "info"}> = {
        error_comunicacion: { message: "Error de comunicación con el Carro Transferidor", severity: "critical" },
        emergencia_armario_carro: { message: "Emergencia en armario del carro", severity: "critical" },
        anomalia_variador: { message: "Anomalía en el variador", severity: "warning" },
        anomalia_motor_traslacion: { message: "Anomalía en motor de traslación", severity: "warning" },
        anomalia_motor_entrada: { message: "Anomalía en motor de entrada", severity: "warning" },
        anomalia_motor_salida: { message: "Anomalía en motor de salida", severity: "warning" },
        final_carrera_pasillo_1: { message: "Final de carrera pasillo 1", severity: "warning" },
        final_carrera_pasillo_12: { message: "Final de carrera pasillo 12", severity: "warning" },
        paleta_descentrada_transfer_entrada: { message: "Paleta descentrada en transfer de entrada", severity: "warning" },
        paleta_descentrada_transfer_salida: { message: "Paleta descentrada en transfer de salida", severity: "warning" },
        limite_inferior_lectura_encoder: { message: "Límite inferior de lectura del encoder", severity: "info" },
        limite_superior_lectura_encoder: { message: "Límite superior de lectura del encoder", severity: "info" },
        tiempo_transferencia_mesa_salida_carro: { message: "Tiempo de transferencia mesa salida carro excedido", severity: "warning" },
        telemetro: { message: "Problema con telemetro", severity: "warning" },
        tiempo_entrada: { message: "Tiempo de entrada excedido", severity: "warning" },
        tiempo_salida: { message: "Tiempo de salida excedido", severity: "warning" },
        paleta_entrada_sin_codigo: { message: "Paleta de entrada sin código", severity: "info" },
        paleta_salida_sin_codigo: { message: "Paleta de salida sin código", severity: "info" }
      };
      
      // Imprimir los datos de alarma para depuración
      logger.info(`Datos de alarma: ${JSON.stringify(alarmData)}`);
      
      // Recorrer todos los campos excepto id y timestamp
      for (const [field, value] of Object.entries(alarmData)) {
        // Depurar cada campo
        logger.info(`Campo: ${field}, Valor: ${value}, Tipo: ${typeof value}`);
        
        // Verificar si el campo es una alarma activa (valor === 1)
        if (field !== 'id' && field !== 'timestamp' && value == 1 && alarmConfig[field]) {
          logger.info(`Alarma activa encontrada: ${field}`);
          
          activeAlarms.push({
            id: `ct-${field}`,
            deviceId: 'CT-001',
            deviceName: 'Carro Transferidor',
            message: alarmConfig[field].message,
            severity: alarmConfig[field].severity,
            timestamp: new Date(alarmData.timestamp),
            acknowledged: false
          });
        }
      }
      
      // Imprimir las alarmas activas encontradas
      logger.info(`Alarmas activas encontradas: ${activeAlarms.length}`);
      logger.info(`Datos de alarmas activas: ${JSON.stringify(activeAlarms)}`);
      
      
      res.json({
        success: true,
        data: activeAlarms
      });
    } catch (error: any) {
      logger.error(`Error al obtener alarmas activas CT: ${error}`);
      res.status(500).json({
        success: false,
        message: 'Error al consultar la base de datos',
        error: error.message
      });
    }
  }

  /**
   * Sincronizar alarmas manualmente
   */
  async syncAlarms(req: Request, res: Response): Promise<void> {
    try {
      await this.updateAlarms();
      res.json({
        success: true,
        message: 'Alarmas CT sincronizadas correctamente'
      });
    } catch (error: any) {
      logger.error(`Error al sincronizar alarmas CT: ${error}`);
      res.status(500).json({
        success: false,
        message: 'Error al sincronizar alarmas CT',
        error: error.message
      });
    }
  }

  /**
   * Obtener historial de alarmas
   */
  async getAlarmsHistory(req: Request, res: Response): Promise<void> {
    try {
      // Obtener el límite de registros a devolver
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      
      // Consultar el historial de alarmas en la base de datos
      const rows = await query(`SELECT * FROM CT_Alarmas ORDER BY id DESC LIMIT ${limit}`);
      
      if (!rows || rows.length === 0) {
        res.status(404).json({
          success: false,
          message: 'No se encontraron datos de historial de alarmas CT'
        });
        return;
      }
      
      res.json({
        success: true,
        data: rows
      });
    } catch (error: any) {
      logger.error(`Error al obtener historial de alarmas CT: ${error}`);
      res.status(500).json({
        success: false,
        message: 'Error al consultar la base de datos',
        error: error.message
      });
    }
  }
}

export default new CTAlarmsController();
