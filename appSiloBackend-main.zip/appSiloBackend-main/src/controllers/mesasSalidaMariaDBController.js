// src/controllers/mesasSalidaMariaDBController.js
const { query } = require('../db/mariadb-config');
const { logger } = require('../utils/logger');
const nodes7 = require('nodes7');

/**
 * Controlador para sincronizar datos de mesas de salida del PLC con la tabla MesasSalida_Status de MariaDB
 */
class MesasSalidaMariaDBController {
  /**
   * Lee los datos de mesas de salida del PLC y los guarda en la tabla MesasSalida_Status
   * @param {Object} req - Objeto de solicitud Express
   * @param {Object} res - Objeto de respuesta Express
   */
  async syncPLCToDatabase(req, res) {
    try {
      // Leer datos del PLC
      const plcData = await this.readPLCData();
      
      if (!plcData) {
        return res.status(500).json({
          success: false,
          message: 'No se pudieron leer los datos de mesas de salida del PLC'
        });
      }
      
      // Convertir datos del PLC al formato de la tabla MesasSalida_Status
      const dbData = this.convertPLCDataToDBFormat(plcData);
      
      // Guardar datos en la base de datos
      await this.saveToDatabase(dbData);
      
      // Responder con los datos guardados
      res.json({
        success: true,
        message: 'Datos de mesas de salida sincronizados correctamente',
        data: dbData
      });
    } catch (error) {
      logger.error('Error al sincronizar datos de mesas de salida con MariaDB:', error);
      res.status(500).json({
        success: false,
        message: 'Error al sincronizar datos de mesas de salida',
        error: error.message
      });
    }
  }
  
  /**
   * Lee los datos de mesas de salida del PLC utilizando nodes7
   * @returns {Promise<Object>} Datos leídos del PLC
   */
  async readPLCData() {
    const conn = new nodes7();
    
    // Configuración de conexión al PLC
    const connectionParams = {
      host: process.env.PLC_IP || '10.21.178.100',
      port: 102,
      rack: parseInt(process.env.PLC_RACK || '0'),
      slot: parseInt(process.env.PLC_SLOT || '3'),
      timeout: 5000
    };
    
    try {
      // Crear una promesa para manejar la conexión asíncrona
      return await new Promise((resolve, reject) => {
        // Conectar al PLC
        conn.initiateConnection(connectionParams, (err) => {
          if (err) {
            logger.error('Error al conectar con el PLC para leer estado de mesas de salida:', err);
            reject(err);
            return;
          }
          
          // Añadir variables para leer (estado de mesas de salida MS1 a MS12)
          const statusMesasSalida = [
            'DB110,B70', 'DB110,B71', 'DB110,B72', 'DB110,B73', 'DB110,B74', 
            'DB110,B75', 'DB110,B76', 'DB110,B77', 'DB110,B78', 'DB110,B79', 
            'DB110,B80', 'DB110,B81'
          ];
          
          conn.addItems(statusMesasSalida);
          
          // Leer todas las variables
          conn.readAllItems((err, values) => {
            // Desconectar del PLC después de leer
            conn.dropConnection(() => {
              logger.info('Desconectado del PLC después de leer valores de mesas de salida');
            });
            
            if (err) {
              logger.error('Error al leer valores de mesas de salida del PLC:', err);
              reject(err);
              return;
            }
            
            // Mostrar los valores crudos exactos que se leen del PLC
            console.log('\n==== VALORES CRUDOS LEÍDOS DEL PLC (MESAS DE SALIDA) ====');
            console.log(JSON.stringify(values, null, 2));
            console.log('===============================================\n');
            
            // Verificar si los valores del PLC son válidos
            const hasValidValues = Object.values(values).some(value => 
              value !== null && value !== undefined);
            
            if (hasValidValues) {
              resolve(values);
            } else {
              logger.warn('No se obtuvieron valores válidos del PLC para mesas de salida');
              reject(new Error('No se obtuvieron valores válidos del PLC para mesas de salida'));
            }
          });
        });
      });
    } catch (error) {
      logger.error('Error al leer datos de mesas de salida del PLC:', error);
      return null;
    }
  }
  
  /**
   * Convierte los datos del PLC al formato de la tabla MesasSalida_Status
   * @param {Object} plcData - Datos leídos del PLC
   * @returns {Object} Datos en formato para la tabla MesasSalida_Status
   */
  convertPLCDataToDBFormat(plcData) {
    // Mapear los valores de las mesas de salida (MS1 a MS12)
    return {
      psp1: plcData['DB110,B70'] !== undefined ? plcData['DB110,B70'] : 0,
      psp2: plcData['DB110,B71'] !== undefined ? plcData['DB110,B71'] : 0,
      psp3: plcData['DB110,B72'] !== undefined ? plcData['DB110,B72'] : 0,
      psp4: plcData['DB110,B73'] !== undefined ? plcData['DB110,B73'] : 0,
      psp5: plcData['DB110,B74'] !== undefined ? plcData['DB110,B74'] : 0,
      psp6: plcData['DB110,B75'] !== undefined ? plcData['DB110,B75'] : 0,
      psp7: plcData['DB110,B76'] !== undefined ? plcData['DB110,B76'] : 0,
      psp8: plcData['DB110,B77'] !== undefined ? plcData['DB110,B77'] : 0,
      psp9: plcData['DB110,B78'] !== undefined ? plcData['DB110,B78'] : 0,
      psp10: plcData['DB110,B79'] !== undefined ? plcData['DB110,B79'] : 0,
      psp11: plcData['DB110,B80'] !== undefined ? plcData['DB110,B80'] : 0,
      psp12: plcData['DB110,B81'] !== undefined ? plcData['DB110,B81'] : 0
    };
  }
  
  /**
   * Guarda los datos en la tabla MesasSalida_Status
   * @param {Object} data - Datos a guardar
   * @returns {Promise<void>}
   */
  async saveToDatabase(data) {
    try {
      console.log('Guardando datos de mesas de salida en MariaDB:', data);
      
      // Verificar si ya existe un registro con id=1
      const checkResult = await query('SELECT COUNT(*) as count FROM MesasSalida_Status WHERE id = 1');
      
      // Manejar diferentes formatos de resultado
      let count = 0;
      if (Array.isArray(checkResult) && checkResult.length > 0) {
        if (checkResult[0] && Array.isArray(checkResult[0]) && checkResult[0].length > 0) {
          count = checkResult[0][0].count || 0;
        } else if (checkResult[0] && typeof checkResult[0] === 'object') {
          count = checkResult[0].count || 0;
        }
      }
      
      // Construir la consulta SQL
      let sql = '';
      const values = [
        data.psp1, data.psp2, data.psp3, data.psp4, data.psp5, data.psp6,
        data.psp7, data.psp8, data.psp9, data.psp10, data.psp11, data.psp12
      ];
      
      if (count > 0) {
        // Actualizar el registro existente con id=1
        sql = `
          UPDATE MesasSalida_Status 
          SET 
            psp1 = ?, psp2 = ?, psp3 = ?, psp4 = ?, psp5 = ?, psp6 = ?,
            psp7 = ?, psp8 = ?, psp9 = ?, psp10 = ?, psp11 = ?, psp12 = ?,
            timestamp = CURRENT_TIMESTAMP
          WHERE id = 1
        `;
      } else {
        // Insertar un nuevo registro con id=1
        sql = `
          INSERT INTO MesasSalida_Status 
          (id, psp1, psp2, psp3, psp4, psp5, psp6, psp7, psp8, psp9, psp10, psp11, psp12)
          VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
      }
      
      // Ejecutar la consulta
      await query(sql, values);
      
      logger.info('Datos de mesas de salida guardados correctamente en MariaDB');
    } catch (error) {
      logger.error('Error al guardar datos de mesas de salida en MariaDB:', error);
      throw error;
    }
  }
  
  /**
   * Configura una tarea programada para sincronizar datos periódicamente
   * @param {number} intervalSeconds - Intervalo en segundos
   */
  setupScheduledSync(intervalSeconds = 30) {
    // Configurar intervalo para sincronización automática
    setInterval(async () => {
      try {
        console.log(`Ejecutando sincronización automática de mesas de salida (cada ${intervalSeconds} segundos)...`);
        
        // Leer datos del PLC
        const plcData = await this.readPLCData();
        
        if (plcData) {
          // Convertir datos del PLC al formato de la tabla MesasSalida_Status
          const dbData = this.convertPLCDataToDBFormat(plcData);
          
          // Guardar datos en la base de datos
          await this.saveToDatabase(dbData);
          
          logger.info('Sincronización automática de mesas de salida completada');
        } else {
          logger.warn('No se pudieron leer datos del PLC para la sincronización automática de mesas de salida');
        }
      } catch (error) {
        logger.error('Error en la sincronización automática de mesas de salida:', error);
      }
    }, intervalSeconds * 1000);
    
    logger.info(`Sincronización automática de mesas de salida configurada cada ${intervalSeconds} segundos`);
  }
  
  /**
   * Inicializa la tabla MesasSalida_Status en MariaDB
   * @returns {Promise<void>}
   */
  async initMesasSalidaStatusTable() {
    try {
      // Crear tabla MesasSalida_Status si no existe
      await query(`
        CREATE TABLE IF NOT EXISTS MesasSalida_Status (
          id INT AUTO_INCREMENT PRIMARY KEY,
          psp1 INT DEFAULT 0,
          psp2 INT DEFAULT 0,
          psp3 INT DEFAULT 0,
          psp4 INT DEFAULT 0,
          psp5 INT DEFAULT 0,
          psp6 INT DEFAULT 0,
          psp7 INT DEFAULT 0,
          psp8 INT DEFAULT 0,
          psp9 INT DEFAULT 0,
          psp10 INT DEFAULT 0,
          psp11 INT DEFAULT 0,
          psp12 INT DEFAULT 0,
          timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
      `);
      
      // Verificar si hay datos en la tabla
      const result = await query('SELECT COUNT(*) as count FROM MesasSalida_Status');
      
      // Manejar diferentes formatos de resultado
      let count = 0;
      if (Array.isArray(result) && result.length > 0) {
        // Si el resultado es un array (como [rows, fields])
        if (result[0] && Array.isArray(result[0]) && result[0].length > 0) {
          count = result[0][0].count || 0;
        } else if (result[0] && typeof result[0] === 'object') {
          count = result[0].count || 0;
        }
      }
      
      logger.info(`Verificación de datos en MesasSalida_Status: ${count} registros encontrados`);
      
      // Si no hay datos, insertar datos iniciales con id=1
      if (count === 0) {
        await query(`
          INSERT INTO MesasSalida_Status 
          (id, psp1, psp2, psp3, psp4, psp5, psp6, psp7, psp8, psp9, psp10, psp11, psp12)
          VALUES (1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
        `);
        logger.info('Datos iniciales para MesasSalida_Status insertados correctamente');
      }
      
      logger.info('Tabla MesasSalida_Status creada o ya existente');
    } catch (error) {
      logger.error('Error al inicializar la tabla MesasSalida_Status:', error);
      throw error;
    }
  }
  
  /**
   * Obtiene los datos actuales de mesas de salida desde MariaDB
   * @param {Object} req - Objeto de solicitud Express
   * @param {Object} res - Objeto de respuesta Express
   */
  async getMesasSalidaStatus(req, res) {
    try {
      console.log('Ejecutando getMesasSalidaStatus para obtener datos de mesas de salida desde MariaDB...');
      
      // Obtener la fila con id=1 de la tabla MesasSalida_Status (que es la que siempre actualizamos)
      const result = await query('SELECT * FROM MesasSalida_Status WHERE id = 1');
      
      // Imprimir el resultado completo para depuración
      console.log('Resultado completo de la consulta MesasSalida_Status:', JSON.stringify(result, null, 2));
      
      // Manejar diferentes formatos de resultado
      let rows = [];
      if (Array.isArray(result)) {
        if (result.length > 0) {
          rows = result;
        }
      } else if (result && Array.isArray(result.rows)) {
        rows = result.rows;
      }
      
      console.log(`Se encontraron ${rows.length} registros en MesasSalida_Status`);
      
      if (rows.length > 0) {
        const mesasSalidaData = rows[0];
        console.log('Datos de mesas de salida encontrados:', JSON.stringify(mesasSalidaData, null, 2));
        
        res.json(mesasSalidaData);
      } else {
        console.log('No se encontraron datos de mesas de salida en la base de datos');
        res.status(404).json({
          success: false,
          message: 'No se encontraron datos de mesas de salida'
        });
      }
    } catch (error) {
      logger.error('Error al obtener datos de mesas de salida desde MariaDB:', error);
      console.error('Error completo:', error);
      res.status(500).json({
        success: false,
        message: 'Error al obtener datos de mesas de salida',
        error: error.message
      });
    }
  }
}

// Inicializar la tabla MesasSalida_Status al cargar el módulo
const mesasSalidaController = new MesasSalidaMariaDBController();
mesasSalidaController.initMesasSalidaStatusTable()
  .then(() => {
    // Iniciar sincronización automática cada 30 segundos
    mesasSalidaController.setupScheduledSync(30);
  })
  .catch(error => {
    logger.error('Error al inicializar el controlador de mesas de salida:', error);
  });

module.exports = mesasSalidaController;
