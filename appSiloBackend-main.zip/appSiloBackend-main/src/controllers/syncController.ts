// @ts-ignore
import { nodes7 } from 'nodes7';
import { logger } from '../utils/logger';
import { query } from '../db/mariadb-config';

/**
 * Controlador para sincronizar datos de pasillos, mesas de entrada y mesas de salida con MariaDB
 */
export class SyncController {
  
  /**
   * Inicializa la sincronización automática
   */
  public init(): void {
    console.log('======================================================');
    console.log('INICIANDO SINCRONIZACIÓN DE PASILLOS Y MESAS');
    console.log('======================================================');
    
    // Configurar la sincronización automática cada 30 segundos
    const syncInterval = 30000; // 30 segundos
    
    // Iniciar la sincronización automática
    this.setupScheduledSync(syncInterval);
    
    logger.info(`Sincronización automática de pasillos y mesas configurada cada ${syncInterval / 1000} segundos`);
  }
  
  /**
   * Configura la sincronización automática
   * @param syncInterval Intervalo de sincronización en milisegundos
   */
  private setupScheduledSync(syncInterval: number): void {
    // Configurar la sincronización automática para pasillos, mesas de entrada y mesas de salida
    console.log('CONFIGURANDO SINCRONIZACIÓN PARA PASILLOS, MESAS DE ENTRADA Y MESAS DE SALIDA');
    
    setInterval(async () => {
      try {
        console.log('\n==== SINCRONIZACIÓN DE PASILLOS, MESAS DE ENTRADA Y MESAS DE SALIDA ====');
        console.log(`Hora de inicio: ${new Date().toISOString()}`);
        
        // Leer valores del PLC
        const conn = new nodes7();
        
        // Parámetros de conexión al PLC
        const connectionParams = {
          host: process.env.PLC_IP || '10.21.178.100',
          port: 102,
          rack: parseInt(process.env.PLC_RACK || '0'),
          slot: parseInt(process.env.PLC_SLOT || '3'),
          timeout: 5000
        };
        
        // Variables a leer del PLC (pasillos, mesas de entrada y mesas de salida)
        const variables: Record<string, string> = {};
        
        // Agregar variables de pasillos
        for (let i = 1; i <= 12; i++) {
          variables[`P${i}`] = `DB110,B${9 + i}`; // B10 a B21
        }
        
        // Agregar variables de mesas de entrada
        for (let i = 1; i <= 12; i++) {
          variables[`ME${i}`] = `DB110,B${49 + i}`; // B50 a B61
        }
        
        // Agregar variables de mesas de salida
        for (let i = 1; i <= 12; i++) {
          variables[`MS${i}`] = `DB110,B${69 + i}`; // B70 a B81
        }
        
        console.log(`Variables a leer: ${Object.keys(variables).length}`);
        console.log(`Direcciones: ${JSON.stringify(Object.values(variables))}`);
        
        // Agregar variables al cliente
        conn.addItems(Object.values(variables));
        
        try {
          // Conectar al PLC
          await new Promise<void>((resolve, reject) => {
            conn.initiateConnection(connectionParams, (err: any) => {
              if (err) {
                console.error(`Error al conectar con el PLC: ${err}`);
                reject(err);
                return;
              }
              console.log('Conexión con el PLC establecida correctamente para leer pasillos y mesas');
              resolve();
            });
          });
          
          // Leer valores
          const values = await new Promise<Record<string, any>>((resolve, reject) => {
            conn.readAllItems((err: any, values: any) => {
              if (err) {
                console.error(`Error al leer valores del PLC: ${err}`);
                reject(err);
                return;
              }
              console.log('Valores leídos del PLC correctamente para pasillos y mesas');
              resolve(values);
            });
          });
          
          console.log('Valores leídos del PLC:', JSON.stringify(values));
          
          // Procesar los valores para pasillos
          const pasData: Record<string, number> = {};
          for (let i = 1; i <= 12; i++) {
            const key = `P${i}`;
            const address = variables[key];
            pasData[`pas${i}`] = values[address] || 0;
            console.log(`Pasillo ${i}: ${values[address]} (${address})`);
          }
          
          // Procesar los valores para mesas de entrada
          const mesasEntradaData: Record<string, number> = {};
          for (let i = 1; i <= 12; i++) {
            const key = `ME${i}`;
            const address = variables[key];
            mesasEntradaData[`pep${i}`] = values[address] || 0;
            console.log(`Mesa de entrada ${i}: ${values[address]} (${address})`);
          }
          
          // Procesar los valores para mesas de salida
          const mesasSalidaData: Record<string, number> = {};
          for (let i = 1; i <= 12; i++) {
            const key = `MS${i}`;
            const address = variables[key];
            mesasSalidaData[`psp${i}`] = values[address] || 0;
            console.log(`Mesa de salida ${i}: ${values[address]} (${address})`);
          }
          
          // Actualizar las tablas en MariaDB
          try {
            console.log('Actualizando tabla pas_status...');
            await this.updateMariaDBTable('pas_status', pasData);
            console.log('Tabla pas_status actualizada correctamente');
            
            console.log('Actualizando tabla mesasentrada_status...');
            await this.updateMariaDBTable('mesasentrada_status', mesasEntradaData);
            console.log('Tabla mesasentrada_status actualizada correctamente');
            
            console.log('Actualizando tabla mesassalida_status...');
            await this.updateMariaDBTable('mesassalida_status', mesasSalidaData);
            console.log('Tabla mesassalida_status actualizada correctamente');
            
            logger.info('Sincronización de pasillos, mesas de entrada y mesas de salida completada con éxito');
          } catch (dbError) {
            console.error(`Error al actualizar tablas en MariaDB: ${dbError}`);
            logger.error(`Error al actualizar tablas en MariaDB: ${dbError}`);
          }
          
        } catch (plcError) {
          console.error(`Error al leer valores del PLC: ${plcError}`);
          logger.error(`Error al leer valores del PLC para pasillos y mesas: ${plcError}`);
        } finally {
          // Desconectar del PLC
          conn.dropConnection();
          console.log('Desconectado del PLC después de leer valores de pasillos y mesas');
        }
        
        console.log('==== FIN SINCRONIZACIÓN DE PASILLOS, MESAS DE ENTRADA Y MESAS DE SALIDA ====\n');
      } catch (error) {
        console.error(`Error en la sincronización de pasillos y mesas: ${error}`);
        logger.error(`Error en la sincronización de pasillos y mesas: ${error}`);
      }
    }, syncInterval);
  }
  
  /**
   * Actualiza una tabla en MariaDB
   * @param tableName Nombre de la tabla
   * @param data Datos a actualizar
   */
  private async updateMariaDBTable(tableName: string, data: Record<string, any>): Promise<void> {
    try {
      const fields = Object.keys(data);
      const values = Object.values(data);
      
      // Construir la consulta SQL para actualizar los datos
      const setClause = fields.map(field => `${field} = ?`).join(', ');
      const sql = `UPDATE ${tableName} SET ${setClause} WHERE id = 1`;
      
      console.log(`Ejecutando consulta SQL: ${sql}`);
      console.log(`Valores para la consulta: ${JSON.stringify(values)}`);
      
      // Ejecutar la consulta
      const result = await query(sql, values);
      console.log(`Resultado de la consulta: ${JSON.stringify(result)}`);
      
      // Verificar que los datos se han actualizado correctamente
      const verificationSql = `SELECT * FROM ${tableName} WHERE id = 1`;
      const verificationResult = await query(verificationSql);
      console.log(`Verificación de datos en ${tableName}: ${JSON.stringify(verificationResult)}`);
      
      logger.info(`Datos actualizados en ${tableName} usando SQL directo: ${JSON.stringify(data)}`);
    } catch (error) {
      console.error(`Error al actualizar datos en ${tableName}: ${error}`);
      logger.error(`Error al actualizar datos en ${tableName}: ${error}`);
      throw error; // Re-lanzar el error para que pueda ser capturado por el llamador
    }
  }
}
