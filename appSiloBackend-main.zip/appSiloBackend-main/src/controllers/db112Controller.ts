import { Request, Response } from 'express';
import { logger } from '../utils/logger';
import { query } from '../db/mariadb-config';

// Importar nodes7 de forma dinámica para evitar problemas de tipado
const nodes7 = require('nodes7');

// Función para actualizar datos en MariaDB
async function updateMariaDBTable(tableName: string, data: Record<string, any>): Promise<void> {
  try {
    const fields = Object.keys(data);
    const values = Object.values(data);
    
    // Construir la consulta SQL para actualizar los datos
    const setClause = fields.map(field => `${field} = ?`).join(', ');
    const sql = `UPDATE ${tableName} SET ${setClause} WHERE id = 1`;
    
    console.log(`Ejecutando consulta SQL: ${sql}`);
    console.log(`Valores para la consulta: ${JSON.stringify(values)}`);
    
    // Ejecutar la consulta
    await query(sql, values);
    console.log(`Datos actualizados en la tabla ${tableName}`);
  } catch (error) {
    console.error(`Error al actualizar datos en ${tableName}:`, error);
    throw error;
  }
}

/**
 * Controlador para gestionar la comunicación con el DB112 del PLC
 */
export class DB112Controller {
  private variables: Record<string, string>;
  private syncInterval: NodeJS.Timeout | null = null;
  
  /**
   * Constructor del controlador DB112
   */
  constructor() {
    // Definir las variables del DB112 que queremos leer según la imagen
    this.variables = {
      // Status bits (X130)
      'DB112,X130.0': 'Status-Conectado',
      'DB112,X130.1': 'Status-Defecto',
      'DB112,X130.2': 'Status-Automático',
      'DB112,X130.3': 'Status-Semiautomático',
      'DB112,X130.4': 'Status-Manual',
      'DB112,X130.5': 'Status-Emergencia puerta armario',
      'DB112,X130.6': 'Status-Con datos',
      'DB112,X130.7': '',
      
      // Autorizaciones y peticiones (X131)
      'DB112,X131.0': '',
      'DB112,X131.1': '',
      'DB112,X131.2': 'Autorización de transferencia desde TC26',
      'DB112,X131.3': 'Fin de transferencia desde TC26',
      'DB112,X131.4': 'Petición de transferencia desde TC30',
      'DB112,X131.5': '',
      'DB112,X131.6': '',
      'DB112,X131.7': 'Acuse de orden recibida',
      
      // Autorizaciones y peticiones (X132)
      'DB112,X132.0': 'Autorización de transferencia desde TC30',
      'DB112,X132.1': 'Fin de transferencia desde TC30',
      'DB112,X132.2': 'Petición de transferencia desde TC31',
      'DB112,X132.3': 'Petición de transferencia desde TC31',
      'DB112,X132.4': '',
      'DB112,X132.5': '',
      'DB112,X132.6': '',
      'DB112,X132.7': '',
      
      // Otras variables (X133)
      'DB112,X133.0': '',
      'DB112,X133.1': '',
      'DB112,X133.2': '',
      'DB112,X133.3': '',
      'DB112,X133.4': '',
      'DB112,X133.5': '',
      'DB112,X133.6': '',
      'DB112,X133.7': '',
      
      // Matrículas (Words)
      'DB112,W132': 'Matrícula paleta en transportador de entrada',
      'DB112,W134': 'Matrícula paleta en transportador de salida',
      
      // Pasillos y estados (Bytes)
      'DB112,B136': 'Pasillo destino',
      'DB112,B137': 'Ciclo de trabajo',
      'DB112,B138': '',
      'DB112,B139': '',
      'DB112,B140': 'Numero de pasillo actual',
      'DB112,B141': 'Estado carro (0=Libre 1=Ocupado 2=Avería)',
      
      // Defectos (X142)
      'DB112,X142.0': 'Defecto-Error de comunicación',
      'DB112,X142.1': 'Defecto-Emergencia armario carro',
      'DB112,X142.2': 'Defecto-Anomalía variador',
      'DB112,X142.3': 'Defecto-Anomalía motor traslación',
      'DB112,X142.4': 'Defecto-Anomalía motor entrada',
      'DB112,X142.5': 'Defecto-Anomalía motor salida',
      'DB112,X142.6': 'Defecto-Final de carrera pasillo 1',
      'DB112,X142.7': 'Defecto-Final de carrera pasillo 12',
      
      // Defectos (X143)
      'DB112,X143.0': 'Defecto-Paleta descentrada en transfer de entrada',
      'DB112,X143.1': 'Defecto-Paleta descentrada en transfer de salida',
      'DB112,X143.2': '',
      'DB112,X143.3': '',
      'DB112,X143.4': '',
      'DB112,X143.5': '',
      'DB112,X143.6': '',
      'DB112,X143.7': '',
      
      // Visualización (X144)
      'DB112,X144.0': 'Visualización-Centraje traslación adelante',
      'DB112,X144.1': 'Visualización-Centraje traslación atrás',
      'DB112,X144.2': 'Visualización-Presencia delantera de paleta en entrada',
      'DB112,X144.3': 'Visualización-Presencia trasera de paleta en entrada',
      'DB112,X144.4': 'Visualización-Presencia delantera de paleta en salida',
      'DB112,X144.5': 'Visualización-Presencia trasera de paleta en salida',
      'DB112,X144.6': '',
      'DB112,X144.7': '',
      
      // Visualización (X145)
      'DB112,X145.0': 'Visualización-Marcha traslación adelante',
      'DB112,X145.1': 'Visualización-Marcha traslación atrás',
      'DB112,X145.2': 'Visualización-Motor traslación parado',
      'DB112,X145.3': 'Visualización-Centraje traslación',
      'DB112,X145.4': 'Visualización-Marcha transportador entrada',
      'DB112,X145.5': 'Visualización-Marcha transportador salida',
      'DB112,X145.6': 'Visualización-Defecto traslación',
      'DB112,X145.7': 'Visualización-Defecto transportador'
    };
  }
  
  /**
   * Método para traducir las etiquetas de las variables
   * @param tag Etiqueta a traducir
   * @returns Etiqueta traducida
   */
  private translateTag(tag: string): { address: string, datatype: string } {
    try {
      // Verificar que tag sea un string válido
      if (!tag || typeof tag !== 'string') {
        logger.error(`translateTag: Tag inválido: ${tag}`);
        return { address: 'DB112.DBX0.0', datatype: 'BOOL' };
      }
      
      // Extraer el tipo de datos de la etiqueta
      let datatype = 'BOOL'; // Por defecto es un bit (booleano)
      
      if (tag.includes(',X')) {
        datatype = 'BOOL';
      } else if (tag.includes(',B')) {
        datatype = 'BYTE';
      } else if (tag.includes(',W')) {
        datatype = 'WORD';
      } else if (tag.includes(',D') && !tag.includes(',DI')) {
        datatype = 'DWORD';
      } else if (tag.includes(',I')) {
        datatype = 'INT';
      } else if (tag.includes(',DI')) {
        datatype = 'DINT';
      } else if (tag.includes(',R')) {
        datatype = 'REAL';
      }
      
      // Verificar que el tag tenga el formato esperado
      if (!tag.includes(',')) {
        logger.error(`translateTag: Formato de tag inválido (sin coma): ${tag}`);
        return { address: 'DB112.DBX0.0', datatype: 'BOOL' };
      }
      
      // Extraer la dirección base y el offset
      const parts = tag.split(',');
      if (parts.length < 2) {
        logger.error(`translateTag: Formato de tag inválido (partes insuficientes): ${tag}`);
        return { address: 'DB112.DBX0.0', datatype: 'BOOL' };
      }
      
      const dbNumber = parts[0].replace('DB', '');
      const addressPart = parts[1];
      
      // Construir la dirección completa
      let address = '';
      
      if (addressPart.startsWith('X')) {
        // Es un bit, formato: DBx,Xy.z
        const bitParts = addressPart.substring(1).split('.');
        if (bitParts.length < 2) {
          logger.error(`translateTag: Formato de bit inválido: ${addressPart}`);
          return { address: 'DB112.DBX0.0', datatype: 'BOOL' };
        }
        const byteOffset = parseInt(bitParts[0]);
        const bitOffset = parseInt(bitParts[1]);
        address = `DB${dbNumber}.DBX${byteOffset}.${bitOffset}`;
      } else if (addressPart.startsWith('B')) {
        // Es un byte, formato: DBx,By
        const byteOffset = parseInt(addressPart.substring(1));
        address = `DB${dbNumber}.DBB${byteOffset}`;
      } else if (addressPart.startsWith('W')) {
        // Es una palabra, formato: DBx,Wy
        const byteOffset = parseInt(addressPart.substring(1));
        address = `DB${dbNumber}.DBW${byteOffset}`;
      } else if (addressPart.startsWith('D')) {
        // Es una doble palabra, formato: DBx,Dy
        const byteOffset = parseInt(addressPart.substring(1));
        address = `DB${dbNumber}.DBD${byteOffset}`;
      } else {
        logger.error(`translateTag: Tipo de dirección no reconocido: ${addressPart}`);
        return { address: 'DB112.DBX0.0', datatype: 'BOOL' };
      }
      
      return { address, datatype };
    } catch (error: any) {
      logger.error(`translateTag: Error al procesar tag ${tag}: ${error.message}`);
      return { address: 'DB112.DBX0.0', datatype: 'BOOL' };
    }
  }
  
  /**
   * Método para formatear los datos leídos del PLC
   */
  private formatPLCData(plcData: Record<string, any>): Record<string, any> {
    const result: Record<string, any> = {
      timestamp: new Date().toISOString(),
      data: {
        status: {},
        autorizaciones: {},
        matriculas: {},
        pasillos: {},
        defectos: {},
        visualizacion: {}
      }
    };
    
    // Recorrer los datos del PLC y organizarlos por categorías
    for (const [address, value] of Object.entries(plcData)) {
      const name = this.variables[address];
      
      if (!name || name === '') continue; // Ignorar variables sin nombre
      
      if (name.startsWith('Status-')) {
        result.data.status[name] = Boolean(value); // Asegurar que los estados son booleanos
      } else if (name.startsWith('Autorización') || name.startsWith('Petición')) {
        result.data.autorizaciones[name] = Boolean(value); // Asegurar que las autorizaciones son booleanos
      } else if (name.startsWith('Matrícula')) {
        result.data.matriculas[name] = Number(value); // Asegurar que las matrículas son números
      } else if (name.startsWith('Pasillo') || name.startsWith('Ciclo') || name.startsWith('Numero') || name.startsWith('Estado carro')) {
        result.data.pasillos[name] = Number(value); // Asegurar que los pasillos son números
      } else if (name.startsWith('Defecto-')) {
        result.data.defectos[name] = Boolean(value); // Asegurar que los defectos son booleanos
      } else if (name.startsWith('Visualización')) {
        result.data.visualizacion[name] = value; // Mantener el tipo original para visualización
      }
    }
    
    // Agregar información adicional para el estado del carro
    if ('Estado carro (0=Libre 1=Ocupado 2=Avería)' in result.data.pasillos) {
      const estadoCarro = result.data.pasillos['Estado carro (0=Libre 1=Ocupado 2=Avería)'];
      let estadoCarroTexto = 'Desconocido';
      
      switch (estadoCarro) {
        case 0:
          estadoCarroTexto = 'Libre';
          break;
        case 1:
          estadoCarroTexto = 'Ocupado';
          break;
        case 2:
          estadoCarroTexto = 'Avería';
          break;
      }
      
      result.data.pasillos['Estado carro texto'] = estadoCarroTexto;
    }
    
    return result;
  }
  
  /**
   * Método para actualizar la tabla DB112 en MariaDB
   * @param data Datos formateados del PLC
   */
  private async updateDB112Table(data: Record<string, any>): Promise<void> {
    try {
      // Verificar si la tabla existe
      const checkTableSql = `
        SELECT COUNT(*) as count 
        FROM information_schema.tables 
        WHERE table_schema = DATABASE() 
        AND table_name = 'DB112_Status'
      `;
      
      const [checkResult] = await query(checkTableSql);
      
      if (checkResult.count === 0) {
        // Crear la tabla si no existe
        logger.info('Creando tabla DB112_Status en MariaDB');
        
        const createTableSql = `
          CREATE TABLE DB112_Status (
            id INT AUTO_INCREMENT PRIMARY KEY,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            data JSON
          )
        `;
        
        await query(createTableSql);
        logger.info('Tabla DB112_Status creada en MariaDB');
        
        // Insertar el primer registro
        const insertSql = `
          INSERT INTO DB112_Status (data) 
          VALUES (?)
        `;
        
        await query(insertSql, [JSON.stringify(data.data)]);
        logger.info('Primer registro insertado en la tabla DB112_Status');
      } else {
        // Actualizar el registro existente
        const updateSql = `
          UPDATE DB112_Status 
          SET data = ?, timestamp = CURRENT_TIMESTAMP
          WHERE id = 1
        `;
        
        await query(updateSql, [JSON.stringify(data.data)]);
        logger.info('Registro actualizado en la tabla DB112_Status');
      }
      
      // Actualizar la tabla CT_Status con los campos específicos
      try {
        // Verificar si la tabla CT_Status existe
        const checkCTTableSql = `
          SELECT COUNT(*) as count 
          FROM information_schema.tables 
          WHERE table_schema = DATABASE() 
          AND table_name = 'CT_Status'
        `;
        
        const [checkCTResult] = await query(checkCTTableSql);
        
        if (checkCTResult.count === 0) {
          // Crear la tabla CT_Status si no existe
          logger.info('Creando tabla CT_Status en MariaDB');
          
          const createCTTableSql = `
            CREATE TABLE CT_Status (
              id INT AUTO_INCREMENT PRIMARY KEY,
              timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              StConectado TINYINT DEFAULT 0,
              StDefecto TINYINT DEFAULT 0,
              St_Auto TINYINT DEFAULT 0,
              St_Semi TINYINT DEFAULT 0,
              St_Manual TINYINT DEFAULT 0,
              St_Puerta TINYINT DEFAULT 0,
              St_Datos TINYINT DEFAULT 0,
              MatEntrada INT DEFAULT 0,
              MatSalida INT DEFAULT 0,
              PasDestino TINYINT DEFAULT 0,
              CicloTrabajo TINYINT DEFAULT 0,
              PasActual TINYINT DEFAULT 0,
              St_Carro TINYINT DEFAULT 0
            )
          `;
          
          await query(createCTTableSql);
          logger.info('Tabla CT_Status creada en MariaDB');
          
          // Insertar el primer registro
          const insertCTSql = `
            INSERT INTO CT_Status (StConectado, StDefecto, St_Auto, St_Semi, St_Manual, St_Puerta, St_Datos, 
                                  MatEntrada, MatSalida, PasDestino, CicloTrabajo, PasActual, St_Carro) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `;
          
          // Extraer los valores de los datos formateados
          const ctValues = [
            data.data.status['Status-Conectado'] === true ? 1 : 0,
            data.data.status['Status-Defecto'] === true ? 1 : 0,
            data.data.status['Status-Automático'] === true ? 1 : 0,
            data.data.status['Status-Semiautomático'] === true ? 1 : 0,
            data.data.status['Status-Manual'] === true ? 1 : 0,
            data.data.status['Status-Emergencia puerta armario'] === true ? 1 : 0,
            data.data.status['Status-Con datos'] === true ? 1 : 0,
            data.data.matriculas['Matrícula paleta en transportador de entrada'] || 0,
            data.data.matriculas['Matrícula paleta en transportador de salida'] || 0,
            data.data.pasillos['Pasillo destino'] || 0,
            data.data.pasillos['Ciclo de trabajo'] || 0, // Corregido: 'Ciclo de trabajo' en lugar de 'Ciclo trabajo'
            data.data.pasillos['Numero de pasillo actual'] || 0,
            data.data.pasillos['Estado carro (0=Libre 1=Ocupado 2=Avería)'] || 0
          ];
          
          await query(insertCTSql, ctValues);
          logger.info('Primer registro insertado en la tabla CT_Status');
        } else {
          // Actualizar el registro existente en CT_Status
          const updateCTSql = `
            UPDATE CT_Status 
            SET StConectado = ?, StDefecto = ?, St_Auto = ?, St_Semi = ?, St_Manual = ?, St_Puerta = ?, St_Datos = ?,
                MatEntrada = ?, MatSalida = ?, PasDestino = ?, CicloTrabajo = ?, PasActual = ?, St_Carro = ?,
                timestamp = CURRENT_TIMESTAMP
            WHERE id = 1
          `;
          
          // Extraer los valores de los datos formateados
          const ctValues = [
            data.data.status['Status-Conectado'] === true ? 1 : 0,
            data.data.status['Status-Defecto'] === true ? 1 : 0,
            data.data.status['Status-Automático'] === true ? 1 : 0,
            data.data.status['Status-Semiautomático'] === true ? 1 : 0,
            data.data.status['Status-Manual'] === true ? 1 : 0,
            data.data.status['Status-Emergencia puerta armario'] === true ? 1 : 0,
            data.data.status['Status-Con datos'] === true ? 1 : 0,
            data.data.matriculas['Matrícula paleta en transportador de entrada'] || 0,
            data.data.matriculas['Matrícula paleta en transportador de salida'] || 0,
            data.data.pasillos['Pasillo destino'] || 0,
            data.data.pasillos['Ciclo de trabajo'] || 0, // Corregido: 'Ciclo de trabajo' en lugar de 'Ciclo trabajo'
            data.data.pasillos['Numero de pasillo actual'] || 0,
            data.data.pasillos['Estado carro (0=Libre 1=Ocupado 2=Avería)'] || 0
          ];
          
          await query(updateCTSql, ctValues);
          logger.info('Registro actualizado en la tabla CT_Status');
        }
      } catch (ctError) {
        logger.error(`Error al actualizar la tabla CT_Status: ${ctError}`);
        // No lanzamos el error para que no afecte a la actualización de DB112_Status
      }
    } catch (error) {
      logger.error(`Error al actualizar la tabla DB112_Status: ${error}`);
      throw error;
    }
  }
  
  /**
   * Método para actualizar directamente la tabla CT_Status con los valores leídos del PLC
   * @param values Valores leídos del PLC
   */
  private async updateCTStatusDirectly(values: Record<string, any>): Promise<void> {
    try {
      // Verificar si la tabla CT_Status existe
      const checkCTTableSql = `
        SELECT COUNT(*) as count 
        FROM information_schema.tables 
        WHERE table_schema = DATABASE() 
        AND table_name = 'CT_Status'
      `;
      
      const [checkCTResult] = await query(checkCTTableSql);
      
      if (checkCTResult.count === 0) {
        // Crear la tabla CT_Status si no existe
        logger.info('Creando tabla CT_Status en MariaDB');
        
        const createCTTableSql = `
          CREATE TABLE CT_Status (
            id INT AUTO_INCREMENT PRIMARY KEY,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            StConectado TINYINT DEFAULT 0,
            StDefecto TINYINT DEFAULT 0,
            St_Auto TINYINT DEFAULT 0,
            St_Semi TINYINT DEFAULT 0,
            St_Manual TINYINT DEFAULT 0,
            St_Puerta TINYINT DEFAULT 0,
            St_Datos TINYINT DEFAULT 0,
            MatEntrada INT DEFAULT 0,
            MatSalida INT DEFAULT 0,
            PasDestino TINYINT DEFAULT 0,
            CicloTrabajo TINYINT DEFAULT 0,
            PasActual TINYINT DEFAULT 0,
            St_Carro TINYINT DEFAULT 0
          )
        `;
        
        await query(createCTTableSql);
        logger.info('Tabla CT_Status creada en MariaDB');
        
        // Insertar el primer registro
        const insertCTSql = `
          INSERT INTO CT_Status (StConectado, StDefecto, St_Auto, St_Semi, St_Manual, St_Puerta, St_Datos, 
                                MatEntrada, MatSalida, PasDestino, CicloTrabajo, PasActual, St_Carro) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        
        const ctValues = [
          values['DB112,X130.0'] === true ? 1 : 0,  // StConectado
          values['DB112,X130.1'] === true ? 1 : 0,  // StDefecto
          values['DB112,X130.2'] === true ? 1 : 0,  // St_Auto
          values['DB112,X130.3'] === true ? 1 : 0,  // St_Semi
          values['DB112,X130.4'] === true ? 1 : 0,  // St_Manual
          values['DB112,X130.5'] === true ? 1 : 0,  // St_Puerta
          values['DB112,X130.6'] === true ? 1 : 0,  // St_Datos
          values['DB112,W132'] || 0,               // MatEntrada
          values['DB112,W134'] || 0,               // MatSalida
          values['DB112,B136'] || 0,               // PasDestino
          values['DB112,B137'] || 0,               // CicloTrabajo
          values['DB112,B140'] || 0,               // PasActual
          values['DB112,B141'] || 0                // St_Carro
        ];
        
        await query(insertCTSql, ctValues);
        logger.info('Primer registro insertado en la tabla CT_Status');
      } else {
        // Actualizar el registro existente en CT_Status
        const updateCTSql = `
          UPDATE CT_Status 
          SET StConectado = ?, StDefecto = ?, St_Auto = ?, St_Semi = ?, St_Manual = ?, St_Puerta = ?, St_Datos = ?,
              MatEntrada = ?, MatSalida = ?, PasDestino = ?, CicloTrabajo = ?, PasActual = ?, St_Carro = ?,
              timestamp = CURRENT_TIMESTAMP
          WHERE id = 1
        `;
        
        const ctValues = [
          values['DB112,X130.0'] === true ? 1 : 0,  // StConectado
          values['DB112,X130.1'] === true ? 1 : 0,  // StDefecto
          values['DB112,X130.2'] === true ? 1 : 0,  // St_Auto
          values['DB112,X130.3'] === true ? 1 : 0,  // St_Semi
          values['DB112,X130.4'] === true ? 1 : 0,  // St_Manual
          values['DB112,X130.5'] === true ? 1 : 0,  // St_Puerta
          values['DB112,X130.6'] === true ? 1 : 0,  // St_Datos
          values['DB112,W132'] || 0,               // MatEntrada
          values['DB112,W134'] || 0,               // MatSalida
          values['DB112,B136'] || 0,               // PasDestino
          values['DB112,B137'] || 0,               // CicloTrabajo
          values['DB112,B140'] || 0,               // PasActual
          values['DB112,B141'] || 0                // St_Carro
        ];
        
        await query(updateCTSql, ctValues);
        logger.info('Registro actualizado en la tabla CT_Status');
      }
    } catch (error: any) {
      logger.error(`Error al actualizar la tabla CT_Status: ${error.message}`);
      throw error;
    }
  }
  
  /**
   * Método para sincronizar los datos del DB112 con la tabla CT_Status
   */
  async syncDB112ToCT(): Promise<void> {
    console.log('Iniciando sincronización DB112 con CT_Status...');
    try {
      // Actualizar manualmente la tabla CT_Status con datos de prueba
      // Esto es temporal para verificar que la tabla se puede actualizar correctamente
      try {
        const updateCTSql = `
          UPDATE CT_Status 
          SET StConectado = ?, StDefecto = ?, St_Auto = ?, St_Semi = ?, St_Manual = ?, St_Puerta = ?, St_Datos = ?,
              MatEntrada = ?, MatSalida = ?, PasDestino = ?, CicloTrabajo = ?, PasActual = ?, St_Carro = ?,
              timestamp = CURRENT_TIMESTAMP
          WHERE id = 1
        `;
        
        // Valores de prueba para actualizar la tabla
        const testValues = [
          1, // StConectado
          0, // StDefecto
          1, // St_Auto
          0, // St_Semi
          0, // St_Manual
          0, // St_Puerta
          1, // St_Datos
          123, // MatEntrada
          456, // MatSalida
          5, // PasDestino
          2, // CicloTrabajo
          7, // PasActual
          1  // St_Carro
        ];
        
        await query(updateCTSql, testValues);
        logger.info('Registro de prueba actualizado en la tabla CT_Status');
        return; // Salir del método después de actualizar los datos de prueba
      } catch (testError: any) {
        logger.error(`Error al actualizar datos de prueba en CT_Status: ${testError.message}`);
        // Continuar con el método normal si falla la actualización de prueba
      }
      
      // El resto del método se ejecutará solo si falla la actualización de prueba
      // Crear una nueva conexión al PLC para esta solicitud
      const conn = new nodes7();
      
      // Configurar la conexión al PLC
      await new Promise<void>((resolve, reject) => {
        conn.initiateConnection(
          {
            host: process.env.PLC_IP || '10.21.178.100',
            port: parseInt(process.env.PLC_PORT || '102'),
            rack: parseInt(process.env.PLC_RACK || '0'),
            slot: parseInt(process.env.PLC_SLOT || '3'),
            timeout: 5000
          },
          (err: any) => {
            if (err) {
              logger.error(`Error al conectar con el PLC: ${err}`);
              reject(err);
              return;
            }
            
            logger.info('Conexión establecida con el PLC para sincronizar DB112');
            resolve();
          }
        );
      }).catch(err => {
        console.error(`Error al conectar con el PLC: ${err}`);
        throw err; // Re-lanzar para salir de la función
      });
      
      // Configurar la función de traducción antes de añadir las variables
      conn.setTranslationCB((tag: string) => {
        try {
          return this.translateTag(tag);
        } catch (error) {
          logger.error(`Error al traducir tag ${tag}: ${error}`);
          // Devolver un valor por defecto para evitar errores
          return { address: `DB112.DBX0.0`, datatype: 'BOOL' };
        }
      });
      
      // Añadir variables a la conexión una por una para evitar problemas
      try {
        const variableKeys = Object.keys(this.variables);
        for (const key of variableKeys) {
          conn.addItems(key);
        }
        logger.info(`Se han añadido ${variableKeys.length} variables a la conexión para sincronización manual`);
      } catch (addError) {
        logger.error(`Error al añadir variables a la conexión: ${addError}`);
        throw addError;
      }
      
      // Leer las variables del PLC
      const values = await new Promise<Record<string, any>>((resolve, reject) => {
        conn.readAllItems((err: any, values: Record<string, any>) => {
          if (err) {
            logger.error(`Error al leer datos del PLC: ${err}`);
            reject(err);
            return;
          }
          
          logger.info('Datos del DB112 leídos correctamente');
          resolve(values);
        });
      }).catch(err => {
        console.error(`Error al leer datos del PLC: ${err}`);
        throw err; // Re-lanzar para salir de la función
      });
      
      // Añadir log para depuración
      console.log('Valores leídos del PLC:', JSON.stringify(values, null, 2));
      
      // Formatear los datos
      const formattedData = this.formatPLCData(values);
      
      // Añadir log para depuración
      console.log('Datos formateados:', JSON.stringify(formattedData, null, 2));
      
      // Actualizar la base de datos
      try {
        await this.updateDB112Table(formattedData);
        logger.info('Datos del DB112 actualizados en la base de datos');
      } catch (dbError) {
        logger.error(`Error al actualizar la base de datos: ${dbError}`);
        // No devolvemos error al cliente, solo lo registramos
      }
      
      // Cerrar la conexión con el PLC
      conn.dropConnection();
      logger.info('Conexión con el PLC cerrada después de sincronizar DB112');
    } catch (error: any) {
      console.error(`Error al sincronizar datos del DB112: ${error.message}`);
    }
  }
  
  /**
   * Método para configurar la sincronización programada
   */
  setupScheduledSync(intervalSeconds: number = 30): void {
    // Limpiar el intervalo existente si hay uno
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
    
    const intervalMs = intervalSeconds * 1000;
    logger.info(`Configurando sincronización programada del DB112 cada ${intervalSeconds} segundos`);
    
    // Configurar el nuevo intervalo
    this.syncInterval = setInterval(async () => {
      try {
        logger.info('Iniciando sincronización programada del DB112');
        
        // Crear una nueva conexión al PLC
        const conn = new nodes7();
        
        // Parámetros de conexión al PLC
        const connectionParams = {
          host: process.env.PLC_IP || '10.21.178.100',
          port: parseInt(process.env.PLC_PORT || '102'),
          rack: parseInt(process.env.PLC_RACK || '0'),
          slot: parseInt(process.env.PLC_SLOT || '3'),
          timeout: 5000
        };
        
        try {
          // Conectar al PLC - siguiendo el patrón de PTMariaDBController
          await new Promise<void>((resolve, reject) => {
            conn.initiateConnection(connectionParams, (err: any) => {
              if (err) {
                logger.error(`Error al conectar con el PLC para DB112: ${err}`);
                reject(err);
                return;
              }
              
              logger.info('Conexión con el PLC establecida correctamente para leer DB112');
              
              // Añadir variables para leer - siguiendo el patrón de PTMariaDBController
              // Usamos un conjunto reducido de variables clave para evitar problemas
              const variablesToRead = [
                'DB112,X130.0', // StConectado
                'DB112,X130.1', // StDefecto
                'DB112,X130.2', // St_Auto
                'DB112,X130.3', // St_Semi
                'DB112,X130.4', // St_Manual
                'DB112,X130.5', // St_Puerta
                'DB112,X130.6', // St_Datos
                'DB112,W132',   // MatEntrada
                'DB112,W134',   // MatSalida
                'DB112,B136',   // PasDestino
                'DB112,B137',   // CicloTrabajo
                'DB112,B140',   // PasActual
                'DB112,B141'    // St_Carro
              ];
              
              conn.addItems(variablesToRead);
              logger.info(`Se han añadido ${variablesToRead.length} variables clave a la conexión`);
              
              // Leer todas las variables
              conn.readAllItems((err: any, values: any) => {
                // Desconectar del PLC después de leer
                conn.dropConnection(() => {
                  logger.info('Desconectado del PLC después de leer valores del DB112');
                });
                
                if (err) {
                  logger.error(`Error al leer valores del PLC para DB112: ${err}`);
                  reject(err);
                  return;
                }
                
                // Mostrar los valores crudos exactos que se leen del PLC
                console.log('\n==== VALORES CRUDOS LEÍDOS DEL PLC (DB112) ====');
                console.log(JSON.stringify(values, null, 2));
                console.log('===============================================\n');
                
                // Verificar si los valores del PLC son válidos
                const hasValidValues = Object.values(values).some(value => 
                  value !== null && value !== undefined);
                
                if (hasValidValues) {
                  logger.info('Valores del DB112 leídos correctamente del PLC');
                  
                  // Actualizar directamente la tabla CT_Status con los valores leídos
                  this.updateCTStatusDirectly(values)
                    .then(() => {
                      logger.info('Tabla CT_Status actualizada correctamente');
                      resolve();
                    })
                    .catch((dbError: any) => {
                      logger.error(`Error al actualizar la tabla CT_Status: ${dbError}`);
                      reject(dbError);
                    });
                } else {
                  reject(new Error('No se obtuvieron valores válidos del PLC para el DB112'));
                }
              });
            });
          });
        } catch (error) {
          logger.error(`Error en la sincronización programada del DB112: ${error}`);
        }
      } catch (error) {
        logger.error(`Error general en la sincronización programada del DB112: ${error}`);
      }
    }, intervalMs);
    
    logger.info(`Sincronización automática del DB112 configurada cada ${intervalSeconds} segundos`);
  }
  
  /**
   * Método para detener la sincronización programada
   */
  stopScheduledSync(): void {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
      logger.info('Sincronización programada del DB112 detenida');
    }
  }
  
  /**
   * Método para obtener el estado actual del DB112 (consultando la tabla CT_Status)
   */
  async getDB112Status(req: Request, res: Response): Promise<void> {
    try {
      // Consultar el estado actual en la tabla CT_Status en lugar de DB112_Status
      const rows = await query('SELECT * FROM CT_Status WHERE id = 1');
      
      if (!rows || rows.length === 0) {
        res.status(404).json({
          success: false,
          message: 'No se encontraron datos del Carro Transferidor (CT)'
        });
        return;
      }
      
      // Formatear los datos para la respuesta
      const ctData = rows[0];
      logger.info(`Datos del CT obtenidos correctamente: ${JSON.stringify(ctData)}`);
      
      res.json({
        success: true,
        data: ctData
      });
    } catch (error: any) {
      logger.error(`Error al obtener el estado del Carro Transferidor (CT): ${error}`);
      res.status(500).json({
        success: false,
        message: 'Error al consultar la base de datos',
        error: error.message
      });
    }
  }

  /**
   * Método para obtener el estado actual del CT desde la base de datos
   */
  async getCTStatus(): Promise<any> {
    try {
      // Consultar la tabla CT_Status para obtener el último registro
      const rows = await query('SELECT * FROM CT_Status ORDER BY id DESC LIMIT 1');
      
      if (!rows || rows.length === 0) {
        logger.warn('No se encontraron datos en la tabla CT_Status');
        return null;
      }
      
      logger.info(`Datos del CT obtenidos correctamente: ${JSON.stringify(rows[0])}`);
      return rows[0];
    } catch (error: any) {
      logger.error(`Error al consultar la tabla CT_Status: ${error}`);
      throw error;
    }
  }
}
