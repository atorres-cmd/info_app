// src/controllers/pasMariaDBController.js
const { query } = require('../db/mariadb-config');
const { logger } = require('../utils/logger');
const nodes7 = require('nodes7');

/**
 * Controlador para sincronizar datos de pasillos del PLC con la tabla Pas_Status de MariaDB
 */
class PasMariaDBController {
  /**
   * Lee los datos de pasillos del PLC y los guarda en la tabla Pas_Status
   * @param {Object} req - Objeto de solicitud Express
   * @param {Object} res - Objeto de respuesta Express
   */
  async syncPLCToDatabase(req, res) {
    try {
      // Leer datos del PLC
      const plcData = await this.readPLCData();
      
      if (!plcData) {
        return res.status(500).json({
          success: false,
          message: 'No se pudieron leer los datos de pasillos del PLC'
        });
      }
      
      // Convertir datos del PLC al formato de la tabla Pas_Status
      const dbData = this.convertPLCDataToDBFormat(plcData);
      
      // Guardar datos en la base de datos
      await this.saveToDatabase(dbData);
      
      // Responder con los datos guardados
      res.json({
        success: true,
        message: 'Datos de pasillos sincronizados correctamente',
        data: dbData
      });
    } catch (error) {
      logger.error('Error al sincronizar datos de pasillos con MariaDB:', error);
      res.status(500).json({
        success: false,
        message: 'Error al sincronizar datos de pasillos',
        error: error.message
      });
    }
  }
  
  /**
   * Lee los datos de pasillos del PLC utilizando nodes7
   * @returns {Promise<Object>} Datos leídos del PLC
   */
  async readPLCData() {
    const conn = new nodes7();
    
    // Configuración de conexión al PLC
    const connectionParams = {
      host: process.env.PLC_IP || '10.21.178.100',
      port: 102,
      rack: parseInt(process.env.PLC_RACK || '0'),
      slot: parseInt(process.env.PLC_SLOT || '3'),
      timeout: 5000
    };
    
    try {
      // Crear una promesa para manejar la conexión asíncrona
      return await new Promise((resolve, reject) => {
        // Conectar al PLC
        conn.initiateConnection(connectionParams, (err) => {
          if (err) {
            logger.error('Error al conectar con el PLC para leer estado de pasillos:', err);
            reject(err);
            return;
          }
          
          // Añadir variables para leer (estado de pasillos P1 a P12)
          const statusPasillos = [
            'DB110,B10', 'DB110,B11', 'DB110,B12', 'DB110,B13', 'DB110,B14', 
            'DB110,B15', 'DB110,B16', 'DB110,B17', 'DB110,B18', 'DB110,B19', 
            'DB110,B20', 'DB110,B21'
          ];
          
          conn.addItems(statusPasillos);
          
          // Leer todas las variables
          conn.readAllItems((err, values) => {
            // Desconectar del PLC después de leer
            conn.dropConnection(() => {
              logger.info('Desconectado del PLC después de leer valores de pasillos');
            });
            
            if (err) {
              logger.error('Error al leer valores de pasillos del PLC:', err);
              reject(err);
              return;
            }
            
            // Mostrar los valores crudos exactos que se leen del PLC
            console.log('\n==== VALORES CRUDOS LEÍDOS DEL PLC (PASILLOS) ====');
            console.log(JSON.stringify(values, null, 2));
            console.log('===============================================\n');
            
            // Verificar si los valores del PLC son válidos
            const hasValidValues = Object.values(values).some(value => 
              value !== null && value !== undefined);
            
            if (hasValidValues) {
              resolve(values);
            } else {
              logger.warn('No se obtuvieron valores válidos del PLC para pasillos');
              reject(new Error('No se obtuvieron valores válidos del PLC para pasillos'));
            }
          });
        });
      });
    } catch (error) {
      logger.error('Error al leer datos de pasillos del PLC:', error);
      return null;
    }
  }
  
  /**
   * Convierte los datos del PLC al formato de la tabla Pas_Status
   * @param {Object} plcData - Datos leídos del PLC
   * @returns {Object} Datos en formato para la tabla Pas_Status
   */
  convertPLCDataToDBFormat(plcData) {
    // Mapear los valores de los pasillos (P1 a P12)
    return {
      pas1: plcData['DB110,B10'] !== undefined ? plcData['DB110,B10'] : 0,
      pas2: plcData['DB110,B11'] !== undefined ? plcData['DB110,B11'] : 0,
      pas3: plcData['DB110,B12'] !== undefined ? plcData['DB110,B12'] : 0,
      pas4: plcData['DB110,B13'] !== undefined ? plcData['DB110,B13'] : 0,
      pas5: plcData['DB110,B14'] !== undefined ? plcData['DB110,B14'] : 0,
      pas6: plcData['DB110,B15'] !== undefined ? plcData['DB110,B15'] : 0,
      pas7: plcData['DB110,B16'] !== undefined ? plcData['DB110,B16'] : 0,
      pas8: plcData['DB110,B17'] !== undefined ? plcData['DB110,B17'] : 0,
      pas9: plcData['DB110,B18'] !== undefined ? plcData['DB110,B18'] : 0,
      pas10: plcData['DB110,B19'] !== undefined ? plcData['DB110,B19'] : 0,
      pas11: plcData['DB110,B20'] !== undefined ? plcData['DB110,B20'] : 0,
      pas12: plcData['DB110,B21'] !== undefined ? plcData['DB110,B21'] : 0
    };
  }
  
  /**
   * Guarda los datos en la tabla Pas_Status
   * @param {Object} data - Datos a guardar
   * @returns {Promise<void>}
   */
  async saveToDatabase(data) {
    try {
      console.log('Guardando datos de pasillos en MariaDB:', data);
      
      // Verificar si ya existe un registro con id=1
      const checkResult = await query('SELECT COUNT(*) as count FROM Pas_Status WHERE id = 1');
      
      // Manejar diferentes formatos de resultado
      let count = 0;
      if (Array.isArray(checkResult) && checkResult.length > 0) {
        if (checkResult[0] && Array.isArray(checkResult[0]) && checkResult[0].length > 0) {
          count = checkResult[0][0].count || 0;
        } else if (checkResult[0] && typeof checkResult[0] === 'object') {
          count = checkResult[0].count || 0;
        }
      }
      
      // Construir la consulta SQL
      let sql = '';
      const values = [
        data.pas1, data.pas2, data.pas3, data.pas4, data.pas5, data.pas6,
        data.pas7, data.pas8, data.pas9, data.pas10, data.pas11, data.pas12
      ];
      
      if (count > 0) {
        // Actualizar el registro existente con id=1
        sql = `
          UPDATE Pas_Status 
          SET 
            pas1 = ?, pas2 = ?, pas3 = ?, pas4 = ?, pas5 = ?, pas6 = ?,
            pas7 = ?, pas8 = ?, pas9 = ?, pas10 = ?, pas11 = ?, pas12 = ?,
            timestamp = CURRENT_TIMESTAMP
          WHERE id = 1
        `;
      } else {
        // Insertar un nuevo registro con id=1
        sql = `
          INSERT INTO Pas_Status 
          (id, pas1, pas2, pas3, pas4, pas5, pas6, pas7, pas8, pas9, pas10, pas11, pas12)
          VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
      }
      
      // Ejecutar la consulta
      await query(sql, values);
      
      logger.info('Datos de pasillos guardados correctamente en MariaDB');
    } catch (error) {
      logger.error('Error al guardar datos de pasillos en MariaDB:', error);
      throw error;
    }
  }
  
  /**
   * Configura una tarea programada para sincronizar datos periódicamente
   * @param {number} intervalSeconds - Intervalo en segundos
   */
  setupScheduledSync(intervalSeconds = 30) {
    // Configurar intervalo para sincronización automática
    setInterval(async () => {
      try {
        console.log(`Ejecutando sincronización automática de pasillos (cada ${intervalSeconds} segundos)...`);
        
        // Leer datos del PLC
        const plcData = await this.readPLCData();
        
        if (plcData) {
          // Convertir datos del PLC al formato de la tabla Pas_Status
          const dbData = this.convertPLCDataToDBFormat(plcData);
          
          // Guardar datos en la base de datos
          await this.saveToDatabase(dbData);
          
          logger.info('Sincronización automática de pasillos completada');
        } else {
          logger.warn('No se pudieron leer datos del PLC para la sincronización automática de pasillos');
        }
      } catch (error) {
        logger.error('Error en la sincronización automática de pasillos:', error);
      }
    }, intervalSeconds * 1000);
    
    logger.info(`Sincronización automática de pasillos configurada cada ${intervalSeconds} segundos`);
  }
  
  /**
   * Inicializa la tabla Pas_Status en MariaDB
   * @returns {Promise<void>}
   */
  async initPasStatusTable() {
    try {
      // Crear tabla Pas_Status si no existe
      await query(`
        CREATE TABLE IF NOT EXISTS Pas_Status (
          id INT AUTO_INCREMENT PRIMARY KEY,
          pas1 INT DEFAULT 0,
          pas2 INT DEFAULT 0,
          pas3 INT DEFAULT 0,
          pas4 INT DEFAULT 0,
          pas5 INT DEFAULT 0,
          pas6 INT DEFAULT 0,
          pas7 INT DEFAULT 0,
          pas8 INT DEFAULT 0,
          pas9 INT DEFAULT 0,
          pas10 INT DEFAULT 0,
          pas11 INT DEFAULT 0,
          pas12 INT DEFAULT 0,
          timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
      `);
      
      // Verificar si hay datos en la tabla
      const result = await query('SELECT COUNT(*) as count FROM Pas_Status');
      
      // Manejar diferentes formatos de resultado
      let count = 0;
      if (Array.isArray(result) && result.length > 0) {
        // Si el resultado es un array (como [rows, fields])
        if (result[0] && Array.isArray(result[0]) && result[0].length > 0) {
          count = result[0][0].count || 0;
        } else if (result[0] && typeof result[0] === 'object') {
          count = result[0].count || 0;
        }
      }
      
      logger.info(`Verificación de datos en Pas_Status: ${count} registros encontrados`);
      
      // Si no hay datos, insertar datos iniciales con id=1
      if (count === 0) {
        await query(`
          INSERT INTO Pas_Status 
          (id, pas1, pas2, pas3, pas4, pas5, pas6, pas7, pas8, pas9, pas10, pas11, pas12)
          VALUES (1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
        `);
        logger.info('Datos iniciales para Pas_Status insertados correctamente');
      }
      
      logger.info('Tabla Pas_Status creada o ya existente');
    } catch (error) {
      logger.error('Error al inicializar la tabla Pas_Status:', error);
      throw error;
    }
  }
  
  /**
   * Obtiene los datos actuales de pasillos desde MariaDB
   * @param {Object} req - Objeto de solicitud Express
   * @param {Object} res - Objeto de respuesta Express
   */
  async getPasStatus(req, res) {
    try {
      console.log('Ejecutando getPasStatus para obtener datos de pasillos desde MariaDB...');
      
      // Obtener la fila con id=1 de la tabla Pas_Status (que es la que siempre actualizamos)
      const result = await query('SELECT * FROM Pas_Status WHERE id = 1');
      
      // Imprimir el resultado completo para depuración
      console.log('Resultado completo de la consulta Pas_Status:', JSON.stringify(result, null, 2));
      
      // Manejar diferentes formatos de resultado
      let rows = [];
      if (Array.isArray(result)) {
        if (result.length > 0) {
          rows = result;
        }
      } else if (result && Array.isArray(result.rows)) {
        rows = result.rows;
      }
      
      console.log(`Se encontraron ${rows.length} registros en Pas_Status`);
      
      if (rows.length > 0) {
        const pasData = rows[0];
        console.log('Datos de pasillos encontrados:', JSON.stringify(pasData, null, 2));
        
        res.json(pasData);
      } else {
        console.log('No se encontraron datos de pasillos en la base de datos');
        res.status(404).json({
          success: false,
          message: 'No se encontraron datos de pasillos'
        });
      }
    } catch (error) {
      logger.error('Error al obtener datos de pasillos desde MariaDB:', error);
      console.error('Error completo:', error);
      res.status(500).json({
        success: false,
        message: 'Error al obtener datos de pasillos',
        error: error.message
      });
    }
  }
}

// Inicializar la tabla Pas_Status al cargar el módulo
const pasController = new PasMariaDBController();
pasController.initPasStatusTable()
  .then(() => {
    // Iniciar sincronización automática cada 30 segundos
    pasController.setupScheduledSync(30);
  })
  .catch(error => {
    logger.error('Error al inicializar el controlador de pasillos:', error);
  });

module.exports = pasController;
