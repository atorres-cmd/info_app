/**
 * Script para iniciar solo el servidor MariaDB específico
 */

const { startMariaDBServer } = require('./utils/mariadb-server');
const { logger } = require('./utils/logger');

// Iniciar el servidor MariaDB específico
async function startServer() {
  try {
    logger.info('Iniciando servidor MariaDB específico en el puerto 3003...');
    const { server } = await startMariaDBServer();
    logger.success('Servidor MariaDB específico iniciado correctamente en el puerto 3003');
  } catch (error) {
    logger.error('Error al iniciar el servidor MariaDB específico:', error);
  }
}

// Ejecutar la función para iniciar el servidor
startServer();
