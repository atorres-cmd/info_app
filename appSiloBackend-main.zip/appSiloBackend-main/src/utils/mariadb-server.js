/**
 * Módulo para iniciar el servidor MariaDB específico
 * 
 * Este módulo exporta una función para iniciar el servidor MariaDB en el puerto 3003
 * y puede ser importado y utilizado por otros scripts.
 */

const express = require('express');
const cors = require('cors');
const { initializeDatabase } = require('../db/init-db');
const tlv1Routes = require('../routes/tlv1Routes');
const tlv1SyncRoutes = require('../routes/tlv1SyncRoutes');
const tlv1MariaDBController = require('../controllers/tlv1MariaDBController');
const tlv2Routes = require('../routes/tlv2Routes');
const tlv2SyncRoutes = require('../routes/tlv2SyncRoutes');
const tlv2MariaDBController = require('../controllers/tlv2MariaDBController');
const puenteRoutes = require('../routes/ptRoutes');
const puenteController = require('../controllers/ptMariaDBController');
const { logger } = require('./logger');

// Importar rutas y controlador para DB110 (mesas de entrada y salida)
const { DB110Controller } = require('../../dist/controllers/db110Controller');
const createDB110Routes = require('../../dist/routes/db110Routes').default;

// Importar rutas y controlador para DB112 (carro transferidor)
const { DB112Controller } = require('../../dist/controllers/db112Controller');
const createDB112Routes = require('../../dist/routes/db112Routes').default;

// Importar rutas para alarmas del CT (DB111)
const ctAlarmsRoutes = require('../../dist/routes/ctAlarmsRoutes').default;

// Importar rutas para alarmas del TLV1
const tlv1AlarmsRoutes = require('../routes/tlv1AlarmsRoutes');

/**
 * Inicia el servidor MariaDB específico en el puerto 3003
 * @returns {Promise<Express.Application>} La instancia de Express del servidor MariaDB
 */
async function startMariaDBServer() {
  try {
    // Crear una instancia de Express
    const app = express();

    // Configurar middleware
    app.use(cors());
    app.use(express.json());

    // Configurar rutas para MariaDB
    app.use('/api/mariadb/tlv1', tlv1Routes);
    app.use('/api/mariadb/tlv2', tlv2Routes);
    app.use('/api/mariadb/puente', puenteRoutes);

    // Configurar rutas para la sincronización PLC-MariaDB
    app.use('/api/mariadb/tlv1/sync', tlv1SyncRoutes);
    app.use('/api/mariadb/tlv2/sync', tlv2SyncRoutes);
    
    // Configurar rutas para DB110 (mesas de entrada y salida)
    const db110Controller = new DB110Controller();
    app.use('/api/mariadb/db110', createDB110Routes(db110Controller));
    
    // Configurar rutas para DB112 (carro transferidor)
    app.use('/api/mariadb/db112', createDB112Routes());
    
    // Configurar rutas para alarmas del CT (DB111)
    app.use('/api/mariadb/ct/alarmas', ctAlarmsRoutes);
    
    // Configurar rutas para alarmas del TLV1
    app.use('/api/mariadb/tlv1/alarmas', tlv1AlarmsRoutes);

    // Ruta de documentación
    app.get('/api/mariadb', (req, res) => {
      res.json({
        message: 'API de MariaDB para Operator Insight',
        endpoints: {
          tlv1: {
            getCurrent: 'GET /api/mariadb/tlv1',
            getHistory: 'GET /api/mariadb/tlv1/history?limit=100',
            update: 'POST /api/mariadb/tlv1'
          },
          tlv2: {
            getCurrent: 'GET /api/mariadb/tlv2',
            getHistory: 'GET /api/mariadb/tlv2/history?limit=100',
            update: 'POST /api/mariadb/tlv2'
          },
          puente: {
            getCurrent: 'GET /api/mariadb/puente',
            sync: 'POST /api/mariadb/puente/sync',
            plc: 'GET /api/mariadb/puente/plc'
          },
          db110: {
            values: 'GET /api/mariadb/db110/values',
            write: 'POST /api/mariadb/db110/write',
            mesasEntrada: {
              status: 'GET /api/mariadb/db110/mesasEntrada/status',
              sync: 'POST /api/mariadb/db110/mesasEntrada/sync'
            },
            mesasSalida: {
              status: 'GET /api/mariadb/db110/mesasSalida/status',
              sync: 'POST /api/mariadb/db110/mesasSalida/sync'
            }
          },
          db112: {
            read: 'GET /api/mariadb/db112/read'
          },
          ct_alarmas: {
            all: 'GET /api/mariadb/ct/alarmas',
            active: 'GET /api/mariadb/ct/alarmas/active',
            history: 'GET /api/mariadb/ct/alarmas/history',
            sync: 'POST /api/mariadb/ct/alarmas/sync'
          },
          tlv1_alarmas: {
            all: 'GET /api/mariadb/tlv1/alarmas',
            active: 'GET /api/mariadb/tlv1/alarmas/active',
            history: 'GET /api/mariadb/tlv1/alarmas/history',
            sync: 'POST /api/mariadb/tlv1/alarmas/sync'
          }
        }
      });
    });

    // Inicializar la base de datos
    logger.info('Inicializando la base de datos MariaDB...');
    await initializeDatabase();
    
    // Definir un puerto específico (3003) para evitar conflictos
    const PORT = 3003;
    
    // Iniciar el servidor
    const server = app.listen(PORT, () => {
      logger.info(`Servidor con integración de MariaDB iniciado en el puerto ${PORT}`);
      logger.info('Rutas disponibles:');
      logger.info('- Documentación API: http://localhost:' + PORT + '/api/mariadb');
      logger.info('- TLV1 Status: http://localhost:' + PORT + '/api/mariadb/tlv1');
      logger.info('- TLV1 Sync: http://localhost:' + PORT + '/api/mariadb/tlv1/sync/status');
      logger.info('- TLV2 Status: http://localhost:' + PORT + '/api/mariadb/tlv2');
      logger.info('- TLV2 Sync: http://localhost:' + PORT + '/api/mariadb/tlv2/sync/status');
      logger.info('- Puente Status: http://localhost:' + PORT + '/api/mariadb/puente');
      logger.info('- Puente Sync: http://localhost:' + PORT + '/api/mariadb/puente/sync');
      
      // Configurar sincronización automática cada 30 segundos
      const SYNC_INTERVAL_SECONDS = 30;
      logger.info(`Configurando sincronización automática PLC-MariaDB cada ${SYNC_INTERVAL_SECONDS} segundos...`);
      tlv1MariaDBController.setupScheduledSync(SYNC_INTERVAL_SECONDS);
      tlv2MariaDBController.startAutoSync(SYNC_INTERVAL_SECONDS * 1000);
      puenteController.setupScheduledSync(SYNC_INTERVAL_SECONDS);
      
      // Configurar sincronización automática de alarmas CT
      try {
        logger.info(`=== Configurando sincronización automática de alarmas CT cada ${SYNC_INTERVAL_SECONDS} segundos... ===`);
        
        // Configurar intervalo para sincronizar alarmas del CT
        const ctAlarmsInterval = setInterval(async () => {
          try {
            logger.info('=== INICIO: Sincronización programada de alarmas CT ===');
            
            // Ejecutar el script de sincronización de alarmas CT
            const syncScript = require('../../force-ct-alarms-sync');
            const result = await syncScript.syncCTAlarms();
            
            if (result && result.length > 0) {
              logger.info(`Alarmas CT actualizadas con timestamp: ${result[0].timestamp}`);
            }
            
            logger.info('=== FIN: Sincronización programada de alarmas CT completada ===');
          } catch (syncError) {
            logger.error(`=== ERROR: Sincronización programada de alarmas CT: ${syncError.message} ===`);
          }
        }, SYNC_INTERVAL_SECONDS * 1000);
        
        // Ejecutar inmediatamente la primera sincronización
        setTimeout(async () => {
          try {
            logger.info('=== INICIO: Primera sincronización de alarmas CT ===');
            const syncScript = require('../../force-ct-alarms-sync');
            await syncScript.syncCTAlarms();
            logger.info('=== FIN: Primera sincronización de alarmas CT completada ===');
          } catch (error) {
            logger.error(`=== ERROR: Primera sincronización de alarmas CT: ${error.message} ===`);
          }
        }, 5000);
        
        logger.info(`=== Sincronización automática de alarmas CT configurada cada ${SYNC_INTERVAL_SECONDS} segundos ===`);
      } catch (error) {
        logger.error(`Error al configurar la sincronización automática de alarmas CT: ${error.message}`);
      }
      
      // Configurar sincronización automática de alarmas TLV1
      try {
        logger.info(`=== Configurando sincronización automática de alarmas TLV1 cada ${SYNC_INTERVAL_SECONDS} segundos... ===`);
        
        // Configurar intervalo para sincronizar alarmas del TLV1
        const tlv1AlarmsInterval = setInterval(async () => {
          try {
            logger.info('=== INICIO: Sincronización programada de alarmas TLV1 ===');
            
            // Ejecutar el script de sincronización de alarmas TLV1
            const syncScript = require('../../force-tlv1-alarms-sync');
            const result = await syncScript.syncTLV1Alarms();
            
            if (result && result.length > 0) {
              logger.info(`Alarmas TLV1 actualizadas con timestamp: ${result[0].timestamp}`);
            }
            
            logger.info('=== FIN: Sincronización programada de alarmas TLV1 completada ===');
          } catch (syncError) {
            logger.error(`=== ERROR: Sincronización programada de alarmas TLV1: ${syncError.message} ===`);
          }
        }, SYNC_INTERVAL_SECONDS * 1000);
        
        // Ejecutar inmediatamente la primera sincronización
        setTimeout(async () => {
          try {
            logger.info('=== INICIO: Primera sincronización de alarmas TLV1 ===');
            const syncScript = require('../../force-tlv1-alarms-sync');
            await syncScript.syncTLV1Alarms();
            logger.info('=== FIN: Primera sincronización de alarmas TLV1 completada ===');
          } catch (error) {
            logger.error(`=== ERROR: Primera sincronización de alarmas TLV1: ${error.message} ===`);
          }
        }, 8000); // Ejecutar 3 segundos después de la sincronización de CT para evitar sobrecarga
        
        logger.info(`=== Sincronización automática de alarmas TLV1 configurada cada ${SYNC_INTERVAL_SECONDS} segundos ===`);
      } catch (error) {
        logger.error(`Error al configurar la sincronización automática de alarmas TLV1: ${error.message}`);
      }
    });

    return { app, server };
  } catch (error) {
    logger.error('Error al iniciar el servidor con integración de MariaDB:', error);
    throw error;
  }
}

module.exports = {
  startMariaDBServer
};
