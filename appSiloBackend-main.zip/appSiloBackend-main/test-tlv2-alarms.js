// Script para probar las alarmas del Transelevador 2 (TLV2)
require('dotenv').config();
const { query } = require('./src/db/mariadb-config');
const { logger } = require('./src/utils/logger');

async function testTLV2Alarms() {
  try {
    console.log('Simulando alarmas activas del Transelevador 2 (TLV2)...');
    
    // Verificar si existe algún registro en la tabla
    const checkSql = `SELECT COUNT(*) as count FROM TLV2_Alarmas`;
    const checkResult = await query(checkSql);
    
    // Si no hay registros, crear uno nuevo
    if (checkResult[0].count === 0) {
      console.log('No hay registros en la tabla TLV2_Alarmas. Creando uno nuevo...');
      const insertSql = `INSERT INTO TLV2_Alarmas (timestamp) VALUES (CURRENT_TIMESTAMP)`;
      await query(insertSql);
      console.log('Registro creado correctamente.');
    }
    
    // Activar algunas alarmas
    const updateSql = `
      UPDATE TLV2_Alarmas 
      SET 
        EMERGENCIA_GENERAL = TRUE,
        PUERTA_CABINA_ABIERTA = TRUE,
        EXCESO_RECORRIDO_ADELANTE = TRUE,
        timestamp = CURRENT_TIMESTAMP
      WHERE id = (SELECT id FROM TLV2_Alarmas ORDER BY id DESC LIMIT 1)
    `;
    
    await query(updateSql);
    console.log('Alarmas activadas: EMERGENCIA_GENERAL, PUERTA_CABINA_ABIERTA, EXCESO_RECORRIDO_ADELANTE');
    
    // Mostrar el registro actualizado
    const selectSql = `SELECT * FROM TLV2_Alarmas ORDER BY id DESC LIMIT 1`;
    const results = await query(selectSql);
    
    console.log('Registro actualizado:');
    console.log(JSON.stringify(results[0], null, 2));
    
    // Contar alarmas activas
    let activeAlarmCount = 0;
    for (const [key, value] of Object.entries(results[0])) {
      if (key !== 'id' && key !== 'timestamp' && value === 1) {
        activeAlarmCount++;
      }
    }
    
    console.log(`Total de alarmas activas: ${activeAlarmCount}`);
    console.log('Prueba completada con éxito.');
    
    // Opcional: Desactivar las alarmas después de un tiempo
    console.log('Esperando 10 segundos antes de desactivar las alarmas...');
    await new Promise(resolve => setTimeout(resolve, 10000));
    
    const resetSql = `
      UPDATE TLV2_Alarmas 
      SET 
        EMERGENCIA_GENERAL = FALSE,
        PUERTA_CABINA_ABIERTA = FALSE,
        EXCESO_RECORRIDO_ADELANTE = FALSE,
        timestamp = CURRENT_TIMESTAMP
      WHERE id = (SELECT id FROM TLV2_Alarmas ORDER BY id DESC LIMIT 1)
    `;
    
    await query(resetSql);
    console.log('Alarmas desactivadas.');
    
    // Mostrar el registro actualizado después de desactivar
    const finalResults = await query(selectSql);
    console.log('Registro final:');
    console.log(JSON.stringify(finalResults[0], null, 2));
    
  } catch (error) {
    console.error('Error al probar las alarmas del TLV2:', error);
    process.exit(1);
  }
}

// Ejecutar la función
testTLV2Alarms();
