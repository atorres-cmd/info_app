/**
 * Script para forzar una sincronización inmediata del DB112
 */
const db112Controller = require('./dist/controllers/db112Controller').default;

// Forzar la sincronización
console.log('Forzando sincronización del DB112...');
db112Controller.syncDB112ToCT()
  .then(() => {
    console.log('Sincronización completada');
    
    // Esperar 2 segundos y luego salir
    setTimeout(() => {
      process.exit(0);
    }, 2000);
  })
  .catch(err => {
    console.error('Error en la sincronización:', err);
    process.exit(1);
  });
