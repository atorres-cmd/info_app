// Script para verificar las actualizaciones en la tabla CT_Status
require('dotenv').config();
const { query } = require('./src/db/mariadb-config');

async function checkCTStatusUpdates() {
  try {
    console.log('Verificando actualizaciones en la tabla CT_Status...');
    
    // Consultar los datos actuales
    const selectDataSql = `SELECT * FROM CT_Status`;
    const currentData = await query(selectDataSql);
    
    console.log('Datos actuales en la tabla CT_Status:');
    console.log(JSON.stringify(currentData, null, 2));
    
    // Mostrar la última actualización
    if (currentData && currentData.length > 0) {
      const lastUpdate = currentData[0];
      console.log(`\nÚltima actualización: ${lastUpdate.timestamp}`);
      console.log(`Tiempo transcurrido desde la última actualización: ${Math.round((new Date() - new Date(lastUpdate.timestamp)) / 1000)} segundos`);
      
      // Mostrar los valores de los campos
      console.log('\nValores actuales:');
      console.log(`- StConectado: ${lastUpdate.StConectado}`);
      console.log(`- StDefecto: ${lastUpdate.StDefecto}`);
      console.log(`- St_Auto: ${lastUpdate.St_Auto}`);
      console.log(`- St_Semi: ${lastUpdate.St_Semi}`);
      console.log(`- St_Manual: ${lastUpdate.St_Manual}`);
      console.log(`- St_Puerta: ${lastUpdate.St_Puerta}`);
      console.log(`- St_Datos: ${lastUpdate.St_Datos}`);
      console.log(`- MatEntrada: ${lastUpdate.MatEntrada}`);
      console.log(`- MatSalida: ${lastUpdate.MatSalida}`);
      console.log(`- PasDestino: ${lastUpdate.PasDestino}`);
      console.log(`- CicloTrabajo: ${lastUpdate.CicloTrabajo}`);
      console.log(`- PasActual: ${lastUpdate.PasActual}`);
      console.log(`- St_Carro: ${lastUpdate.St_Carro}`);
    } else {
      console.log('No hay datos en la tabla CT_Status.');
    }
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

// Ejecutar la función principal
checkCTStatusUpdates();
