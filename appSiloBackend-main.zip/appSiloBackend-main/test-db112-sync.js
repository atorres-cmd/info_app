// Script para probar la sincronización del DB112 con la tabla CT_Status
const { DB112Controller } = require('./dist/controllers/db112Controller');

// Crear una instancia del controlador
const db112Controller = new DB112Controller();

// Ejecutar la sincronización
async function testSync() {
  console.log('Iniciando prueba de sincronización DB112 a CT_Status...');
  
  try {
    // Ejecutar la sincronización
    await db112Controller.syncDB112ToCT();
    console.log('Sincronización completada');
  } catch (error) {
    console.error('Error durante la sincronización:', error);
  }
}

// Ejecutar la prueba
testSync();
