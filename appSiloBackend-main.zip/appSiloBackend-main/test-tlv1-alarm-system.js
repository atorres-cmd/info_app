// Script para probar todo el sistema de alarmas del Transelevador 1 (TLV1) de principio a fin
require('dotenv').config();
const axios = require('axios');
const { query } = require('./src/db/mariadb-config');
const { logger } = require('./src/utils/logger');

// URL base para las peticiones API
const API_BASE_URL = process.env.API_BASE_URL || 'http://localhost:3000/api';

// Función para simular alarmas en la base de datos
async function simulateAlarmsInDatabase() {
  try {
    console.log('Simulando alarmas del TLV1 en la base de datos...');
    
    // Verificar si la tabla tiene registros
    const checkTableSql = `
      SELECT COUNT(*) as count 
      FROM TLV1_Alarmas
    `;
    
    const [checkResult] = await query(checkTableSql);
    
    if (checkResult.count === 0) {
      // No hay registros, insertar uno nuevo con algunas alarmas activas
      const insertSql = `
        INSERT INTO TLV1_Alarmas (
          EMERGENCIA_GENERAL,
          PUERTA_CABINA_ABIERTA,
          EXCESO_RECORRIDO_ADELANTE,
          EXCESO_RECORRIDO_ATRAS,
          EXCESO_RECORRIDO_SUBIDA,
          EXCESO_RECORRIDO_BAJADA,
          PARACAIDAS_ELEVACION,
          CABLES_FLOJOS_ELEVACION,
          PROTECCION_CONVERTIDOR_TRASLACION,
          PROTECCION_CONVERTIDOR_ELEVACION,
          PROTECCION_CONVERTIDOR_HORQUILLAS,
          timestamp
        ) VALUES (
          1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, CURRENT_TIMESTAMP
        )
      `;
      
      await query(insertSql);
      console.log('Primer registro insertado en la tabla TLV1_Alarmas con alarmas simuladas');
    } else {
      // Actualizar el registro existente (el más reciente) con algunas alarmas activas
      const updateSql = `
        UPDATE TLV1_Alarmas 
        SET 
          EMERGENCIA_GENERAL = 1,
          PUERTA_CABINA_ABIERTA = 0,
          EXCESO_RECORRIDO_ADELANTE = 1,
          EXCESO_RECORRIDO_ATRAS = 0,
          EXCESO_RECORRIDO_SUBIDA = 1,
          EXCESO_RECORRIDO_BAJADA = 0,
          PARACAIDAS_ELEVACION = 0,
          CABLES_FLOJOS_ELEVACION = 0,
          PROTECCION_CONVERTIDOR_TRASLACION = 1,
          PROTECCION_CONVERTIDOR_ELEVACION = 0,
          PROTECCION_CONVERTIDOR_HORQUILLAS = 0,
          timestamp = CURRENT_TIMESTAMP
        WHERE id = (SELECT id FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1)
      `;
      
      await query(updateSql);
      console.log('Registro actualizado en la tabla TLV1_Alarmas con alarmas simuladas');
    }
    
    // Consultar los datos actualizados
    const selectSql = `SELECT * FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1`;
    const selectResult = await query(selectSql);
    
    console.log('Datos actualizados en la tabla TLV1_Alarmas:');
    console.log(JSON.stringify(selectResult[0], null, 2));
    
    return true;
  } catch (error) {
    console.error('Error al simular alarmas del TLV1 en la base de datos:', error);
    return false;
  }
}

// Función para probar la API de alarmas del TLV1
async function testTLV1AlarmsAPI() {
  try {
    console.log('\nProbando la API de alarmas del TLV1...');
    
    // 1. Probar endpoint de sincronización
    console.log('1. Probando endpoint de sincronización...');
    const syncResponse = await axios.post(`${API_BASE_URL}/tlv1/alarmas/sync`);
    console.log('Respuesta de sincronización:', syncResponse.data);
    
    // 2. Probar endpoint de alarmas activas
    console.log('\n2. Probando endpoint de alarmas activas...');
    const activeAlarmsResponse = await axios.get(`${API_BASE_URL}/tlv1/alarmas/active`);
    console.log('Respuesta de alarmas activas:');
    console.log(JSON.stringify(activeAlarmsResponse.data, null, 2));
    
    // 3. Probar endpoint de todas las alarmas
    console.log('\n3. Probando endpoint de todas las alarmas...');
    const allAlarmsResponse = await axios.get(`${API_BASE_URL}/tlv1/alarmas`);
    console.log('Respuesta de todas las alarmas:');
    console.log(JSON.stringify(allAlarmsResponse.data, null, 2));
    
    return true;
  } catch (error) {
    console.error('Error al probar la API de alarmas del TLV1:', error);
    return false;
  }
}

// Función para desactivar todas las alarmas después de la prueba
async function resetAlarms() {
  try {
    console.log('\nDesactivando todas las alarmas del TLV1...');
    
    // Obtener todos los nombres de columnas de la tabla TLV1_Alarmas (excepto id y timestamp)
    const getColumnsSql = `
      SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = 'operator_insight'
      AND TABLE_NAME = 'TLV1_Alarmas'
      AND COLUMN_NAME NOT IN ('id', 'timestamp')
    `;
    
    const columnsResult = await query(getColumnsSql);
    const columns = columnsResult.map(col => col.COLUMN_NAME);
    
    // Construir la consulta SQL para desactivar todas las alarmas
    const setClause = columns.map(col => `${col} = 0`).join(', ');
    
    const resetSql = `
      UPDATE TLV1_Alarmas 
      SET ${setClause}, timestamp = CURRENT_TIMESTAMP
      WHERE id = (SELECT id FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1)
    `;
    
    await query(resetSql);
    console.log('Todas las alarmas del TLV1 han sido desactivadas');
    
    // Consultar los datos actualizados
    const selectSql = `SELECT * FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1`;
    const selectResult = await query(selectSql);
    
    console.log('Estado final de las alarmas del TLV1:');
    console.log(JSON.stringify(selectResult[0], null, 2));
    
    return true;
  } catch (error) {
    console.error('Error al desactivar las alarmas del TLV1:', error);
    return false;
  }
}

// Función principal para ejecutar todas las pruebas
async function runFullTest() {
  try {
    console.log('=== INICIANDO PRUEBA COMPLETA DEL SISTEMA DE ALARMAS TLV1 ===\n');
    
    // Paso 1: Simular alarmas en la base de datos
    console.log('=== PASO 1: SIMULACIÓN DE ALARMAS EN LA BASE DE DATOS ===');
    const dbSimulationResult = await simulateAlarmsInDatabase();
    if (!dbSimulationResult) {
      throw new Error('Error en la simulación de alarmas en la base de datos');
    }
    
    // Paso 2: Probar la API de alarmas
    console.log('\n=== PASO 2: PRUEBA DE LA API DE ALARMAS ===');
    const apiTestResult = await testTLV1AlarmsAPI();
    if (!apiTestResult) {
      throw new Error('Error en la prueba de la API de alarmas');
    }
    
    // Paso 3: Desactivar todas las alarmas
    console.log('\n=== PASO 3: DESACTIVACIÓN DE ALARMAS ===');
    const resetResult = await resetAlarms();
    if (!resetResult) {
      throw new Error('Error al desactivar las alarmas');
    }
    
    console.log('\n=== PRUEBA COMPLETA DEL SISTEMA DE ALARMAS TLV1 FINALIZADA CON ÉXITO ===');
    process.exit(0);
  } catch (error) {
    console.error('\n=== ERROR EN LA PRUEBA DEL SISTEMA DE ALARMAS TLV1 ===');
    console.error(error);
    process.exit(1);
  }
}

// Ejecutar la prueba completa
runFullTest();
