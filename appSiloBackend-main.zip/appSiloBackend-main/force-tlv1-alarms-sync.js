// Script para forzar la sincronización de alarmas del Transelevador 1 (TLV1) con datos reales del PLC
require('dotenv').config();
const { query } = require('./src/db/mariadb-config');
const nodes7 = require('nodes7');
const { logger } = require('./src/utils/logger');



async function syncTLV1Alarms() {
  try {
    console.log('Forzando sincronización de alarmas TLV1 con datos reales del PLC...');
    
    // Crear una conexión al PLC y leer los datos del DB111
    const conn = new nodes7();
    
    // Configuración de conexión al PLC
    const connectionParams = {
      host: process.env.PLC_IP || '10.21.178.100',
      port: 102,
      rack: parseInt(process.env.PLC_RACK || '0'),
      slot: parseInt(process.env.PLC_SLOT || '3'),
      timeout: 5000
    };
    
    // Variables de alarmas a leer para el TLV1 (basado en la imagen proporcionada)
    const alarmVariables = {
      'DB111,X40.0': 'EMERGENCIA_GENERAL',
      'DB111,X40.1': 'PUERTA_CABINA_ABIERTA',
      'DB111,X40.2': 'EXCESO_RECORRIDO_ADELANTE',
      'DB111,X40.3': 'EXCESO_RECORRIDO_ATRAS',
      'DB111,X40.4': 'EXCESO_RECORRIDO_SUBIDA',
      'DB111,X40.5': 'EXCESO_RECORRIDO_BAJADA',
      'DB111,X40.6': 'PARACAIDAS_ELEVACION',
      'DB111,X40.7': 'CABLES_FLOJOS_ELEVACION',
      'DB111,X41.0': 'PROTECCION_CONVERTIDOR_TRASLACION',
      'DB111,X41.1': 'PROTECCION_CONVERTIDOR_ELEVACION',
      'DB111,X41.2': 'PROTECCION_CONVERTIDOR_HORQUILLAS',
      'DB111,X41.3': 'PROTECCION_MOTOR_TRASLACION',
      'DB111,X41.4': 'PROTECCION_MOTOR_ELEVACION',
      'DB111,X41.5': 'PROTECCION_MOTOR_HORQUILLAS',
      'DB111,X41.6': 'PROTECCION_CONVERTIDOR_TRASLACION',
      'DB111,X41.7': 'PROTECCION_CONVERTIDOR_TRASLACION',
      'DB111,X42.0': 'DEFECTO_CONVERTIDOR_ELEVACION',
      'DB111,X42.1': 'DEFECTO_CONVERTIDOR_HORQUILLAS',
      'DB111,X42.2': 'EXCESO_VELOCIDAD_TRASLACION',
      'DB111,X42.3': 'EXCESO_VELOCIDAD_TRASLACION',
      'DB111,X42.4': 'DEFECTO_FOTOCELLULAS_DE_CENTRAJE_HORQUILLAS',
      'DB111,X42.5': 'DEFECTO_GIRO_TRASLACION',
      'DB111,X42.6': 'DEFECTO_GIRO_ELEVACION',
      'DB111,X42.7': 'DEFECTO_GIRO_HORQUILLAS',
      'DB111,X43.0': 'TIEMPO_CENTRAJE_TRASLACION',
      'DB111,X43.1': 'TIEMPO_CENTRAJE_ELEVACION',
      'DB111,X43.2': 'TIEMPO_CICLO_HORQUILLAS',
      'DB111,X43.3': 'TIEMPO_CICLO_TOPE_DE_SEGURIDAD',
      'DB111,X43.4': 'DEFECTO_DETECTORES_TRASLACION',
      'DB111,X43.5': 'DEFECTO_DETECTORES_ELEVACION',
      'DB111,X43.6': 'DEFECTO_DETECTORES_HORQUILLAS',
      'DB111,X43.7': 'DEFECTO_DETECTORES_TOPE_DE_SEGURIDAD',
      'DB111,X44.0': 'DEFECTO_IMPULSOR_ENCODER_TRASLACION',
      'DB111,X44.1': 'DEFECTO_IMPULSOR_ENCODER_ELEVACION',
      'DB111,X44.2': 'DEFECTO_IMPULSOR_ENCODER_HORQUILLAS',
      'DB111,X44.3': 'CONTADOR_IMPULSOR_ENCODER_TRASL_DESFASADO',
      'DB111,X44.4': 'CONTADOR_IMPULSOR_ENCODER_ELEV_DESFASADO',
      'DB111,X44.5': 'DEFECTO_COMUNICACION_PERIFERIA',
      'DB111,X44.6': 'DEFECTO_FOTOCELLULAS_DE_CENTRAJE_TRASLACION',
      'DB111,X44.7': 'DEFECTOS_DETECTORES_LECTURA_PASILLO',
      'DB111,X45.0': 'DEFECTO_CHOPPER_FRENADO_ELEVACION',
      'DB111,X45.1': 'DEFECTO_DE_GALIBO',
      'DB111,X45.2': 'DEFECTO_PRESENCIA_DE_PALETA',
      'DB111,X45.3': 'DEF_FOTOCELLULAS_PALPADORAS',
      'DB111,X45.4': 'DEF_FOTOC_PUENTE_ENCARGADO',
      'DB111,X45.5': 'PASILLO_FUERA_DE_SERVICIO',
      'DB111,X45.6': 'DEF_NR_DE_PASILLO',
      'DB111,X45.7': 'DEFECTO_TENSION_24VCC',
      'DB111,X46.0': 'DEFECTO_TENSION_PERIFERICOS_220_VCA',
      'DB111,X46.1': 'DEF_DESTINO_INCORRECTO',
      'DB111,X46.2': 'PETICION_VUELTA_MANTENIMIENTO',
      'DB111,X46.3': 'DEFECTO_PLC_DETECTO_BATERIA_PLC',
      'DB111,X46.4': 'DEFECTO_NUMERO_DE_ESCLAVO',
      'DB111,X47.0': 'ERROR_DEPOSITO',
      'DB111,X47.1': 'ERROR_EXTRACTO',
      'DB111,X47.2': 'ERROR_DEPOSITO',
      'DB111,X47.3': 'ERROR_EXTRACTO'
    };
    
    // Leer los datos del PLC
    // Conectar al PLC con timeout
    await new Promise((resolve, reject) => {
      const connectionTimeout = setTimeout(() => {
        reject(new Error('Timeout al conectar con el PLC después de 5 segundos'));
      }, 5000);
      
      conn.initiateConnection(connectionParams, err => {
        clearTimeout(connectionTimeout);
        if (err) {
          logger.error(`Error al conectar con el PLC: ${err.toString()}`);
          reject(new Error(`Error al conectar con el PLC: ${err.toString()}`));
        } else {
          resolve();
        }
      });
    });
    
    console.log('Conexión establecida con el PLC');
        
    // Extraer las direcciones de las variables
    const variableAddresses = Object.keys(alarmVariables);
        
    // Añadir variables para leer
    conn.addItems(variableAddresses);
        
    // Leer todas las variables
    const plcData = await new Promise((resolve, reject) => {
      const readTimeout = setTimeout(() => {
        reject(new Error('Timeout al leer datos del PLC después de 5 segundos'));
      }, 5000);
      
      conn.readAllItems((err, values) => {
        clearTimeout(readTimeout);
        
        // Desconectar del PLC después de leer
        conn.dropConnection(() => {
          console.log('Desconectado del PLC después de leer valores de alarmas del TLV1');
        });
            
        if (err) {
          console.error('Error al leer valores de alarmas del TLV1 del PLC:', err);
          reject(err);
          return;
        }
            
        // Verificar si los valores del PLC son válidos
        const hasValidValues = Object.values(values).some(value => 
          value !== null && value !== undefined);
            
        if (hasValidValues) {
          console.log('Valores de alarmas del TLV1 leídos correctamente del PLC');
          console.log('Datos leídos:', values);
          resolve(values);
        } else {
          reject(new Error('No se obtuvieron valores válidos de alarmas del TLV1 del PLC'));
        }
      });
    });
    
    // Preparar los valores para la consulta SQL
    const values = {};
    
    // Convertir los datos del PLC a valores booleanos
    for (const [address, fieldName] of Object.entries(alarmVariables)) {
      values[fieldName] = Boolean(plcData[address]);
    }
    
    console.log('Valores formateados para la base de datos:', values);
    
    // Verificar si la tabla tiene registros
    const checkTableSql = `
      SELECT COUNT(*) as count 
      FROM TLV1_Alarmas
    `;
    
    const [checkResult] = await query(checkTableSql);
    
    if (checkResult.count === 0) {
      // No hay registros, insertar uno nuevo
      const fields = Object.keys(values).join(', ');
      const placeholders = Object.keys(values).map(() => '?').join(', ');
      
      const insertSql = `
        INSERT INTO TLV1_Alarmas (${fields})
        VALUES (${placeholders})
      `;
      
      await query(insertSql, Object.values(values));
      console.log('Primer registro insertado en la tabla TLV1_Alarmas con datos reales del PLC');
    } else {
      // Actualizar el registro existente (el más reciente)
      const setClause = Object.keys(values)
        .map(field => `${field} = ?`)
        .join(', ');
      
      const updateSql = `
        UPDATE TLV1_Alarmas 
        SET ${setClause}, timestamp = CURRENT_TIMESTAMP
        WHERE id = (SELECT id FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1)
      `;
      
      await query(updateSql, Object.values(values));
      console.log('Registro actualizado en la tabla TLV1_Alarmas con datos reales del PLC');
    }
    
    // Consultar los datos actualizados
    const selectSql = `SELECT * FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1`;
    const selectResult = await query(selectSql);
    
    console.log('Datos actualizados en la tabla TLV1_Alarmas:');
    console.log(JSON.stringify(selectResult, null, 2));
    
    console.log('Sincronización de alarmas del Transelevador 1 (TLV1) completada con éxito.');
    return {
      success: true,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('Error al sincronizar alarmas TLV1:', error);
    logger.error(`Error al sincronizar alarmas TLV1: ${error.message}`);
    
    // En lugar de propagar el error, devolvemos un objeto con información del error
    // para que el backend no se detenga si hay problemas de conexión con el PLC
    return {
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    };
  }
}

module.exports = {
  syncTLV1Alarms
};
