-- Consultar datos de la tabla PT_Status
SELECT * FROM PT_Status ORDER BY id DESC LIMIT 5;
