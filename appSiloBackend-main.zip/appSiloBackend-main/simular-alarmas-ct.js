/**
 * Script para simular alarmas del Carro Transferidor (CT)
 * Este script inserta o actualiza registros en la tabla CT_Alarmas
 * para simular diferentes estados de alarma
 */

// Importar la configuración de la base de datos
const { query } = require('./src/db/mariadb-config');
const { logger } = require('./src/utils/logger');

// Función para simular alarmas del CT
async function simularAlarmasCT(alarmas) {
  try {
    // Verificar si la tabla tiene registros
    const checkTableSql = `
      SELECT COUNT(*) as count 
      FROM CT_Alarmas
    `;
    
    const [checkResult] = await query(checkTableSql);
    
    // Crear un objeto con todos los campos en false
    const todosLosCampos = [
      'error_comunicacion',
      'emergencia_armario_carro',
      'anomalia_variador',
      'anomalia_motor_traslacion',
      'anomalia_motor_entrada',
      'anomalia_motor_salida',
      'final_carrera_pasillo_1',
      'final_carrera_pasillo_12',
      'paleta_descentrada_transfer_entrada',
      'paleta_descentrada_transfer_salida',
      'limite_inferior_lectura_encoder',
      'limite_superior_lectura_encoder',
      'tiempo_transferencia_mesa_salida_carro',
      'telemetro',
      'tiempo_entrada',
      'tiempo_salida',
      'paleta_entrada_sin_codigo',
      'paleta_salida_sin_codigo'
    ];
    
    // Inicializar todos los campos a 0
    const values = {};
    todosLosCampos.forEach(campo => {
      values[campo] = 0;
    });
    
    // Establecer los campos de alarma especificados a 1
    alarmas.forEach(alarma => {
      if (todosLosCampos.includes(alarma)) {
        values[alarma] = 1;
      } else {
        console.warn(`Alarma '${alarma}' no es válida y será ignorada`);
      }
    });
    
    if (checkResult.count === 0) {
      // No hay registros, insertar uno nuevo
      const fields = Object.keys(values).join(', ');
      const placeholders = Object.keys(values).map(() => '?').join(', ');
      
      const insertSql = `
        INSERT INTO CT_Alarmas (${fields})
        VALUES (${placeholders})
      `;
      
      await query(insertSql, Object.values(values));
      console.log('Primer registro insertado en la tabla CT_Alarmas con las alarmas simuladas');
    } else {
      // Actualizar el registro existente (el más reciente)
      const setClause = Object.keys(values)
        .map(field => `${field} = ?`)
        .join(', ');
      
      const updateSql = `
        UPDATE CT_Alarmas 
        SET ${setClause}, timestamp = CURRENT_TIMESTAMP
        WHERE id = (SELECT id FROM CT_Alarmas ORDER BY id DESC LIMIT 1)
      `;
      
      await query(updateSql, Object.values(values));
      console.log('Registro actualizado en la tabla CT_Alarmas con las alarmas simuladas');
    }
    
    // Mostrar las alarmas activas
    console.log('Alarmas activas simuladas:', alarmas);
    
    // Consultar el registro actual para verificar
    const currentRecordSql = `
      SELECT * FROM CT_Alarmas ORDER BY id DESC LIMIT 1
    `;
    
    const [currentRecord] = await query(currentRecordSql);
    console.log('Registro actual en la base de datos:', 
      Object.entries(currentRecord)
        .filter(([key, value]) => value === 1 && key !== 'id' && key !== 'timestamp')
        .map(([key]) => key)
    );
    
  } catch (error) {
    console.error(`Error al simular alarmas del CT: ${error}`);
  }
}

// Obtener las alarmas a simular de los argumentos de la línea de comandos
const alarmasASimular = process.argv.slice(2);

if (alarmasASimular.length === 0) {
  console.log(`
Uso: node simular-alarmas-ct.js [alarma1] [alarma2] ...

Alarmas disponibles:
- error_comunicacion
- emergencia_armario_carro
- anomalia_variador
- anomalia_motor_traslacion
- anomalia_motor_entrada
- anomalia_motor_salida
- final_carrera_pasillo_1
- final_carrera_pasillo_12
- paleta_descentrada_transfer_entrada
- paleta_descentrada_transfer_salida
- limite_inferior_lectura_encoder
- limite_superior_lectura_encoder
- tiempo_transferencia_mesa_salida_carro
- telemetro
- tiempo_entrada
- tiempo_salida
- paleta_entrada_sin_codigo
- paleta_salida_sin_codigo

Ejemplo: node simular-alarmas-ct.js error_comunicacion anomalia_variador

Para limpiar todas las alarmas: node simular-alarmas-ct.js limpiar
  `);
} else if (alarmasASimular.length === 1 && alarmasASimular[0] === 'limpiar') {
  // Limpiar todas las alarmas (establecer todas a false)
  simularAlarmasCT([])
    .then(() => {
      console.log('Todas las alarmas han sido limpiadas');
      process.exit(0);
    })
    .catch(err => {
      console.error('Error:', err);
      process.exit(1);
    });
} else {
  // Simular las alarmas especificadas
  simularAlarmasCT(alarmasASimular)
    .then(() => {
      console.log('Simulación de alarmas completada');
      process.exit(0);
    })
    .catch(err => {
      console.error('Error:', err);
      process.exit(1);
    });
}
