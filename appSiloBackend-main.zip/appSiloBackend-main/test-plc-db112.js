// Script para probar la conexión al PLC y leer datos del DB112 con el formato correcto
const nodes7 = require('nodes7');
require('dotenv').config();

async function testPLCConnection() {
  console.log('Iniciando prueba de conexión al PLC para DB112...');
  
  // Crear una nueva conexión al PLC
  const conn = new nodes7();
  
  // Parámetros de conexión al PLC
  const connectionParams = {
    host: process.env.PLC_IP || '10.21.178.100',
    port: parseInt(process.env.PLC_PORT || '102'),
    rack: parseInt(process.env.PLC_RACK || '0'),
    slot: parseInt(process.env.PLC_SLOT || '3'),
    timeout: 5000
  };
  
  console.log('Parámetros de conexión:', connectionParams);
  
  try {
    // Conectar al PLC
    await new Promise((resolve, reject) => {
      conn.initiateConnection(connectionParams, (err) => {
        if (err) {
          console.error('Error al conectar con el PLC:', err);
          reject(err);
          return;
        }
        console.log('Conexión con el PLC establecida correctamente');
        resolve();
      });
    });
    
    // Definir las variables a leer con el formato correcto
    // Usamos el formato 'DB112,X130.0' para bits y 'DB112,DINT134' para enteros
    const items = [
      'DB112,X130.0', // StConectado (bit)
      'DB112,X130.1', // StDefecto (bit)
      'DB112,X130.2', // St_Auto (bit)
      'DB112,X130.3', // St_Semi (bit)
      'DB112,X130.4', // St_Manual (bit)
      'DB112,X130.5', // St_Puerta (bit)
      'DB112,X130.6', // St_Datos (bit)
      'DB112,DINT134', // MatEntrada (DINT - 32 bits)
      'DB112,DINT138', // MatSalida (DINT - 32 bits)
      'DB112,B142', // PasDestino (byte)
      'DB112,B143', // CicloTrabajo (byte)
      'DB112,B144', // PasActual (byte)
      'DB112,B145'  // St_Carro (byte)
    ];
    
    // Añadir variables a la conexión
    conn.addItems(items);
    
    // Leer valores
    const values = await new Promise((resolve, reject) => {
      conn.readAllItems((err, values) => {
        if (err) {
          console.error('Error al leer valores del PLC:', err);
          reject(err);
          return;
        }
        console.log('Valores leídos del PLC correctamente');
        resolve(values);
      });
    });
    
    // Mostrar los valores leídos
    console.log('Valores leídos del PLC:');
    console.log(JSON.stringify(values, null, 2));
    
    // Estos son los valores que se escribirían en la tabla CT_Status
    const ctStatusData = {
      StConectado: values['DB112,X130.0'] === true ? 1 : 0,
      StDefecto: values['DB112,X130.1'] === true ? 1 : 0,
      St_Auto: values['DB112,X130.2'] === true ? 1 : 0,
      St_Semi: values['DB112,X130.3'] === true ? 1 : 0,
      St_Manual: values['DB112,X130.4'] === true ? 1 : 0,
      St_Puerta: values['DB112,X130.5'] === true ? 1 : 0,
      St_Datos: values['DB112,X130.6'] === true ? 1 : 0,
      MatEntrada: values['DB112,DINT134'] || 0,
      MatSalida: values['DB112,DINT138'] || 0,
      PasDestino: values['DB112,B142'] || 0,
      CicloTrabajo: values['DB112,B143'] || 0,
      PasActual: values['DB112,B144'] || 0,
      St_Carro: values['DB112,B145'] || 0
    };
    
    console.log('Datos para CT_Status:');
    console.log(JSON.stringify(ctStatusData, null, 2));
    
  } catch (error) {
    console.error('Error en la prueba de conexión:', error);
  } finally {
    // Desconectar del PLC
    conn.dropConnection();
    console.log('Desconectado del PLC');
  }
}

// Ejecutar la prueba
testPLCConnection();
