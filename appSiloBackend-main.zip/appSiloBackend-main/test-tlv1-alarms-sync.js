// Script para probar la sincronización de alarmas del Transelevador 1 (TLV1) simulando datos del PLC
require('dotenv').config();
const { query } = require('./src/db/mariadb-config');
const nodes7 = require('nodes7');
const { logger } = require('./src/utils/logger');

// Función para simular la conexión al PLC y la lectura de datos
async function simulatePLCData() {
  // Simular datos aleatorios para las alarmas (algunos activos, otros inactivos)
  const simulatedData = {};
  
  // Lista de direcciones de alarmas del TLV1
  const alarmAddresses = [
    'DB111,X40.0', 'DB111,X40.1', 'DB111,X40.2', 'DB111,X40.3', 'DB111,X40.4', 
    'DB111,X40.5', 'DB111,X40.6', 'DB111,X40.7', 'DB111,X40.8', 'DB111,X40.9', 
    'DB111,X40.10', 'DB111,X40.11', 'DB111,X40.12', 'DB111,X40.13', 'DB111,X40.14', 
    'DB111,X40.15', 'DB111,X42.0', 'DB111,X42.1', 'DB111,X42.2', 'DB111,X42.3', 
    'DB111,X42.4', 'DB111,X42.5', 'DB111,X42.6', 'DB111,X42.7', 'DB111,X42.8', 
    'DB111,X42.9', 'DB111,X42.10', 'DB111,X42.11', 'DB111,X42.12', 'DB111,X42.13', 
    'DB111,X42.14', 'DB111,X42.15', 'DB111,X44.0', 'DB111,X44.1', 'DB111,X44.2', 
    'DB111,X44.3', 'DB111,X44.4', 'DB111,X44.5', 'DB111,X44.6', 'DB111,X44.7', 
    'DB111,X44.8', 'DB111,X44.9', 'DB111,X44.10', 'DB111,X44.11', 'DB111,X44.12', 
    'DB111,X44.13', 'DB111,X44.14', 'DB111,X44.15', 'DB111,X46.0', 'DB111,X46.1', 
    'DB111,X46.2', 'DB111,X46.3', 'DB111,X46.9', 'DB111,X46.10', 'DB111,X46.11'
  ];
  
  // Generar valores aleatorios para las alarmas (la mayoría inactivas, algunas activas)
  alarmAddresses.forEach(address => {
    // Generar un valor aleatorio con mayor probabilidad de ser 0 (80% de probabilidad)
    simulatedData[address] = Math.random() < 0.2 ? 1 : 0;
  });
  
  // Activar específicamente algunas alarmas para pruebas
  simulatedData['DB111,X40.0'] = 1; // EMERGENCIA_GENERAL
  simulatedData['DB111,X40.8'] = 1; // PROTECCION_CONVERTIDOR_TRASLACION
  simulatedData['DB111,X42.10'] = 1; // TIEMPO_CICLO_HORQUILLAS
  
  return simulatedData;
}

async function testTLV1AlarmsSync() {
  try {
    console.log('Probando sincronización de alarmas TLV1 con datos simulados...');
    
    // Simular datos del PLC
    const plcData = await simulatePLCData();
    console.log('Datos simulados del PLC:', plcData);
    
    // Mapeo de direcciones del PLC a nombres de campos en la base de datos
    const alarmVariables = {
      'DB111,X40.0': 'EMERGENCIA_GENERAL',
      'DB111,X40.1': 'PUERTA_CABINA_ABIERTA',
      'DB111,X40.2': 'EXCESO_RECORRIDO_ADELANTE',
      'DB111,X40.3': 'EXCESO_RECORRIDO_ATRAS',
      'DB111,X40.4': 'EXCESO_RECORRIDO_SUBIDA',
      'DB111,X40.5': 'EXCESO_RECORRIDO_BAJADA',
      'DB111,X40.6': 'PARACAIDAS_ELEVACION',
      'DB111,X40.7': 'CABLES_FLOJOS_ELEVACION',
      'DB111,X40.8': 'PROTECCION_CONVERTIDOR_TRASLACION',
      'DB111,X40.9': 'PROTECCION_CONVERTIDOR_ELEVACION',
      'DB111,X40.10': 'PROTECCION_CONVERTIDOR_HORQUILLAS',
      'DB111,X40.11': 'PROTECCION_MOTOR_TRASLACION',
      'DB111,X40.12': 'PROTECCION_MOTOR_ELEVACION',
      'DB111,X40.13': 'PROTECCION_MOTOR_HORQUILLAS',
      'DB111,X40.14': 'PROTECCION_CONVERTIDOR_TRASLACION',
      'DB111,X40.15': 'DEFECTO_CONVERTIDOR_ELEVACION',
      'DB111,X42.0': 'DEFECTO_CONVERTIDOR_HORQUILLAS',
      'DB111,X42.1': 'EXCESO_VELOCIDAD_TRASLACION',
      'DB111,X42.2': 'EXCESO_VELOCIDAD_TRASLACION',
      'DB111,X42.3': 'EXCESO_VELOCIDAD_TRASLACION',
      'DB111,X42.4': 'DEFECTO_FOTOCELLULAS_DE_CENTRAJE_HORQUILLAS',
      'DB111,X42.5': 'DEFECTO_GIRO_TRASLACION',
      'DB111,X42.6': 'DEFECTO_GIRO_ELEVACION',
      'DB111,X42.7': 'DEFECTO_GIRO_HORQUILLAS',
      'DB111,X42.8': 'TIEMPO_CENTRAJE_TRASLACION',
      'DB111,X42.9': 'TIEMPO_CENTRAJE_ELEVACION',
      'DB111,X42.10': 'TIEMPO_CICLO_HORQUILLAS',
      'DB111,X42.11': 'TIEMPO_CICLO_TOPE_DE_SEGURIDAD',
      'DB111,X42.12': 'DEFECTO_DETECTORES_TRASLACION',
      'DB111,X42.13': 'DEFECTO_DETECTORES_ELEVACION',
      'DB111,X42.14': 'DEFECTO_DETECTORES_HORQUILLAS',
      'DB111,X42.15': 'DEFECTO_DETECTORES_TOPE_DE_SEGURIDAD',
      'DB111,X44.0': 'DEFECTO_IMPULSOR_ENCODER_TRASLACION',
      'DB111,X44.1': 'DEFECTO_IMPULSOR_ENCODER_ELEVACION',
      'DB111,X44.2': 'DEFECTO_IMPULSOR_ENCODER_HORQUILLAS',
      'DB111,X44.3': 'CONTADOR_IMPULSOR_ENCODER_TRASL_DESFASADO',
      'DB111,X44.4': 'CONTADOR_IMPULSOR_ENCODER_ELEV_DESFASADO',
      'DB111,X44.5': 'DEFECTO_COMUNICACION_PERIFERIA',
      'DB111,X44.6': 'DEFECTO_FOTOCELLULAS_DE_CENTRAJE_TRASLACION',
      'DB111,X44.7': 'DEFECTOS_DETECTORES_LECTURA_PASILLO',
      'DB111,X44.8': 'DEFECTO_CHOPPER_FRENADO_ELEVACION',
      'DB111,X44.9': 'DEFECTO_DE_GALIBO',
      'DB111,X44.10': 'DEFECTO_PRESENCIA_DE_PALETA',
      'DB111,X44.11': 'DEF_FOTOCELLULAS_PALPADORAS',
      'DB111,X44.12': 'DEF_FOTOC_PUERTA_CERRADO',
      'DB111,X44.13': 'PASILLO_FUERA_DE_SERVICIO',
      'DB111,X44.14': 'DEF_NR_DE_PASILLO',
      'DB111,X44.15': 'DEFECTO_TENSION_24VCC',
      'DB111,X46.0': 'DEFECTO_TENSION_PERIFERICOS_220_VCA',
      'DB111,X46.1': 'DEF_DESTINO_INCORRECTO',
      'DB111,X46.2': 'PETICION_VUELTA_MANTENIMIENTO',
      'DB111,X46.3': 'DEFECTO_FALTA_DE_BATERIA_PLC',
      'DB111,X46.9': 'DEFECTO_NUMERO_DE_ESCLAVO',
      'DB111,X46.10': 'ERROR_DEPOSITO',
      'DB111,X46.11': 'ERROR_EXTRACCION'
    };
    
    // Preparar los valores para la consulta SQL
    const values = {};
    
    // Convertir los datos del PLC a valores booleanos
    for (const [address, fieldName] of Object.entries(alarmVariables)) {
      values[fieldName] = Boolean(plcData[address]);
    }
    
    console.log('Valores formateados para la base de datos:', values);
    
    // Verificar si la tabla tiene registros
    const checkTableSql = `
      SELECT COUNT(*) as count 
      FROM TLV1_Alarmas
    `;
    
    const [checkResult] = await query(checkTableSql);
    
    if (checkResult.count === 0) {
      // No hay registros, insertar uno nuevo
      const fields = Object.keys(values).join(', ');
      const placeholders = Object.keys(values).map(() => '?').join(', ');
      
      const insertSql = `
        INSERT INTO TLV1_Alarmas (${fields})
        VALUES (${placeholders})
      `;
      
      await query(insertSql, Object.values(values));
      console.log('Primer registro insertado en la tabla TLV1_Alarmas con datos simulados');
    } else {
      // Actualizar el registro existente (el más reciente)
      const setClause = Object.keys(values)
        .map(field => `${field} = ?`)
        .join(', ');
      
      const updateSql = `
        UPDATE TLV1_Alarmas 
        SET ${setClause}, timestamp = CURRENT_TIMESTAMP
        WHERE id = (SELECT id FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1)
      `;
      
      await query(updateSql, Object.values(values));
      console.log('Registro actualizado en la tabla TLV1_Alarmas con datos simulados');
    }
    
    // Consultar los datos actualizados
    const selectSql = `SELECT * FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1`;
    const selectResult = await query(selectSql);
    
    console.log('Datos actualizados en la tabla TLV1_Alarmas:');
    console.log(JSON.stringify(selectResult, null, 2));
    
    console.log('Prueba de sincronización de alarmas del Transelevador 1 (TLV1) completada con éxito.');
    
    // Esperar 10 segundos y luego desactivar todas las alarmas
    console.log('Esperando 10 segundos antes de desactivar todas las alarmas...');
    setTimeout(async () => {
      // Desactivar todas las alarmas
      const resetValues = {};
      for (const fieldName of Object.values(alarmVariables)) {
        resetValues[fieldName] = false;
      }
      
      const resetSetClause = Object.keys(resetValues)
        .map(field => `${field} = ?`)
        .join(', ');
      
      const resetSql = `
        UPDATE TLV1_Alarmas 
        SET ${resetSetClause}, timestamp = CURRENT_TIMESTAMP
        WHERE id = (SELECT id FROM TLV1_Alarmas ORDER BY id DESC LIMIT 1)
      `;
      
      await query(resetSql, Object.values(resetValues));
      console.log('Todas las alarmas han sido desactivadas');
      
      // Consultar los datos actualizados después de desactivar
      const finalResult = await query(selectSql);
      console.log('Estado final de las alarmas:');
      console.log(JSON.stringify(finalResult, null, 2));
      
      process.exit(0);
    }, 10000);
    
  } catch (error) {
    console.error('Error al probar la sincronización de alarmas TLV1:', error);
    process.exit(1);
  }
}

// Ejecutar la función
testTLV1AlarmsSync();
